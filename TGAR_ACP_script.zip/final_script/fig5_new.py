
""" This code generates frequency plot of CO, O3, and PAN
    Coded    : - 2023/April/
    By       : - Mukesh Rai
    Location : - JPL office """


#===== Import librries ==========================
import matplotlib
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap
import numpy as np
import cmaps
from matplotlib.patches import Patch
from matplotlib.pyplot import figure
import matplotlib.gridspec as gridspec
import scipy.ndimage
from mpl_toolkits.axes_grid1 import make_axes_locatable
from matplotlib import rcParams
from numpy import sqrt
import xarray as xr
from mpl_toolkits.axes_grid1 import make_axes_locatable
import pandas as pd


"""Control font"""
matplotlib.rcParams['font.family'] = "sans-serif"
matplotlib.rcParams['font.sans-serif'] = "Times New Roman"

#======================== Get IGT data ================================================================
data1 = xr.open_dataset('/Volumes/External_4TB/jpl_AR/2005_2019/igt_co_2005_2019_regrid.nc')          #CO
data2 = xr.open_dataset('/Volumes/External_4TB/jpl_AR/2005_2019/igt_o3_2005_2019_regrid.nc')          #O3
data3 = xr.open_dataset('/Volumes/External_4TB/jpl_AR/2005_2019/igt_pan_2005_2019_regrid.nc')         #PAN
#============= Load AR data for same pixel data run  =======================
ar1   = xr.open_dataset('/Volumes/External_4TB/jpl_AR/2005_2019//server_run/run_pixelarea_same/co/output/ar_co_regrid.nc')       #CO
ar2   = xr.open_dataset('/Volumes/External_4TB/jpl_AR/2005_2019/server_run/run_pixelarea_same/o3/output/ar_o3_regrid.nc')       #O3
ar3   = xr.open_dataset('/Volumes/External_4TB/jpl_AR/2005_2019/server_run/run_pixelarea_same/pan/output/ar_pan_regrid.nc')      #PAN
#========== Load U and V wind component ==============
u1    = xr.open_dataset('/Volumes/External_4TB/jpl_AR/2005_2019/u_2005_2019_vertmean.nc')
v1    = xr.open_dataset('/Volumes/External_4TB/jpl_AR/2005_2019/v_2005_2019_vertmean.nc')
#==== Get lat and lon =========
lat = data1.lat
lon = data1.lon
#====== Get IGT ====================
#===== CO ===========
ivtx1  = data1.ivtx
ivty1  = data1.ivty

#===== O3 ===========
ivtx2  = data2.ivtx
ivty2  = data2.ivty

#===== PAN ===========
ivtx3  = data3.ivtx
ivty3  = data3.ivty

ivtx3 = ivtx3.sortby('time')
ivty3 = ivty3.sortby('time')

#==== Get u and v ===========
u = u1.u
v = v1.v

#====== Resample hourly data into seasons ===============
#=== co ==
ivtx_month1 = ivtx1.resample(time="1M").mean()
ivty_month1 = ivty1.resample(time="1M").mean()
#=== o3 ==
ivtx_month2 = ivtx2.resample(time="1M").mean()
ivty_month2 = ivty2.resample(time="1M").mean()
#=== PAN ==
ivtx_month3 = ivtx3.resample(time="1M").mean()
ivty_month3 = ivty3.resample(time="1M").mean()


#====== Resample u and v hourly data into seasons ===============
u_month = u.resample(time="1M").mean()
v_month = v.resample(time="1M").mean()

#========= Seasonal mean ==========================
#=== CO ==
ivtx_seasonal1 = ivtx_month1.groupby("time.season").mean("time")
ivty_seasonal1 = ivty_month1.groupby("time.season").mean("time")

#== O3 ==
ivtx_seasonal2 = ivtx_month2.groupby("time.season").mean("time")
ivty_seasonal2 = ivty_month2.groupby("time.season").mean("time")

#== PAN ==
ivtx_seasonal3 = ivtx_month3.groupby("time.season").mean("time")
ivty_seasonal3 = ivty_month3.groupby("time.season").mean("time")

#==== U and V ===================
u_season = u_month.groupby("time.season").mean("time")
v_season = v_month.groupby("time.season").mean("time")

#========= Calculate Integrated Gas Transport  ========

#===== CO ===============
ivtx_win1 = ivtx_seasonal1.isel(season=0) # winter [DJF]
ivty_win1 = ivty_seasonal1.isel(season=0) # winter [DJF]

ivtx_spr1 = ivtx_seasonal1.isel(season=2) # Spring [MAM]
ivty_spr1 = ivty_seasonal1.isel(season=2) # Spring [MAM]

ivtx_sum1 = ivtx_seasonal1.isel(season=1) # Summer [JJA]
ivty_sum1 = ivty_seasonal1.isel(season=1) # Summer [JJA]

ivtx_aut1 = ivtx_seasonal1.isel(season=3) # Autumn [SON]
ivty_aut1 = ivty_seasonal1.isel(season=3) # Autumn [SON]

#===== O3 ===============
ivtx_win2 = ivtx_seasonal2.isel(season=0) # winter [DJF]
ivty_win2 = ivty_seasonal2.isel(season=0) # winter [DJF]

ivtx_spr2 = ivtx_seasonal2.isel(season=2) # Spring [MAM]
ivty_spr2 = ivty_seasonal2.isel(season=2) # Spring [MAM]

ivtx_sum2 = ivtx_seasonal2.isel(season=1) # Summer [JJA]
ivty_sum2 = ivty_seasonal2.isel(season=1) # Summer [JJA]

ivtx_aut2 = ivtx_seasonal2.isel(season=3) # Autumn [SON]
ivty_aut2 = ivty_seasonal2.isel(season=3) # Autumn [SON]


#===== PAN ===============
ivtx_win3 = ivtx_seasonal3.isel(season=0) # winter [DJF]
ivty_win3 = ivty_seasonal3.isel(season=0) # winter [DJF]

ivtx_spr3 = ivtx_seasonal3.isel(season=2) # Spring [MAM]
ivty_spr3 = ivty_seasonal3.isel(season=2) # Spring [MAM]

ivtx_sum3 = ivtx_seasonal3.isel(season=1) # Summer [JJA]
ivty_sum3 = ivty_seasonal3.isel(season=1) # Summer [JJA]

ivtx_aut3 = ivtx_seasonal3.isel(season=3) # Autumn [SON]
ivty_aut3 = ivty_seasonal3.isel(season=3) # Autumn [SON]

#===== Slice down seasonal data u and v ======================

u_win = u_season.isel(season=0) # winter [DJF]
v_win = v_season.isel(season=0) # winter [DJF]

u_spr = u_season.isel(season=2) # Spring [MAM]
v_spr = v_season.isel(season=2) # Spring [MAM]

u_sum = u_season.isel(season=1) # Summer [JJA]
v_sum = v_season.isel(season=1) # Summer [JJA]

u_aut = u_season.isel(season=3) # Autumn [SON]
v_aut = v_season.isel(season=3) # Autumn [SON]

#======== Calculate wind speed =================================
win_speed = np.sqrt(u_win**2 + u_win**2)
spr_speed = np.sqrt(u_spr**2 + u_spr**2)
sum_speed = np.sqrt(u_sum**2 + u_sum**2)
aut_speed = np.sqrt(u_aut**2 + u_aut**2)

#========================xxxxxxx Now Plot xxxx =======================================================================
#========== Setting Frame ======================
fig = plt.figure(figsize=(11, 9))
m = Basemap(projection='robin',lon_0=0,resolution='c')


"""===========O3======================================"""
#========= WINTER O3  ========================
shape = ar2.shape
isAR  = shape>=1
isAR  = np.float64(isAR)
isAR[isAR==0] = np.nan
#======== Manage month =======
date        = data2.time
df          = pd.DataFrame({'date':date})
df['month'] = df['date'].dt.month
month       = df['month']
#========== Set all months outside of desired season to NaN (create a mask) =============================================
month[(month==3)|(month==4)|(month==5)|(month==6)|(month==7)|(month==8)|(month==9)|(month==10)|(month==11)]= np.NaN  # Winter
month = np.array(month) #convert month to array
#========== Set all selected months (not NaN) to value 1 ===============================================================
month[np.logical_not(np.isnan(month))] = 1
N = np.nansum(month)
#=========  Create matrix of the month variable, in the same size as isAR ===========================================
win_month = np.tile(month[:, np.newaxis, np.newaxis], (1, isAR.shape[1], isAR.shape[2]))
#======== Now Calculate AR Frequency [%] ================================================================================
o3_win = (np.nansum(isAR * win_month, axis=0) / N) * 100

ax = plt.subplot(4,3,1)
x, y = m(*np.meshgrid(lon,lat))
s = m.pcolormesh(x,y,o3_win,cmap=cmaps.GMT_panoply)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=8)
m.drawmeridians(range(0, 360, 60),    color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=8)
m.drawcoastlines(linewidth=0.2)
plt.clim(0,20)
s1 = m.contour(x,y,win_speed,5, linewidths=1,colors='#014421')
plt.clabel(s1, fontsize=10)
ax.set_title('$O_3$', fontsize=15, pad=5)
plt.ylabel("DJF",fontsize=15,labelpad=5)
#========= SPRING  O3  ========================
#======== Mange month =======
date        = data2.time
df          = pd.DataFrame({'date':date})
df['month'] = df['date'].dt.month
month       = df['month']

month[np.logical_or(month < 3, month > 5)] = np.NaN
month = np.array(month) #convert month to array
month[np.logical_not(np.isnan(month))] = 1
N = np.nansum(month)
spr_month = np.tile(month[:, np.newaxis, np.newaxis], (1, isAR.shape[1], isAR.shape[2]))
o3_spr = (np.nansum(isAR * spr_month, axis=0) / N) * 100
ax = plt.subplot(4,3,4)
x, y = m(*np.meshgrid(lon,lat))
s = m.pcolormesh(x,y,o3_spr,cmap=cmaps.GMT_panoply)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=8)
m.drawmeridians(range(0, 360, 60), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=8)
m.drawcoastlines(linewidth=0.2)
plt.clim(0,20)
s1 = m.contour(x,y,win_speed,5, linewidths=1,colors='#014421')
plt.clabel(s1, fontsize=10)
plt.ylabel("MAM",fontsize=15,labelpad=5)

#========= SUMMER O3 ============================
#======== Mange month =======
date        = data2.time
df          = pd.DataFrame({'date':date})
df['month'] = df['date'].dt.month
month       = df['month']
month[np.logical_or(month < 6, month > 8)] = np.NaN
month = np.array(month) #convert month to array
month[np.logical_not(np.isnan(month))] = 1
N = np.nansum(month)
sum_month = np.tile(month[:, np.newaxis, np.newaxis], (1, isAR.shape[1], isAR.shape[2]))
o3_sum = (np.nansum(isAR * sum_month, axis=0) / N) * 100
s = plt.subplot(4,3,7)
x, y = m(*np.meshgrid(lon,lat))
ax = m.pcolormesh(x,y,o3_sum,cmap=cmaps.GMT_panoply)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=8)
m.drawmeridians(range(0, 360, 60), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=8)
m.drawcoastlines(linewidth=0.2)
plt.clim(0,20)
s1 = m.contour(x,y,spr_speed,5, linewidths=1,colors='#014421')
plt.clabel(s1, fontsize=10)
plt.ylabel("JJA",fontsize=15,labelpad=5)

#========= Autumn O3 ============================
#======== Mange month =======
date        = data2.time
df          = pd.DataFrame({'date':date})
df['month'] = df['date'].dt.month
month       = df['month']

month[np.logical_or(month < 9, month > 11)] = np.NaN
month = np.array(month) #convert month to array
month[np.logical_not(np.isnan(month))] = 1
N = np.nansum(month)
aut_month = np.tile(month[:, np.newaxis, np.newaxis], (1, isAR.shape[1], isAR.shape[2]))
o3_aut = (np.nansum(isAR * aut_month, axis=0) / N) * 100
ax = plt.subplot(4,3,10)
x, y = m(*np.meshgrid(lon,lat))
s = m.pcolormesh(x,y,o3_aut,cmap=cmaps.GMT_panoply)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=8)
m.drawmeridians(range(0, 360, 60), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 1],fontsize=10)
m.drawcoastlines(linewidth=0.2)
plt.clim(0,20)
s1 = m.contour(x,y,spr_speed,5, linewidths=1,colors='#014421')
plt.clabel(s1, fontsize=10)

plt.ylabel("SON",fontsize=15,labelpad=5)

divider = make_axes_locatable(ax)
cax = divider.append_axes('bottom', size="10%", pad=0.2)
cbar = fig.colorbar(s, cax=cax,orientation='horizontal',extend='both')
cbar.set_label('AR frequency [days/season]',fontsize=15)
cbar.ax.tick_params(labelsize=12)
# Add minor ticks
cbar.ax.minorticks_on()

"""============== CO===================================================="""
#============================================================
#========= WINTER CO  ========================
shape = ar1.shape
isAR  = shape>=1
isAR  = np.float64(isAR)
isAR[isAR==0] = np.nan
#======== Manage month =======
date        = data1.time
df          = pd.DataFrame({'date':date})
df['month'] = df['date'].dt.month
month       = df['month']
#========== Set all months outside of desired season to NaN (create a mask) =============================================
month[(month==3)|(month==4)|(month==5)|(month==6)|(month==7)|(month==8)|(month==9)|(month==10)|(month==11)]= np.NaN  # Winter
month = np.array(month) #convert month to array
#========== Set all selected months (not NaN) to value 1 ===============================================================
month[np.logical_not(np.isnan(month))] = 1
N = np.nansum(month)
#=========  Create matrix of the month variable, in the same size as isAR ===========================================
win_month = np.tile(month[:, np.newaxis, np.newaxis], (1, isAR.shape[1], isAR.shape[2]))
#======== Now Calculate AR Frequency [%] ================================================================================
co_win = (np.nansum(isAR * win_month, axis=0) / N) * 100
ax = plt.subplot(4,3,2)
x, y = m(*np.meshgrid(lon,lat))
s = m.pcolormesh(x,y,co_win,cmap=cmaps.GMT_panoply)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=8)
m.drawmeridians(range(0, 360, 60), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=8)
m.drawcoastlines(linewidth=0.2)
plt.clim(0,20)
ax.set_title('CO', fontsize=15, pad=5)
s1 = m.contour(x,y,win_speed,5, linewidths=1,colors='#014421')
plt.clabel(s1, fontsize=10)

#========= SPRING CO  ===================================================================================================
#======== Mange month =======
date        = data1.time
df          = pd.DataFrame({'date':date})
df['month'] = df['date'].dt.month
month       = df['month']
month[np.logical_or(month < 3, month > 5)] = np.NaN
month = np.array(month) #convert month to array
month[np.logical_not(np.isnan(month))] = 1
N = np.nansum(month)
spr_month = np.tile(month[:, np.newaxis, np.newaxis], (1, isAR.shape[1], isAR.shape[2]))
co_spr = (np.nansum(isAR * spr_month, axis=0) / N) * 100
ax = plt.subplot(4,3,5)
x, y = m(*np.meshgrid(lon,lat))
ax = m.pcolormesh(x,y,co_spr,cmap=cmaps.GMT_panoply)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=8)
m.drawmeridians(range(0, 360, 60),    color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=8)
m.drawcoastlines(linewidth=0.2)
plt.clim(0,20)
s1 = m.contour(x,y,spr_speed,5, linewidths=1,colors='#014421')
plt.clabel(s1, fontsize=10)


#========= SUMMER CO ============================
#======== Mange month =======
date        = data1.time
df          = pd.DataFrame({'date':date})
df['month'] = df['date'].dt.month
month       = df['month']
month[np.logical_or(month < 6, month > 8)] = np.NaN
month = np.array(month) #convert month to array
month[np.logical_not(np.isnan(month))] = 1
N = np.nansum(month)
spr_month = np.tile(month[:, np.newaxis, np.newaxis], (1, isAR.shape[1], isAR.shape[2]))
co_sum = (np.nansum(isAR * spr_month, axis=0) / N) * 100
ax = plt.subplot(4,3,8)
x, y = m(*np.meshgrid(lon,lat))
s = m.pcolormesh(x,y,co_sum,cmap=cmaps.GMT_panoply)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=8)
m.drawmeridians(range(0, 360, 60), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=8)
m.drawcoastlines(linewidth=0.2)
plt.clim(0,20)
s1 = m.contour(x,y,sum_speed,5, linewidths=1,colors='#014421')
plt.clabel(s1, fontsize=10)

#========= AUTUMN CO ============================
#======== Mange month =======
date        = data2.time
df          = pd.DataFrame({'date':date})
df['month'] = df['date'].dt.month
month       = df['month']

month[np.logical_or(month < 9, month > 11)] = np.NaN
month = np.array(month) #convert month to array
month[np.logical_not(np.isnan(month))] = 1
N = np.nansum(month)
spr_month = np.tile(month[:, np.newaxis, np.newaxis], (1, isAR.shape[1], isAR.shape[2]))
co_aut = (np.nansum(isAR * spr_month, axis=0) / N) * 100

ax = plt.subplot(4,3,11)
x, y = m(*np.meshgrid(lon,lat))
s3 = m.pcolormesh(x,y,co_aut,cmap=cmaps.GMT_panoply)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=10)
m.drawmeridians(range(0, 360, 60), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 1],fontsize=10)
m.drawcoastlines(linewidth=0.2)
plt.clim(0,20)
s1 = m.contour(x,y,aut_speed,5, linewidths=1,colors='#014421')
plt.clabel(s1, fontsize=10)

#===== Add colorbar ===================
divider = make_axes_locatable(ax)
cax = divider.append_axes('bottom', size="10%", pad=0.2)
cbar = fig.colorbar(s, cax=cax,orientation='horizontal',extend='both')
cbar.set_label('AR frequency [days/season]',fontsize=15)
cbar.ax.tick_params(labelsize=12)
# Add minor ticks
cbar.ax.minorticks_on()




"""===================PAN===================="""

#========= WINTER PAN  ========================
shape = ar3.shape
isAR  = shape>=1
isAR  = np.float64(isAR)
isAR[isAR==0] = np.nan
#======== Manage month =======
date        = data1.time
df          = pd.DataFrame({'date':date})
df['month'] = df['date'].dt.month
month       = df['month']
#========== Set all months outside of desired season to NaN (create a mask) =============================================
month[(month==3)|(month==4)|(month==5)|(month==6)|(month==7)|(month==8)|(month==9)|(month==10)|(month==11)]= np.NaN  # Winter
month = np.array(month) #convert month to array
#========== Set all selected months (not NaN) to value 1 ===============================================================
month[np.logical_not(np.isnan(month))] = 1
N = np.nansum(month)
#=========  Create matrix of the month variable, in the same size as isAR ===========================================
win_month = np.tile(month[:, np.newaxis, np.newaxis], (1, isAR.shape[1], isAR.shape[2]))
#======== Now Calculate AR Frequency [%] ================================================================================
pan_win = (np.nansum(isAR * win_month, axis=0) / N) * 100
ax = plt.subplot(4,3,3)
x, y = m(*np.meshgrid(lon,lat))
s = m.pcolormesh(x,y,pan_win,cmap=cmaps.GMT_panoply)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 1, 0, 0],fontsize=10)
m.drawmeridians(range(0, 360, 60), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=10)
m.drawcoastlines(linewidth=0.2)
plt.clim(0,20)
ax.set_title('PAN', fontsize=15, pad=5)
s1 = m.contour(x,y,win_speed,5, linewidths=1,colors='#014421')
plt.clabel(s1, fontsize=10)


#========= SPRING  PAN  ========================
#======== Mange month =======
date        = data3.time
df          = pd.DataFrame({'date':date})
df['month'] = df['date'].dt.month
month       = df['month']

month[np.logical_or(month < 3, month > 5)] = np.NaN
month = np.array(month) #convert month to array
month[np.logical_not(np.isnan(month))] = 1
N = np.nansum(month)
spr_month = np.tile(month[:, np.newaxis, np.newaxis], (1, isAR.shape[1], isAR.shape[2]))
pan_spr = (np.nansum(isAR * spr_month, axis=0) / N) * 100

ax = plt.subplot(4,3,6)
x, y = m(*np.meshgrid(lon,lat))
ax = m.pcolormesh(x,y,pan_spr,cmap=cmaps.GMT_panoply)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 1, 0, 0],fontsize=10)
m.drawmeridians(range(0, 360, 60), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=10)
m.drawcoastlines(linewidth=0.2)
plt.clim(0,20)
s1 = m.contour(x,y,spr_speed,5, linewidths=1,colors='#014421')
plt.clabel(s1, fontsize=10)

#========= SUMMER PAN ============================

#======== Mange month =======
date        = data3.time
df          = pd.DataFrame({'date':date})
df['month'] = df['date'].dt.month
month       = df['month']

month[np.logical_or(month < 6, month > 8)] = np.NaN
month = np.array(month) #convert month to array
month[np.logical_not(np.isnan(month))] = 1
N = np.nansum(month)
sum_month = np.tile(month[:, np.newaxis, np.newaxis], (1, isAR.shape[1], isAR.shape[2]))
pan_sum = (np.nansum(isAR * sum_month, axis=0) / N) * 100


ax = plt.subplot(4,3,9)
x, y = m(*np.meshgrid(lon,lat))
ax = m.pcolormesh(x,y,pan_sum,cmap=cmaps.GMT_panoply)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 1, 0, 0],fontsize=10)
m.drawmeridians(range(0, 360, 60), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=10)
m.drawcoastlines(linewidth=0.2)
plt.clim(0,20)
s1 = m.contour(x,y,sum_speed,5, linewidths=1,colors='#014421')
plt.clabel(s1, fontsize=10)

#=========== AUTUMN PAN ==============================================================
#======== Mange month =======
date        = data3.time
df          = pd.DataFrame({'date':date})
df['month'] = df['date'].dt.month
month       = df['month']

month[np.logical_or(month < 9, month > 11)] = np.NaN
month = np.array(month) #convert month to array
month[np.logical_not(np.isnan(month))] = 1
N = np.nansum(month)
aut_month = np.tile(month[:, np.newaxis, np.newaxis], (1, isAR.shape[1], isAR.shape[2]))
pan_aut = (np.nansum(isAR * aut_month, axis=0) / N) * 100

ax = plt.subplot(4,3,12)
x, y = m(*np.meshgrid(lon,lat))
s4 = m.pcolormesh(x,y,pan_aut,cmap=cmaps.GMT_panoply)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 1, 0, 0],fontsize=10)
m.drawmeridians(range(0, 360, 60), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 1],fontsize=10)
m.drawcoastlines(linewidth=0.2)
plt.clim(0,20)


s1 = m.contour(x,y,aut_speed,5, linewidths=1,colors='#014421')
plt.clabel(s1, fontsize=10)

#===== Add colorbar ===================
divider = make_axes_locatable(ax)
cax = divider.append_axes('bottom', size="10%", pad=0.2)
cbar = fig.colorbar(s, cax=cax,orientation='horizontal',extend='both')
cbar.set_label('AR frequency [days/season]',fontsize=15)
cbar.ax.tick_params(labelsize=12)
# Add minor ticks
cbar.ax.minorticks_on()




fig.subplots_adjust(top=0.973,
                        bottom=0.056,
                        left=0.025,
                        right=0.972,
                        hspace=0.002,
                        wspace=0.031)

plt.savefig('fig5.png',dpi=300)

plt.show()



