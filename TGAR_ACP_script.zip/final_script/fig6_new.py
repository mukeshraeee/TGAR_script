#===== Import Libraries ========================
import matplotlib
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap
import numpy as np
import cmaps
from matplotlib.patches import Patch
from matplotlib.pyplot import figure
import matplotlib.gridspec as gridspec
import scipy.ndimage
from mpl_toolkits.axes_grid1 import make_axes_locatable
from matplotlib import rcParams
from numpy import sqrt
import xarray as xr
from mpl_toolkits.axes_grid1 import make_axes_locatable
from mplgrid import grid
from mpl_toolkits.axes_grid1 import make_axes_locatable
from mpl_toolkits.axes_grid1 import ImageGrid
import pandas as pd
from geocat.viz import util as gvutil
from matplotlib.ticker import MultipleLocator, FormatStrFormatter
from matplotlib import ticker
import matplotlib.lines as mlines


"""Control font"""
matplotlib.rcParams['font.family'] = "sans-serif"
matplotlib.rcParams['font.sans-serif'] = "Times New Roman"

#============== Load data =========================
#== 1000-700hpa
data1 = xr.open_dataset('/Volumes/External_4TB/jpl_AR/2010_igt/1000_700hpa/igt_co_regrid.nc')
data2 = xr.open_dataset('/Volumes/External_4TB/jpl_AR/2010_igt/1000_700hpa/igt_o3_regrid.nc')
data3 = xr.open_dataset('/Volumes/External_4TB/jpl_AR/2010_igt/1000_700hpa/igt_pan_regrid.nc')
#=== 1000-60hpa
data4 = xr.open_dataset('/Volumes/External_4TB/jpl_AR/2010_igt/1000_60hpa/igt_co_regrid.nc')
data5 = xr.open_dataset('/Volumes/External_4TB/jpl_AR/2010_igt/1000_60hpa/igt_o3_regrid.nc')
data6 = xr.open_dataset('/Volumes/External_4TB/jpl_AR/2010_igt/1000_60hpa/igt_pan_regrid.nc')


#==== Get zonal flux =======
#== 1000-700hpa
#===== CO ===========
ivtx1 = data1.ivtx
ivty1 = data1.ivty
#==== O3 ============
ivtx2 = data2.ivtx
ivty2 = data2.ivty
#==== PAN ==========
ivtx3 = data3.ivtx
ivty3 = data3.ivty

#=== 1000-60hpa
#===== CO ===========
ivtx4 = data4.ivtx
ivty4 = data4.ivty
#==== O3 ============
ivtx5 = data5.ivtx
ivty5 = data5.ivty
#==== PAN ==========
ivtx6 = data6.ivtx
ivty6 = data6.ivty

#==== Get lat and lon =========
lat = data1.lat
lon = data1.lon



#========= Calculate Integrated Gas Transport  ========
#== 1000-700hpa
igt1  = sqrt(ivtx1**2+ivty1**2)
igt2  = sqrt(ivtx2**2+ivty2**2)
igt3  = sqrt(ivtx3**2+ivty3**2)
#=== 700-60hpa
igt4  = sqrt(ivtx4**2+ivty4**2)
igt5  = sqrt(ivtx5**2+ivty5**2)
igt6  = sqrt(ivtx6**2+ivty6**2)


#===== NOW CALCULAT igt ========
igt_co  = (igt1/igt4)*100
igt_o3  = (igt2/igt5)*100
igt_pan = (igt3/igt6)*100


#=== Resmaple monthly===
co_mon  = igt_co.resample(time="1M").mean()
o3_mon  = igt_o3.resample(time="1M").mean()
pan_mon = igt_pan.resample(time="1M").mean()
#========= Seasonal mean ==========================
co_sea  = co_mon.groupby("time.season").mean("time")
o3_sea  = o3_mon.groupby("time.season").mean("time")
pan_sea = pan_mon.groupby("time.season").mean("time")
#====== slice out seasona =================================
#== CO
win_co = co_sea.isel(season=0)
spr_co = co_sea.isel(season=2)
sum_co = co_sea.isel(season=1)
aut_co = co_sea.isel(season=3)
#=== O3
win_o3 = o3_sea.isel(season=0)
spr_o3 = o3_sea.isel(season=2)
sum_o3 = o3_sea.isel(season=1)
aut_o3 = o3_sea.isel(season=3)
#===PAN
win_pan = pan_sea.isel(season=0)
spr_pan = pan_sea.isel(season=2)
sum_pan = pan_sea.isel(season=1)
aut_pan = pan_sea.isel(season=3)


"""Control font"""
matplotlib.rcParams['font.family'] = "sans-serif"
matplotlib.rcParams['font.sans-serif'] = "Times New Roman"

#===== plot ==============
#========== Setting Frame ======================
fig = plt.figure(figsize=(11, 9))
m = Basemap(projection='robin',lon_0=0,resolution='h', area_thresh=1500)
""" O3 """
#==Win
ax = fig.add_subplot(4,3,1)
x, y = m(*np.meshgrid(lon,lat))
s = m.pcolormesh(x,y,win_o3,cmap=cmaps.GMT_relief_oceanonly_r)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.3, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=9)
m.drawmeridians(range(0, 360, 60),    color='gray', linewidth=0.3, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=9)
m.drawcoastlines(linewidth=0.2)
plt.ylabel("DJF",fontsize=15,labelpad=5)
ax.set_title('$O_3$', fontsize=15, pad=5)
plt.clim(0,80)
#==Spr
ax = fig.add_subplot(4,3,4)
x, y = m(*np.meshgrid(lon,lat))
s = m.pcolormesh(x,y,spr_o3,cmap=cmaps.GMT_relief_oceanonly_r)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.3, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=9)
m.drawmeridians(range(0, 360, 60),    color='gray', linewidth=0.3, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=9)
m.drawcoastlines(linewidth=0.2)
plt.ylabel("MAM",fontsize=15,labelpad=5)
plt.clim(0,80)
#==Sum
ax = fig.add_subplot(4,3,7)
x, y = m(*np.meshgrid(lon,lat))
s = m.pcolormesh(x,y,aut_o3,cmap=cmaps.GMT_relief_oceanonly_r)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.3, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=10)
m.drawmeridians(range(0, 360, 60),    color='gray', linewidth=0.3, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=10)
m.drawcoastlines(linewidth=0.2)
plt.ylabel("JJA",fontsize=15,labelpad=5)
plt.clim(0,80)
#==Aut
ax = fig.add_subplot(4,3,10)
x, y = m(*np.meshgrid(lon,lat))
s = m.pcolormesh(x,y,sum_o3,cmap=cmaps.GMT_relief_oceanonly_r)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.3, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=10)
m.drawmeridians(range(0, 360, 60),    color='gray', linewidth=0.3, dashes=[4, 4], labels=[0, 0, 0, 1],fontsize=10)
m.drawcoastlines(linewidth=0.2)
plt.ylabel("SON",fontsize=15,labelpad=5)
plt.clim(0,80)



""" CO """
#==Win
ax = fig.add_subplot(4,3,2)
x, y = m(*np.meshgrid(lon,lat))
s = m.pcolormesh(x,y,win_co,cmap=cmaps.GMT_relief_oceanonly_r)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.3, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=9)
m.drawmeridians(range(0, 360, 60),    color='gray', linewidth=0.3, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=9)
m.drawcoastlines(linewidth=0.2)
ax.set_title('CO', fontsize=15, pad=0)
plt.clim(0,80)
#==Spr
ax = fig.add_subplot(4,3,5)
x, y = m(*np.meshgrid(lon,lat))
s = m.pcolormesh(x,y,spr_co,cmap=cmaps.GMT_relief_oceanonly_r)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.3, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=9)
m.drawmeridians(range(0, 360, 60),    color='gray', linewidth=0.3, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=9)
m.drawcoastlines(linewidth=0.2)
plt.clim(0,80)
#==Sum
ax = fig.add_subplot(4,3,8)
x, y = m(*np.meshgrid(lon,lat))
s = m.pcolormesh(x,y,aut_co,cmap=cmaps.GMT_relief_oceanonly_r)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.3, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=9)
m.drawmeridians(range(0, 360, 60),    color='gray', linewidth=0.3, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=9)
m.drawcoastlines(linewidth=0.2)

plt.clim(0,80)
#==Aut
ax = fig.add_subplot(4,3,11)
x, y = m(*np.meshgrid(lon,lat))
s = m.pcolormesh(x,y,sum_co,cmap=cmaps.GMT_relief_oceanonly_r)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.3, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=9)
m.drawmeridians(range(0, 360, 60),    color='gray', linewidth=0.3, dashes=[4, 4], labels=[0, 0, 0, 1],fontsize=10)
m.drawcoastlines(linewidth=0.2)
plt.clim(0,80)


""" PAN """
#==Win
ax = fig.add_subplot(4,3,3)
x, y = m(*np.meshgrid(lon,lat))
s = m.pcolormesh(x,y,win_pan,cmap=cmaps.GMT_relief_oceanonly_r)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.3, dashes=[4, 4], labels=[0, 1, 0, 0],fontsize=10)
m.drawmeridians(range(0, 360, 60),    color='gray', linewidth=0.3, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=9)
m.drawcoastlines(linewidth=0.2)
ax.set_title('PAN', fontsize=15, pad=0)
plt.clim(0,80)
#==Spr
ax = fig.add_subplot(4,3,6)
x, y = m(*np.meshgrid(lon,lat))
s = m.pcolormesh(x,y,spr_pan,cmap=cmaps.GMT_relief_oceanonly_r)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.3, dashes=[4, 4], labels=[0, 1, 0, 0],fontsize=10)
m.drawmeridians(range(0, 360, 60),    color='gray', linewidth=0.3, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=9)
m.drawcoastlines(linewidth=0.2)

plt.clim(0,80)
#==Sum
ax = fig.add_subplot(4,3,9)
x, y = m(*np.meshgrid(lon,lat))
s = m.pcolormesh(x,y,aut_pan,cmap=cmaps.GMT_relief_oceanonly_r)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.3, dashes=[4, 4], labels=[0, 1, 0, 0],fontsize=10)
m.drawmeridians(range(0, 360, 60),    color='gray', linewidth=0.3, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=9)
m.drawcoastlines(linewidth=0.2)

plt.clim(0,80)
#==Aut
ax = fig.add_subplot(4,3,12)
x, y = m(*np.meshgrid(lon,lat))
s = m.pcolormesh(x,y,sum_pan,cmap=cmaps.GMT_relief_oceanonly_r)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.3, dashes=[4, 4], labels=[0, 1, 0, 0],fontsize=10)
m.drawmeridians(range(0, 360, 60),    color='gray', linewidth=0.3, dashes=[4, 4], labels=[0, 0, 0, 1],fontsize=10)
m.drawcoastlines(linewidth=0.2)
plt.clim(0,80)

#==== Add colorbar =============
divider = make_axes_locatable(ax)
cax = fig.add_axes([0.05, 0.05, 0.89, 0.015]) # [left, bottom, width, height]
cbar = fig.colorbar(s, cax=cax,orientation='horizontal',extend='both')
cbar.set_label('%',fontsize=12)
cbar.ax.tick_params(labelsize=12)
cbar.ax.minorticks_on()


fig.subplots_adjust(top=0.973,
                        bottom=0.07,
                        left=0.025,
                        right=0.97,
                        hspace=0.002,
                        wspace=0.008)

plt.savefig("surface_to_upper_IGT.png",dpi=600)
plt.savefig("surface_to_upper_IGT.tiff",dpi=200)
plt.show()

