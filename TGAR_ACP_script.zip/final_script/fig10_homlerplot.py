#====== import library ================
import numpy as np
import xarray as xr
from matplotlib import pyplot as plt
from numpy import sqrt
import geocat.viz as gv
import pandas as pd
import matplotlib
from mpl_toolkits.basemap import Basemap
import cmaps

"""=======Control font============================"""
matplotlib.rcParams['font.family'] = "sans-serif"
matplotlib.rcParams['font.sans-serif'] = "Times New Roman"
#========= Load data ===========================
df1 = xr.open_dataset("/Volumes/External_4TB/jpl_AR/2005_2019/co_2005_2019_vertmean_regrid.nc")
df2 = xr.open_dataset("/Volumes/External_4TB/jpl_AR/2005_2019/o3_2005_2019_1000_300hpa_vertmean.nc")
df3 = xr.open_dataset("/Volumes/External_4TB/jpl_AR/2005_2019/pan_2005_2019_vertmean_regrid.nc")
#===== Get data ====
co  = df1.co
o3  = df2.o3
pan = df3.pan
co  = co.mean(dim='lon')
o3  = o3.mean(dim='lon')
pan = pan.mean(dim='lon')
#======= Plot ==============
fig = plt.figure(figsize=(6, 8))
#====== o3 =================
ax = fig.add_subplot(3,1,1)
p = ax.pcolormesh(o3.time, o3.lat, o3.T, cmap=cmaps.MPL_RdBu_r,vmin=20,vmax=80)
gv.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=15)
ax.set_yticks([-90,-60,-30, 0, 30,60, 90])
#==== draw horizonatal line ======================
ax.axhline(y=30, color="gray", linestyle="--")
ax.axhline(y=0, color="black", linestyle="--")
ax.axhline(y=-30, color="gray", linestyle="--")
# Add a colorbar
cbar = plt.colorbar(p, ax=ax, orientation='vertical', pad=0.02,extend='both')
cbar.set_label('$O_3$',fontsize=15)
cbar.ax.tick_params(labelsize=15) 
cbar.ax.minorticks_on()
#====== co =================
ax = fig.add_subplot(3,1,2)
p = ax.pcolormesh(co.time, co.lat, co.T, cmap=cmaps.MPL_RdBu_r, vmin=20,vmax=100)
gv.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=15)
ax.set_yticks([-90,-60,-30, 0, 30,60, 90])
# Add a colorbar
cbar = plt.colorbar(p, ax=ax, orientation='vertical', pad=0.02,extend='both')
cbar.set_label('CO',fontsize=14)
cbar.ax.tick_params(labelsize=14) 
cbar.ax.minorticks_on()
ax.axhline(y=30, color="gray", linestyle="--")
ax.axhline(y=0, color="black", linestyle="--")
ax.axhline(y=-30, color="gray", linestyle="--")
#====== pan =================
ax = fig.add_subplot(3,1,3)
p = ax.pcolormesh(pan.time, pan.lat, pan.T, cmap=cmaps.MPL_RdBu_r,vmin=0,vmax=200)
gv.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=15)
ax.set_yticks([-90,-60,-30, 0, 30,60, 90])
# Add a colorbar
cbar = plt.colorbar(p, ax=ax, orientation='vertical', pad=0.02,extend='both')
cbar.set_label('PAN ',fontsize=14)
cbar.ax.tick_params(labelsize=14) 
cbar.ax.minorticks_on()
#==== draw horizonatal line ======================
ax.axhline(y=30, color="gray", linestyle="--")
ax.axhline(y=0, color="black", linestyle="--")
ax.axhline(y=-30, color="gray", linestyle="--")
fig.subplots_adjust(top=0.97,
            bottom=0.043,
            left=0.076,
            right=1,
            hspace=0.251,
            wspace=0.117)
plt.savefig('homler_new.png',  dpi=600)
plt.savefig('homler_new.tiff', dpi=200)
plt.show()