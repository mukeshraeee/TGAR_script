""" This script is for ploting 2005 Feb IGT
    Written by : Mukesh Rai
    Date : 2023/Mar/02
    Location: JPL """

#===== Import Libraries ========================
import matplotlib
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap
import numpy as np
import cmaps
from matplotlib.patches import Patch
from matplotlib.pyplot import figure
import matplotlib.gridspec as gridspec
import scipy.ndimage
from mpl_toolkits.axes_grid1 import make_axes_locatable
from matplotlib import rcParams
from numpy import sqrt
import xarray as xr
from mpl_toolkits.axes_grid1 import make_axes_locatable
from mplgrid import grid
from mpl_toolkits.axes_grid1 import make_axes_locatable
from mpl_toolkits.axes_grid1 import ImageGrid
import pandas as pd
from geocat.viz import util as gvutil
from matplotlib.ticker import MultipleLocator, FormatStrFormatter
from matplotlib import ticker
import matplotlib.lines as mlines
import netCDF4 as nc
from geocat.viz import util as gvutil
import matplotlib
import scipy as sp
import scipy.ndimage
import matplotlib as mpl


"""Control font"""
matplotlib.rcParams['font.family'] = "sans-serif"
matplotlib.rcParams['font.sans-serif'] = "Times New Roman"


#====== Create Dataframe  =========================
data_co  = []
data_o3  = []
data_pan = []

with open('/Volumes/External_4TB/jpl_AR/2005_2019/server_run/run_pixelarea_same/co/output/ar_co.txt') as f:
    # skip the first 13 rows
    for _ in range(13):
        next(f)
    # read the remaining lines
    for line in f:
        # split the line into columns
        columns = line.strip().split()
        # keep only columns 13 and 14
        desired_columns = [columns[4], columns[5]]
        # add the data to the list
        data_co.append(desired_columns)


#=================== O3 ==================================
with open('/Volumes/External_4TB/jpl_AR/2005_2019/server_run/run_pixelarea_same/o3/output/ar_o3.txt') as f:
    # skip the first 13 rows
    for _ in range(13):
        next(f)
    # read the remaining lines
    for line in f:
        # split the line into columns
        columns = line.strip().split()
        # keep only columns 13 and 14
        desired_columns = [columns[4], columns[5]]
        # add the data to the list
        data_o3.append(desired_columns)


#============== PAN ==================================================
with open('/Volumes/External_4TB/jpl_AR/2005_2019/server_run/run_pixelarea_same/pan/output/ar_pan.txt') as f:
    # skip the first 13 rows
    for _ in range(13):
        next(f)
    # read the remaining lines
    for line in f:
        # split the line into columns
        columns = line.strip().split()
        # keep only columns 13 and 14
        desired_columns = [columns[4], columns[5]]
        # add the data to the list
        data_pan.append(desired_columns)



df_co  = pd.DataFrame(data_co, columns=['length', 'width'])
df_o3  = pd.DataFrame(data_o3, columns=['length', 'width'])
df_pan = pd.DataFrame(data_pan, columns=['length', 'width'])


#====== CO ======================
l_co = df_co['length']
w_co = df_co['width']

#===== O3 =======================
l_o3 = df_o3['length']
w_o3 = df_o3['width']

#===== PAN =======================
l_pan = df_pan['length']
w_pan = df_pan['width']


#============ Conver to Numeric ==================
l_co = pd.to_numeric(l_co, errors='coerce')
w_co = pd.to_numeric(w_co, errors='coerce')

l_o3 = pd.to_numeric(l_o3, errors='coerce')
w_o3 = pd.to_numeric(w_o3, errors='coerce')

l_pan = pd.to_numeric(l_pan, errors='coerce')
w_pan = pd.to_numeric(w_pan, errors='coerce')


#===== lenght width ratio =======
lw_co = l_co/w_co
lw_o3 = l_o3/w_o3
lw_pan = l_pan/w_pan


#=== calculate median =====
l_co_med  = np.median(l_co)
l_o3_med  = np.median(l_o3)
l_pan_med = np.median(l_pan)

w_co_med  = np.median(w_co)
w_o3_med  = np.median(w_o3)
w_pan_med = np.median(w_pan)

lw_co_med  = np.median(lw_co)
lw_o3_med  = np.median(lw_o3)
lw_pan_med = np.median(lw_pan)



#=== calculate binss using Freedman–Diaconis method ==================
#=== CO ============
l25_co, l75_co = np.percentile(l_co, [15, 85])
l1 = 2 * (l75_co - l25_co) * len(l_co) ** (-1/3)
l1 = round((l_co.max() - l_co.min()) / l1)

w25_co, w75_co = np.percentile(w_co, [15, 85])
w1 = 2 * (w75_co - w25_co) * len(w_co) ** (-1/3)
w1 = round((w_co.max() - w_co.min()) / w1)

#===== O3 ==========
l25_o, l75_o = np.percentile(l_o3, [15, 85])
l2 = 2 * (l75_o - l25_o) * len(l_o3) ** (-1/3)
l2 = round((l_o3.max() - l_o3.min()) / l2)

w25_o, w75_o = np.percentile(w_o3, [15, 85])
w2 = 2 * (w75_o - w25_o) * len(w_o3) ** (-1/3)
w2 = round((w_o3.max() - w_o3.min()) / w2)

#===== PAN ==========
l25_p, l75_p = np.percentile(l_pan, [15, 85])
l3 = 2 * (l75_p - l25_p) * len(l_pan) ** (-1/3)
l3 = round((l_pan.max() - l_pan.min()) / l3)

w25_p, w75_p = np.percentile(w_pan, [15, 85])
w3 = 2 * (w75_p - w25_p) * len(w_pan) ** (-1/3)
w3 = round((w_pan.max() - w_pan.min()) / w3)


#=== length width ratio ===
lw25_co, lw75_co = np.percentile(lw_co, [15, 85])
lw1 = 2 * (lw75_co - lw25_co) * len(lw_co) ** (-1/3)
lw1 = round((lw_co.max() - lw_co.min()) / lw1)

lw25_co, lw75_co = np.percentile(lw_o3, [15, 85])
lw2 = 2 * (lw75_co - lw25_co) * len(lw_o3) ** (-1/3)
lw2 = round((lw_o3.max() - lw_o3.min()) / lw2)

#===== O3 ==========
lw25_o, lw75_o = np.percentile(lw_pan, [15, 85])
lw3 = 2 * (lw75_o - lw25_o) * len(lw_pan) ** (-1/3)
lw3 = round((lw_pan.max() - lw_pan.min()) / lw3)


#========= plot ==============================================
fig = plt.figure(figsize=(10, 8))

""" == Plot O3 ============="""
#== Lenth
ax1 = plt.subplot(3,3,1)
ax1.hist(l_o3 ,rwidth=0.8, bins=l2,label = 'L_O3',zorder=5,color='#36454F')
ax1.set_title('$O_3$', fontsize=15, pad=10)

#=== set x and y limit
plt.xlim(1500,20000,5000)
plt.ylim(0,12000,2000)

#===== width 
ax2 = plt.subplot(3,3,4)
ax2.hist(w_o3 ,rwidth=0.8, bins=w2,label = 'W_O3',zorder=5,color='#36454F')

#=== set x and y limit
plt.xlim(250,2500,500)
plt.ylim(0,12000,2000)

#===== ratio =========
ax3 = plt.subplot(3,3,7)
ax3.hist(lw_o3 ,rwidth=0.8, bins=lw2,label = 'W_O3',zorder=5,color='#36454F')

#=== set x and y limit
plt.xlim(0,25,5)
plt.ylim(0,12000,2000)

""" == Plot CO ============="""
#== Lenth
ax4 = plt.subplot(3,3,2)
ax4.hist(l_co ,rwidth=0.8, bins=l2,label = 'L_O3',zorder=5,color='#36454F')
ax4.set_title('CO', fontsize=15, pad=10)

#=== set x and y limit
plt.xlim(1500,20000,5000)
plt.ylim(0,12000,4000)
#===== width 
ax5 = plt.subplot(3,3,5)
ax5.hist(w_co ,rwidth=0.8, bins=w2,label = 'W_O3',zorder=5,color='#36454F')

#=== set x and y limit
plt.xlim(250,2500,500)
plt.ylim(0,15000,5000)


#===== ratio =========
ax6 = plt.subplot(3,3,8)
ax6.hist(lw_co ,rwidth=0.8, bins=lw2,label = 'W_O3',zorder=5,color='#36454F')

#=== set x and y limit
plt.xlim(0,25,5)
plt.ylim(0,12000,2000)


""" == Plot PAN ============="""
#== Lenth
ax7 = plt.subplot(3,3,3)
ax7.hist(l_pan ,rwidth=0.8, bins=l2,label = 'L_O3',zorder=5,color='#36454F')
ax7.set_title('PAN', fontsize=15, pad=10)

#=== set x and y limit
plt.xlim(1500,20000,5000)
plt.ylim(0,12000,4000)
#===== width 
ax8 = plt.subplot(3,3,6)
ax8.hist(w_pan ,rwidth=0.8, bins=w2,label = 'W_O3',zorder=5,color='#36454F')
#=== set x and y limit
plt.xlim(250,2500,500)
plt.ylim(0,15000,5000)
#=====ratio =========
ax9 = plt.subplot(3,3,9)
ax9.hist(lw_pan ,rwidth=0.8, bins=lw2,label = 'W_O3',zorder=5,color='#36454F')
#=== set x and y limit
plt.xlim(0,25,5)
plt.ylim(0,12000,5000)

#== remove y-tick
ax4.set_yticklabels([])
ax5.set_yticklabels([])
ax6.set_yticklabels([])
ax7.set_yticklabels([])
ax8.set_yticklabels([])
ax9.set_yticklabels([])


#=== now plot median value ==
ax1.axvline(l_co_med, color='red', linestyle='dashed', linewidth=1,zorder=5)
ax2.axvline(w_co_med, color='red', linestyle='dashed', linewidth=1,zorder=5)
ax3.axvline(lw_co_med, color='red', linestyle='dashed', linewidth=1,zorder=5)

ax4.axvline(l_o3_med, color='red', linestyle='dashed', linewidth=1,zorder=5)
ax5.axvline(w_o3_med, color='red', linestyle='dashed', linewidth=1,zorder=5)
ax6.axvline(lw_o3_med, color='red', linestyle='dashed', linewidth=1,zorder=5)

ax7.axvline(l_pan_med, color='red', linestyle='dashed', linewidth=1,zorder=5)
ax8.axvline(w_pan_med, color='red', linestyle='dashed', linewidth=1,zorder=5)
ax9.axvline(lw_pan_med, color='red', linestyle='dashed', linewidth=1,zorder=5)

#=== Customize tick label == 
gvutil.add_major_minor_ticks(ax1,x_minor_per_major=3,y_minor_per_major=3,labelsize=12)
gvutil.add_major_minor_ticks(ax2,x_minor_per_major=3,y_minor_per_major=3,labelsize=12)
gvutil.add_major_minor_ticks(ax3,x_minor_per_major=3,y_minor_per_major=3,labelsize=12)

gvutil.add_major_minor_ticks(ax4,x_minor_per_major=3,y_minor_per_major=3,labelsize=12)
gvutil.add_major_minor_ticks(ax5,x_minor_per_major=3,y_minor_per_major=3,labelsize=12)
gvutil.add_major_minor_ticks(ax6,x_minor_per_major=3,y_minor_per_major=3,labelsize=12)

gvutil.add_major_minor_ticks(ax7,x_minor_per_major=3,y_minor_per_major=3,labelsize=12)
gvutil.add_major_minor_ticks(ax8,x_minor_per_major=3,y_minor_per_major=3,labelsize=12)
gvutil.add_major_minor_ticks(ax9,x_minor_per_major=3,y_minor_per_major=3,labelsize=12)

ax1.set_xlabel('Length [km]', fontsize=15)
ax2.set_xlabel('Width [km]', fontsize=15)
ax3.set_xlabel('Length/Width Ratio', fontsize=15)

ax4.set_xlabel('Length [km]', fontsize=15)
ax5.set_xlabel('Width [km]', fontsize=15)
ax6.set_xlabel('Length/Width Ratio', fontsize=15)

ax7.set_xlabel('Length [km]', fontsize=15)
ax8.set_xlabel('Width [km]', fontsize=15)
ax9.set_xlabel('Length/Width Ratio', fontsize=15)

ax1.set_ylabel('TGAR numbers', fontsize=15)
ax2.set_ylabel('TGAR numbers', fontsize=15)
ax3.set_ylabel('TGAR numbers', fontsize=15)

fig.subplots_adjust(top=0.958,
                    bottom=0.075,
                    left=0.102,
                    right=0.977,
                    hspace=0.367,
                    wspace=0.132)

plt.savefig('fig3.png',dpi=1000)
plt.savefig('fig3.tiff',dpi=200)

plt.show()

