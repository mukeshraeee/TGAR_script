"""
This code plots the annual trend of vertically integrated trace gases concentration
such as CO, O3, PAN and significant level.

Date : 2023/May/10
By   : Mukesh Rai
LOC  : JPL office
"""

#======== Load libraries ======================
import numpy as np
import netCDF4 as nc
import matplotlib.pyplot as plt
import matplotlib
from mpl_toolkits.basemap import Basemap
from scipy.stats import pearsonr
import cmaps
import matplotlib.gridspec as gridspec

#======== Control font ======================
matplotlib.rcParams['font.family'] = "sans-serif"
matplotlib.rcParams['font.sans-serif'] = "Times New Roman"

#========= Load data ===========================
dataset1 = nc.Dataset('/Volumes/External_4TB/jpl_AR/2005_2019/co_2005_2019_vertmean_regrid_yearavg.nc')
dataset2 = nc.Dataset('/Volumes/External_4TB/jpl_AR/2005_2019/o3_2005_2019_1000_300hpa_vertmean_yearmean.nc')
dataset3 = nc.Dataset('/Volumes/External_4TB/jpl_AR/2005_2019/pan_2005_2019_vertmean_regrid_yearavg.nc')

#========== Get data =================
co = dataset1.variables['co'][:]
o3 = dataset2.variables['o3'][:]
pan = dataset3.variables['pan'][:]

#======= Get lat and lon =====================
lat = dataset1.variables['lat'][:]
lon = dataset1.variables['lon'][:]

#=============== plot setup ===============================
fig, axs = plt.subplots(1, 3, figsize=(4, 8), dpi=150)
gridspec.GridSpec(1, 3)
m = Basemap(projection='robin', lon_0=0, resolution='c')
x, y = m(*np.meshgrid(lon, lat))

#====== Reshape data =========================
def reshape_data(data):
    time, lat, lon = data.shape
    return np.reshape(data, (time, lat * lon))

data_reshaped1 = reshape_data(co)
data_reshaped2 = reshape_data(o3)
data_reshaped3 = reshape_data(pan)

#===== Calculate slopes and p-values ===========
def calculate_trends(data_reshaped, time):
    slopes = np.zeros(data_reshaped.shape[1])
    p_values = np.zeros(data_reshaped.shape[1])
    for i in range(data_reshaped.shape[1]):
        slopes[i], _ = np.polyfit(np.arange(time), data_reshaped[:, i], 1)
        _, p_values[i] = pearsonr(data_reshaped[:, i], np.arange(time))
    return slopes, p_values

time = co.shape[0]
slopes1, p_values1 = calculate_trends(data_reshaped1, time)
slopes2, p_values2 = calculate_trends(data_reshaped2, time)
slopes3, p_values3 = calculate_trends(data_reshaped3, time)

#==== Reshape slopes and p-values back to lat/lon dimensions ====
slopes1 = np.reshape(slopes1, (lat.size, lon.size))
slopes2 = np.reshape(slopes2, (lat.size, lon.size))
slopes3 = np.reshape(slopes3, (lat.size, lon.size))

p_values1 = np.reshape(p_values1, (lat.size, lon.size))
p_values2 = np.reshape(p_values2, (lat.size, lon.size))
p_values3 = np.reshape(p_values3, (lat.size, lon.size))

sig1 = np.where(p_values1 < 0.05)
sig2 = np.where(p_values2 < 0.05)
sig3 = np.where(p_values3 < 0.05)




def downsample_points(x, y, step=4):
    return x[::step], y[::step]

sig1_x, sig1_y = downsample_points(x[sig1], y[sig1])
sig2_x, sig2_y = downsample_points(x[sig2], y[sig2])
sig3_x, sig3_y = downsample_points(x[sig3], y[sig3])


def plot_trend(ax, slopes, sig_x, sig_y, title, clim, color_ticks, marker_size=0.02):
    ax = m.pcolormesh(x, y, slopes, cmap=cmaps.BlueWhiteOrangeRed)
    plt.clim(*clim)
    plt.title(title)
    cbar = fig.colorbar(ax, ticks=color_ticks, extend='both', orientation='horizontal')
    #cbar.ax.set_title('ppb/year', fontsize=12, pad=5)
    cbar.ax.tick_params(labelsize=10)
    cbar.ax.minorticks_on()
    m.scatter(sig_x, sig_y, marker='o', s=marker_size, c='#3B444B')
    m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.4, dashes=[4, 4], labels=[1, 0, 0, 0], fontsize=9)
    m.drawmeridians(range(0, 360, 60),    color='gray', linewidth=0.4, dashes=[4, 4], labels=[0, 0, 0, 1], fontsize=9)
    m.drawcountries(linewidth=0.2)
    m.drawcoastlines(linewidth=0.2)

# Downsample significant points
sig1_x, sig1_y = downsample_points(x[sig1], y[sig1])
sig2_x, sig2_y = downsample_points(x[sig2], y[sig2])
sig3_x, sig3_y = downsample_points(x[sig3], y[sig3])

#==== Plot CO, O3, PAN trends ===========

plt.subplot2grid((3, 1), (0, 0))
plot_trend(axs[1], slopes2, sig2_x, sig2_y, '$O_3$ Annual Trend', (0, 0.5), np.linspace(0, 0.5, 11), marker_size=0.1)


plt.subplot2grid((3, 1), (0, 1))
plot_trend(axs[0], slopes1, sig1_x, sig1_y, 'CO Annual Trend', (-0.6, 0.6), np.linspace(-1, 1, 11), marker_size=0.1)



plt.subplot2grid((3, 1), (0, 2))
plot_trend(axs[2], slopes3, sig3_x, sig3_y, 'PAN Annual Trend', (-1, 1), np.linspace(-1, 1, 11), marker_size=0.1)

fig.subplots_adjust(top=0.98, bottom=0.06, left=0.03, right=0.996, hspace=0.05, wspace=0.117)

plt.savefig('co_o3_pan_trend_1000_300hpa.png', dpi=600)
plt.savefig('co_o3_pan_trend_1000_300hpa.tiff', dpi=600)
plt.show()
