"""====== This code generates the total transport aacounted by TGARs ====
          Written by: Mukesh
          Date      : 2023/May/31/ Wednesday
          Location  : JPL Office ================ """
#======== load requires Libraries =============
import matplotlib
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap
import numpy as np
import cmaps
from matplotlib.patches import Patch
from matplotlib.pyplot import figure
import matplotlib.gridspec as gridspec
import scipy.ndimage
from mpl_toolkits.axes_grid1 import make_axes_locatable
from matplotlib import rcParams
from numpy import sqrt
import xarray as xr
from mpl_toolkits.axes_grid1 import make_axes_locatable
from mplgrid import grid
from mpl_toolkits.axes_grid1 import ImageGrid
import pandas as pd
from geocat.viz import util as gvutil
from matplotlib.ticker import MultipleLocator, FormatStrFormatter
from matplotlib import ticker
import matplotlib.lines as mlines
import math

"""Control font"""
matplotlib.rcParams['font.family'] = "sans-serif"
matplotlib.rcParams['font.sans-serif'] = "Times New Roman"

#============== Load data =========================
#igt1  = xr.open_dataset('/Users/mrai/mukesh_data/jpl_AR/2005_2019/2005_feb/experiment/co/igt_co_2005_feb_regrid.nc')
#igt1  = xr.open_dataset('/Users/mrai/mukesh_data/jpl_AR/2005_2019/2005_feb/experiment/o3/igt_o3_2005_feb_regrid.nc')
#igt1  = xr.open_dataset('/Users/mrai/mukesh_data/jpl_AR/2005_2019/2005_feb/experiment/pan/igt_pan_2005_feb_regrid.nc')

igt1  = xr.open_dataset('/Volumes/External_4TB/jpl_AR/2005_2019/igt_co_2005_2019_regrid.nc')
igt2  = xr.open_dataset('/Volumes/External_4TB/jpl_AR/2005_2019/igt_o3_2005_2019_regrid.nc')
igt3  = xr.open_dataset('/Volumes/External_4TB/jpl_AR/2005_2019/igt_pan_2005_2019_regrid.nc')

#==== Get lat and lon =========
lat = igt1.lat
lon = igt1.lon

""" === Calculate total IAT ====="""

#===== CO - total ===========
ivtx1_tot = igt1.ivtx
ivty1_tot = igt1.ivty
#===== O3 - total ===========
ivtx2_tot = igt2.ivtx
ivty2_tot = igt2.ivty
#===== PAN - total ===========
ivtx3_tot = igt3.ivtx
ivty3_tot = igt3.ivty



ivtx1_tot1 = np.sum(ivtx1_tot,axis=0)
ivty1_tot1 = np.sum(ivty1_tot,axis=0)

ivtx2_tot2 = np.sum(ivtx2_tot,axis=0)
ivty2_tot2 = np.sum(ivty2_tot,axis=0)

ivtx3_tot3 = np.sum(ivtx3_tot,axis=0)
ivty3_tot3 = np.sum(ivty3_tot,axis=0)

igt_tot1  = sqrt(ivtx1_tot1**2+ivty1_tot1**2)
igt_tot2  = sqrt(ivtx2_tot2**2+ivty2_tot2**2)
igt_tot3  = sqrt(ivtx3_tot3**2+ivty3_tot3**2)

igt_tot1 = (igt_tot1*6*3600)/15
igt_tot2 = (igt_tot2*6*3600)/15
igt_tot3 = (igt_tot3*6*3600)/15


igt_tot1=igt_tot1/10000
igt_tot2=igt_tot2/10000
igt_tot3=igt_tot3/100000


""" ========Plot  ==========="""
fig = plt.figure(figsize=(20, 5))
m = Basemap(projection='robin',lon_0=0,resolution='c')
x, y = m(*np.meshgrid(lon,lat))

"""===== Plot total transport CO ====="""
ax = plt.subplot(1,3,1)

ax = m.contourf(x,y,igt_tot1,cmap=cmaps.WhiteBlueGreenYellowRed,vmin=0, vmax=50, extend='both')
ax.set_clim([0, 50])
cbar = plt.colorbar(orientation='horizontal',pad=0.08,extend='both')
cbar.ax.set_title('Total CO transport [X $10^4$ $Kg m^{-1}$]',fontsize=12)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.3, dashes=[4, 4], labels = [1, 0, 0, 0],fontsize=15)
m.drawmeridians(range(0, 360, 60), color='gray',    linewidth=0.3, dashes=[4, 4],    labels = [0, 0, 1, 0],fontsize=15)
m.drawcountries(linewidth=0.2)
m.drawcoastlines(linewidth=0.2)

ax = plt.subplot(1,3,2)
ax = m.contourf(x,y,igt_tot2,cmap=cmaps.WhiteBlueGreenYellowRed,vmin=0, vmax=50, extend='both')
ax.set_clim([0, 50])
cbar = plt.colorbar(orientation='horizontal',pad=0.08,extend='both')
cbar.ax.set_title('Total $O_3$ transport [X $10^4$ $Kg m^{-1}$]',fontsize=12)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.3, dashes=[4, 4], labels = [0, 0, 0, 0],fontsize=15)
m.drawmeridians(range(0, 360, 60), color='gray',    linewidth=0.3, dashes=[4, 4],    labels = [0, 0, 1, 0],fontsize=15)
m.drawcountries(linewidth=0.2)
m.drawcoastlines(linewidth=0.2)


ax = plt.subplot(1,3,3)
ax = m.contourf(x,y,igt_tot3,cmap=cmaps.WhiteBlueGreenYellowRed,vmin=0, vmax=50, extend='both')
ax.set_clim([0, 50])
cbar = plt.colorbar(orientation='horizontal',pad=0.08,extend='both')
cbar.ax.set_title('Total PAN transport [X $10^5$ $Kg m^{-1}$]',fontsize=12)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.3, dashes=[4, 4], labels = [0, 1, 0, 0],fontsize=15)
m.drawmeridians(range(0, 360, 60), color='gray',    linewidth=0.3, dashes=[4, 4],    labels = [0, 0, 1, 0],fontsize=15)
m.drawcountries(linewidth=0.2)
m.drawcoastlines(linewidth=0.2)

#cbar.ax.set_title('Total_$O_3$ transport /w TGARs [$Kg m^{-1} s^{-1}$]',fontsize=12)
#cbar.ax.set_title('Total_PAN transport /w TGARs [X 10^1 $Kg m^{-1} s^{-1}$]',fontsize=10)


#plt.colorbar(orientation='horizontal',extend='both')
#plt.title('FRACTIONAL TGAR')

fig.subplots_adjust(top=1,
            bottom=0.03,
            left=0.022,
            right=0.98,
            hspace=0.045,
            wspace=0.01)


plt.savefig('total_transport_new2.tiff',dpi=300)
plt.savefig('total_transport_new2.png',dpi=300)
plt.show()

