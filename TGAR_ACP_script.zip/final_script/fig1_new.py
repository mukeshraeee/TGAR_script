

#===== Import Libraries ========================
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import cmaps
from matplotlib.patches import Patch
from matplotlib.pyplot import figure
import matplotlib.gridspec as gridspec
import scipy.ndimage
from mpl_toolkits.axes_grid1 import make_axes_locatable
from matplotlib import rcParams
from numpy import sqrt
import xarray as xr
from mpl_toolkits.axes_grid1 import make_axes_locatable
from mplgrid import grid
from mpl_toolkits.axes_grid1 import make_axes_locatable
from mpl_toolkits.axes_grid1 import ImageGrid
import pandas as pd
from geocat.viz import util as gvutil
from matplotlib.ticker import MultipleLocator, FormatStrFormatter
from matplotlib import ticker
import matplotlib.lines as mlines
from mpl_toolkits.basemap import Basemap

"""Control font"""
matplotlib.rcParams['font.family'] = "sans-serif"
matplotlib.rcParams['font.sans-serif'] = "Times New Roman"
#============== Load data  =========================
df1  = xr.open_dataset('/Volumes/External_4TB/jpl_AR/2005_2019/co_2005_2019_monavg_regrid.nc')
df2  = xr.open_dataset('/Volumes/External_4TB/jpl_AR/2005_2019/o3_2005_2019_monavg_regrid.nc')
df3  = xr.open_dataset('/Volumes/External_4TB/jpl_AR/2005_2019/pan_2005_2019_monavg_regrid.nc')
#===== Get data ====
co  = df1.co
o3  = df2.o3
pan = df3.pan
#====== Get level from =======
lev  = co.lev
"""== WEST COAST ==== """
co_wc  = co.sel(lat=slice(20, 60), lon=slice(-180, -120))
o3_wc  = o3.sel(lat=slice(20, 60), lon=slice(-180, -120))
pan_wc = pan.sel(lat=slice(20, 60), lon=slice(-180, -120))
"""== ATLANTIC OCEAN==="""
co_ao  = co.sel(lat=slice(20, 60), lon=slice(-60, 0))
o3_ao  = o3.sel(lat=slice(20, 60), lon=slice(-60, 0))
pan_ao = pan.sel(lat=slice(20, 60), lon=slice(-60, 0))
"""== ASIA ==="""
co_as  = co.sel(lat=slice(20, 70), lon=slice(50, 120))
o3_as  = o3.sel(lat=slice(20, 70), lon=slice(50, 120))
pan_as = pan.sel(lat=slice(20, 70), lon=slice(50, 120))
"""== EAST COAST ===== """
co_ec  = co.sel(lat=slice(20, 50), lon=slice(120, 180))
o3_ec  = o3.sel(lat=slice(20, 50), lon=slice(120, 180))
pan_ec = pan.sel(lat=slice(20, 50), lon=slice(120, 180))
"""== SOUTH WEST ==="""
co_sw  = co.sel(lat=slice(-60, -30), lon=slice(-180,-30))
o3_sw  = o3.sel(lat=slice(-60, -30), lon=slice(-180,-30))
pan_sw = pan.sel(lat=slice(-60, -30), lon=slice(-180,-30))
"""== SOUTH EAST ==="""
co_se  = co.sel(lat=slice(-60, -20), lon=slice(0, 180))
o3_se  = o3.sel(lat=slice(-60, -20), lon=slice(0, 180))
pan_se = pan.sel(lat=slice(-60, -20), lon=slice(0, 180))
#=========== Now group by seasons ==========================
#==== west cost ==
co_wc   = co_wc.groupby("time.season").mean("time")
o3_wc   = o3_wc.groupby("time.season").mean("time")
pan_wc  = pan_wc.groupby("time.season").mean("time")
#==== atlantic ocean ==
co_ao   = co_ao.groupby("time.season").mean("time")
o3_ao   = o3_ao.groupby("time.season").mean("time")
pan_ao  = pan_ao.groupby("time.season").mean("time")
#==== asia ==
co_as   = co_as.groupby("time.season").mean("time")
o3_as   = o3_as.groupby("time.season").mean("time")
pan_as  = pan_as.groupby("time.season").mean("time")
#==== east cost ==
co_ec   = co_ec.groupby("time.season").mean("time")
o3_ec   = o3_ec.groupby("time.season").mean("time")
pan_ec  = pan_ec.groupby("time.season").mean("time")
#==== south west ==
co_sw   = co_sw.groupby("time.season").mean("time")
o3_sw   = o3_sw.groupby("time.season").mean("time")
pan_sw  = pan_sw.groupby("time.season").mean("time")
#==== south east ==
co_se   = co_se.groupby("time.season").mean("time")
o3_se   = o3_se.groupby("time.season").mean("time")
pan_se  = pan_se.groupby("time.season").mean("time")
#========= Now select the seasons ========================
""" WEST COST """
#======= CO =====================
co_wc_win = co_wc.isel(season=0) # winter
co_wc_sum = co_wc.isel(season=1) # summer
co_wc_spr = co_wc.isel(season=2) # spring
co_wc_aut = co_wc.isel(season=3) # autumn
#======= O3 =====================
o3_wc_win = o3_wc.isel(season=0) # winter
o3_wc_sum = o3_wc.isel(season=1) # summer
o3_wc_spr = o3_wc.isel(season=2) # spring
o3_wc_aut = o3_wc.isel(season=3) # autumn
#======= PAN =====================
pan_wc_win = pan_wc.isel(season=0) # winter
pan_wc_sum = pan_wc.isel(season=1) # summer
pan_wc_spr = pan_wc.isel(season=2) # spring
pan_wc_aut = pan_wc.isel(season=3) # autumn
""" atlantic ocean """
#======= CO =====================
co_ao_win = co_ao.isel(season=0) # winter
co_ao_sum = co_ao.isel(season=1) # summer
co_ao_spr = co_ao.isel(season=2) # spring
co_ao_aut = co_ao.isel(season=3) # autumn
#======= O3 =====================
o3_ao_win = o3_ao.isel(season=0) # winter
o3_ao_sum = o3_ao.isel(season=1) # summer
o3_ao_spr = o3_ao.isel(season=2) # spring
o3_ao_aut = o3_ao.isel(season=3) # autumn
#======= PAN =====================
pan_ao_win = pan_ao.isel(season=0) # winter
pan_ao_sum = pan_ao.isel(season=1) # summer
pan_ao_spr = pan_ao.isel(season=2) # spring
pan_ao_aut = pan_ao.isel(season=3) # autumn
""" asia  """
#======= CO =====================
co_as_win = co_as.isel(season=0) # winter
co_as_sum = co_as.isel(season=1) # summer
co_as_spr = co_as.isel(season=2) # spring
co_as_aut = co_as.isel(season=3) # autumn
#======= O3 =====================
o3_as_win = o3_as.isel(season=0) # winter
o3_as_sum = o3_as.isel(season=1) # summer
o3_as_spr = o3_as.isel(season=2) # spring
o3_as_aut = o3_as.isel(season=3) # autumn
#======= PAN =====================
pan_as_win = pan_as.isel(season=0) # winter
pan_as_sum = pan_as.isel(season=1) # summer
pan_as_spr = pan_as.isel(season=2) # spring
pan_as_aut = pan_as.isel(season=3) # autumn
""" EAST COAST """
#======= CO =====================
co_ec_win = co_ec.isel(season=0) # winter
co_ec_sum = co_ec.isel(season=1) # summer
co_ec_spr = co_ec.isel(season=2) # spring
co_ec_aut = co_ec.isel(season=3) # autumn
#======= O3 =====================
o3_ec_win = o3_ec.isel(season=0) # winter
o3_ec_sum = o3_ec.isel(season=1) # summer
o3_ec_spr = o3_ec.isel(season=2) # spring
o3_ec_aut = o3_ec.isel(season=3) # autumn
#====== PAN =====================
pan_ec_win = pan_ec.isel(season=0) # winter
pan_ec_sum = pan_ec.isel(season=1) # summer
pan_ec_spr = pan_ec.isel(season=2) # spring
pan_ec_aut = pan_ec.isel(season=3) # autumn
""" south west  """
#======= CO =====================
co_sw_win = co_sw.isel(season=0) # winter
co_sw_sum = co_sw.isel(season=1) # summer
co_sw_spr = co_sw.isel(season=2) # spring
co_sw_aut = co_sw.isel(season=3) # autumn
#======= O3 =====================
o3_sw_win = o3_sw.isel(season=0) # winter
o3_sw_sum = o3_sw.isel(season=1) # summer
o3_sw_spr = o3_sw.isel(season=2) # spring
o3_sw_aut = o3_sw.isel(season=3) # autumn
#======= PAN =====================
pan_sw_win = pan_sw.isel(season=0) # winter
pan_sw_sum = pan_sw.isel(season=1) # summer
pan_sw_spr = pan_sw.isel(season=2) # spring
pan_sw_aut = pan_sw.isel(season=3) # autumn
""" south east  """
#======= CO =====================
co_se_win = co_se.isel(season=0) # winter
co_se_sum = co_se.isel(season=1) # summer
co_se_spr = co_se.isel(season=2) # spring
co_se_aut = co_se.isel(season=3) # autumn
#======= O3 =====================
o3_se_win = o3_se.isel(season=0) # winter
o3_se_sum = o3_se.isel(season=1) # summer
o3_se_spr = o3_se.isel(season=2) # spring
o3_se_aut = o3_se.isel(season=3) # autumn
#======= PAN =====================
pan_se_win = pan_se.isel(season=0) # winter
pan_se_sum = pan_se.isel(season=1) # summer
pan_se_spr = pan_se.isel(season=2) # spring
pan_se_aut = pan_se.isel(season=3) # autumn


"""======== Now take Zonal Average ========="""
"""=========== WEST COAST =================="""
#============ co ===============================
co_win_wc_av  = np.mean(co_wc_win,axis=1)      # lat
co_win_wc_av  = np.mean(co_win_wc_av,axis=1)   # lon

co_sum_wc_av  = np.mean(co_wc_sum,axis=1)
co_sum_wc_av  = np.mean(co_sum_wc_av,axis=1)

co_spr_wc_av  = np.mean(co_wc_spr,axis=1)
co_spr_wc_av  = np.mean(co_spr_wc_av,axis=1)

co_aut_wc_av  = np.mean(co_wc_aut,axis=1)
co_aut_wc_av  = np.mean(co_aut_wc_av,axis=1)

#============ o3  ===============================
o3_win_wc_av  = np.mean(o3_wc_win,axis=1)      # lat
o3_win_wc_av  = np.mean(o3_win_wc_av,axis=1)   # lon

o3_sum_wc_av  = np.mean(o3_wc_sum,axis=1)
o3_sum_wc_av  = np.mean(o3_sum_wc_av,axis=1)

o3_spr_wc_av  = np.mean(o3_wc_spr,axis=1)
o3_spr_wc_av  = np.mean(o3_spr_wc_av,axis=1)

o3_aut_wc_av  = np.mean(o3_wc_aut,axis=1)
o3_aut_wc_av  = np.mean(o3_aut_wc_av,axis=1)

#============ pan  ===============================
pan_win_wc_av  = np.mean(pan_wc_win,axis=1)      # lat
pan_win_wc_av  = np.mean(pan_win_wc_av,axis=1)   # lon

pan_sum_wc_av  = np.mean(pan_wc_sum,axis=1)
pan_sum_wc_av  = np.mean(pan_sum_wc_av,axis=1)

pan_spr_wc_av  = np.mean(pan_wc_spr,axis=1)
pan_spr_wc_av  = np.mean(pan_spr_wc_av,axis=1)

pan_aut_wc_av  = np.mean(pan_wc_aut,axis=1)
pan_aut_wc_av  = np.mean(pan_aut_wc_av,axis=1)

"""=========== Atlantic Ocean =================="""

#============ co ===============================
co_win_ao_av  = np.mean(co_ao_win,axis=1)      # lat
co_win_ao_av  = np.mean(co_win_ao_av,axis=1)   # lon

co_sum_ao_av  = np.mean(co_ao_sum,axis=1)
co_sum_ao_av  = np.mean(co_sum_ao_av,axis=1)

co_spr_ao_av  = np.mean(co_ao_spr,axis=1)
co_spr_ao_av  = np.mean(co_spr_ao_av,axis=1)

co_aut_ao_av  = np.mean(co_ao_aut,axis=1)
co_aut_ao_av  = np.mean(co_aut_ao_av,axis=1)

#============ o3  ===============================
o3_win_ao_av  = np.mean(o3_ao_win,axis=1)      # lat
o3_win_ao_av  = np.mean(o3_win_ao_av,axis=1)   # lon

o3_sum_ao_av  = np.mean(o3_ao_sum,axis=1)
o3_sum_ao_av  = np.mean(o3_sum_ao_av,axis=1)

o3_spr_ao_av  = np.mean(o3_ao_spr,axis=1)
o3_spr_ao_av  = np.mean(o3_spr_ao_av,axis=1)

o3_aut_ao_av  = np.mean(o3_ao_aut,axis=1)
o3_aut_ao_av  = np.mean(o3_aut_ao_av,axis=1)

#============ pan  ===============================
pan_win_ao_av  = np.mean(pan_ao_win,axis=1)      # lat
pan_win_ao_av  = np.mean(pan_win_ao_av,axis=1)   # lon

pan_sum_ao_av  = np.mean(pan_ao_sum,axis=1)
pan_sum_ao_av  = np.mean(pan_sum_ao_av,axis=1)

pan_spr_ao_av  = np.mean(pan_ao_spr,axis=1)
pan_spr_ao_av  = np.mean(pan_spr_ao_av,axis=1)

pan_aut_ao_av  = np.mean(pan_ao_aut,axis=1)
pan_aut_ao_av  = np.mean(pan_aut_ao_av,axis=1)


"""=========== Asia =================="""

#============ co ===============================
co_win_as_av  = np.mean(co_as_win,axis=1)      # lat
co_win_as_av  = np.mean(co_win_as_av,axis=1)   # lon

co_sum_as_av  = np.mean(co_as_sum,axis=1)
co_sum_as_av  = np.mean(co_sum_as_av,axis=1)

co_spr_as_av  = np.mean(co_as_spr,axis=1)
co_spr_as_av  = np.mean(co_spr_as_av,axis=1)

co_aut_as_av  = np.mean(co_as_aut,axis=1)
co_aut_as_av  = np.mean(co_aut_as_av,axis=1)

#============ o3  ===============================
o3_win_as_av  = np.mean(o3_as_win,axis=1)      # lat
o3_win_as_av  = np.mean(o3_win_as_av,axis=1)   # lon

o3_sum_as_av  = np.mean(o3_as_sum,axis=1)
o3_sum_as_av  = np.mean(o3_sum_as_av,axis=1)

o3_spr_as_av  = np.mean(o3_as_spr,axis=1)
o3_spr_as_av  = np.mean(o3_spr_as_av,axis=1)

o3_aut_as_av  = np.mean(o3_as_aut,axis=1)
o3_aut_as_av  = np.mean(o3_aut_as_av,axis=1)


#============ pan  ===============================
pan_win_as_av  = np.mean(pan_as_win,axis=1)      # lat
pan_win_as_av  = np.mean(pan_win_as_av,axis=1)   # lon

pan_sum_as_av  = np.mean(pan_as_sum,axis=1)
pan_sum_as_av  = np.mean(pan_sum_as_av,axis=1)

pan_spr_as_av  = np.mean(pan_as_spr,axis=1)
pan_spr_as_av  = np.mean(pan_spr_as_av,axis=1)

pan_aut_as_av  = np.mean(pan_as_aut,axis=1)
pan_aut_as_av  = np.mean(pan_aut_as_av,axis=1)



"""=========== EAST COAST =================="""

#============ co ===============================
co_win_ec_av  = np.mean(co_ec_win,axis=1)      # lat
co_win_ec_av  = np.mean(co_win_ec_av,axis=1)   # lon

co_sum_ec_av  = np.mean(co_ec_sum,axis=1)
co_sum_ec_av  = np.mean(co_sum_ec_av,axis=1)

co_spr_ec_av  = np.mean(co_ec_spr,axis=1)
co_spr_ec_av  = np.mean(co_spr_ec_av,axis=1)

co_aut_ec_av  = np.mean(co_ec_aut,axis=1)
co_aut_ec_av  = np.mean(co_aut_ec_av,axis=1)

#============ o3  ===============================
o3_win_ec_av  = np.mean(o3_ec_win,axis=1)      # lat
o3_win_ec_av  = np.mean(o3_win_ec_av,axis=1)   # lon

o3_sum_ec_av  = np.mean(o3_ec_sum,axis=1)
o3_sum_ec_av  = np.mean(o3_sum_ec_av,axis=1)

o3_spr_ec_av  = np.mean(o3_ec_spr,axis=1)
o3_spr_ec_av  = np.mean(o3_spr_ec_av,axis=1)

o3_aut_ec_av  = np.mean(o3_ec_aut,axis=1)
o3_aut_ec_av  = np.mean(o3_aut_ec_av,axis=1)


#============ pan  ===============================
pan_win_ec_av  = np.mean(pan_ec_win,axis=1)      # lat
pan_win_ec_av  = np.mean(pan_win_ec_av,axis=1)   # lon

pan_sum_ec_av  = np.mean(pan_ec_sum,axis=1)
pan_sum_ec_av  = np.mean(pan_sum_ec_av,axis=1)

pan_spr_ec_av  = np.mean(pan_ec_spr,axis=1)
pan_spr_ec_av  = np.mean(pan_spr_ec_av,axis=1)

pan_aut_ec_av  = np.mean(pan_ec_aut,axis=1)
pan_aut_ec_av  = np.mean(pan_aut_ec_av,axis=1)


"""=========== SOUTH WEST  =================="""

#============ co ===============================
co_win_sw_av  = np.mean(co_sw_win,axis=1)      # lat
co_win_sw_av  = np.mean(co_win_sw_av,axis=1)   # lon

co_sum_sw_av  = np.mean(co_sw_sum,axis=1)
co_sum_sw_av  = np.mean(co_sum_sw_av,axis=1)

co_spr_sw_av  = np.mean(co_sw_spr,axis=1)
co_spr_sw_av  = np.mean(co_spr_sw_av,axis=1)

co_aut_sw_av  = np.mean(co_sw_aut,axis=1)
co_aut_sw_av  = np.mean(co_aut_sw_av,axis=1)

#============ o3  ===============================
o3_win_sw_av  = np.mean(o3_sw_win,axis=1)      # lat
o3_win_sw_av  = np.mean(o3_win_sw_av,axis=1)   # lon

o3_sum_sw_av  = np.mean(o3_sw_sum,axis=1)
o3_sum_sw_av  = np.mean(o3_sum_sw_av,axis=1)

o3_spr_sw_av  = np.mean(o3_sw_spr,axis=1)
o3_spr_sw_av  = np.mean(o3_spr_sw_av,axis=1)

o3_aut_sw_av  = np.mean(o3_sw_aut,axis=1)
o3_aut_sw_av  = np.mean(o3_aut_sw_av,axis=1)


#============ pan  ===============================
pan_win_sw_av  = np.mean(pan_sw_win,axis=1)      # lat
pan_win_sw_av  = np.mean(pan_win_sw_av,axis=1)   # lon

pan_sum_sw_av  = np.mean(pan_sw_sum,axis=1)
pan_sum_sw_av  = np.mean(pan_sum_sw_av,axis=1)

pan_spr_sw_av  = np.mean(pan_sw_spr,axis=1)
pan_spr_sw_av  = np.mean(pan_spr_sw_av,axis=1)

pan_aut_sw_av  = np.mean(pan_sw_aut,axis=1)
pan_aut_sw_av  = np.mean(pan_aut_sw_av,axis=1)


"""=========== SOUTH EAST  =================="""

#============ co ===============================
co_win_se_av  = np.mean(co_se_win,axis=1)      # lat
co_win_se_av  = np.mean(co_win_se_av,axis=1)   # lon

co_sum_se_av  = np.mean(co_se_sum,axis=1)
co_sum_se_av  = np.mean(co_sum_se_av,axis=1)

co_spr_se_av  = np.mean(co_se_spr,axis=1)
co_spr_se_av  = np.mean(co_spr_se_av,axis=1)

co_aut_se_av  = np.mean(co_se_aut,axis=1)
co_aut_se_av  = np.mean(co_aut_se_av,axis=1)

#============ o3  ===============================
o3_win_se_av  = np.mean(o3_se_win,axis=1)      # lat
o3_win_se_av  = np.mean(o3_win_se_av,axis=1)   # lon

o3_sum_se_av  = np.mean(o3_se_sum,axis=1)
o3_sum_se_av  = np.mean(o3_sum_se_av,axis=1)

o3_spr_se_av  = np.mean(o3_se_spr,axis=1)
o3_spr_se_av  = np.mean(o3_spr_se_av,axis=1)

o3_aut_se_av  = np.mean(o3_se_aut,axis=1)
o3_aut_se_av  = np.mean(o3_aut_se_av,axis=1)


#============ pan  ===============================
pan_win_se_av  = np.mean(pan_se_win,axis=1)      # lat
pan_win_se_av  = np.mean(pan_win_se_av,axis=1)   # lon

pan_sum_se_av  = np.mean(pan_se_sum,axis=1)
pan_sum_se_av  = np.mean(pan_sum_se_av,axis=1)

pan_spr_se_av  = np.mean(pan_se_spr,axis=1)
pan_spr_se_av  = np.mean(pan_spr_se_av,axis=1)

pan_aut_se_av  = np.mean(pan_se_aut,axis=1)
pan_aut_se_av  = np.mean(pan_aut_se_av,axis=1)
###
n_steps = 3
co_win_wc_av          = pd.DataFrame(co_win_wc_av)
co_win_wc_av_mean     = co_win_wc_av.rolling(n_steps).mean()
co_win_wc_av_sd       = 3 * co_win_wc_av.rolling(n_steps).std()

#====== CO ==
co_win_lower  = (co_win_wc_av_mean-co_win_wc_av_sd)[0]
co_win_upper  = (co_win_wc_av_mean+co_win_wc_av_sd)[0]
###
#====== Now plot ================================
fig = plt.figure(figsize=(10, 8))
""" =======  O3 WINTER ==============="""
ax = fig.add_subplot(4,3,1)
ax.plot(o3_win_wc_av,lev, 'red', label='West Coast',linewidth=0.8)
ax.plot(o3_win_ao_av,lev, '#0093AF', label='Atlantic Ocean',linewidth=0.8)
ax.plot(o3_win_as_av,lev, 'blue', label='Asia',linewidth=0.8)
ax.plot(o3_win_ec_av,lev, '#3B444B', label='East Coast',linewidth=0.8)
ax.plot(o3_win_sw_av,lev, '#78184A', label='South West',linewidth=0.8)
ax.plot(o3_win_se_av,lev, '#FFB300', label='South East',linewidth=0.8)
plt.ylim(1000,0,200)
plt.xlim(0,100,25)
#===== Customize tick labels ====================
gvutil.set_titles_and_labels(ax,ylabel="DJF \n  [hPa]")
ax.set_title('$O_3$', fontsize=15, pad=10)
gvutil.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
ax.tick_params(axis='y', labelsize=12)
ax.tick_params(axis='x', labelsize=12)
ax.set_xticklabels([])
#ax.set_xticklabels([])
""" =======  O3 SPRING ==============="""
ax = fig.add_subplot(4,3,4)
ax.plot(o3_spr_wc_av,lev, 'red',linewidth=0.8)
ax.plot(o3_spr_ao_av,lev, '#0093AF',linewidth=0.8)
ax.plot(o3_spr_as_av,lev, 'blue',linewidth=0.8)
ax.plot(o3_spr_ec_av,lev, '#3B444B',linewidth=0.8)
ax.plot(o3_spr_sw_av,lev, '#78184A',linewidth=0.8)
ax.plot(o3_spr_se_av,lev, '#FFB300',linewidth=0.8)
plt.ylim(1000,0,200)
plt.xlim(0,100,25)
ax.set_xticklabels([])
#===== Customize tick labels ====================
gvutil.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
gvutil.set_titles_and_labels(ax,ylabel="MAM \n  [hPa]")
ax.tick_params(axis='y', labelsize=12)
ax.tick_params(axis='x', labelsize=12)
#ax.set_yticklabels([])
ax.set_xticklabels([])
""" =======  O3 SUMMER==============="""
ax = fig.add_subplot(4,3,7)

ax.plot(o3_sum_wc_av,lev, 'red', label='West Coast',linewidth=0.8)
ax.plot(o3_sum_ao_av,lev, '#0093AF', label='Atlantic Ocean',linewidth=0.8)
ax.plot(o3_sum_as_av,lev, 'blue', label='Asia',linewidth=0.8)
ax.plot(o3_sum_ec_av,lev, '#3B444B', label='East Coast',linewidth=0.8)
ax.plot(o3_sum_sw_av,lev, '#78184A', label='South West',linewidth=0.8)
ax.plot(o3_sum_se_av,lev, '#FFB300', label='South East',linewidth=0.8)
#===== Customize tick labels ====================
gvutil.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
gvutil.set_titles_and_labels(ax,ylabel="JJA \n  [hPa]")
ax.tick_params(axis='y', labelsize=12)
ax.tick_params(axis='x', labelsize=12)
#ax.set_yticklabels([])
ax.set_xticklabels([])

plt.ylim(1000,0,200)
plt.xlim(0,100,25)

""" =======  O3 AUTUMN ==============="""
ax = fig.add_subplot(4,3,10)
ax.plot(o3_aut_wc_av,lev, 'red', label='West Coast',linewidth=0.8)
ax.plot(o3_aut_ao_av,lev, '#0093AF', label='Atlantic Ocean',linewidth=0.8)
ax.plot(o3_aut_as_av,lev, 'blue', label='Asia',linewidth=0.8)
ax.plot(o3_aut_ec_av,lev, '#3B444B', label='East Coast',linewidth=0.8)
ax.plot(o3_aut_sw_av,lev, '#78184A', label='South West',linewidth=0.8)
ax.plot(o3_aut_se_av,lev, '#FFB300', label='South East',linewidth=0.8)
#===== Customize tick labels ====================
gvutil.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
gvutil.set_titles_and_labels(ax,ylabel="SON \n  [hPa]")
ax.tick_params(axis='y', labelsize=12)
ax.tick_params(axis='x', labelsize=12)
#ax.set_yticklabels([])
plt.ylim(1000,0,200)
plt.xlim(0,100,25)

""" =======  CO WINTER ==============="""
ax = fig.add_subplot(4,3,2)
ax.plot(co_win_wc_av,lev, 'red', label='West Coast',linewidth=0.8)
ax.plot(co_win_ao_av,lev, '#0093AF', label='Atlantic Ocean',linewidth=0.8)
ax.plot(co_win_as_av,lev, 'blue',    label='Asia',linewidth=0.8)
ax.plot(co_win_ec_av,lev, '#3B444B', label='East Coast',linewidth=0.8)
ax.plot(co_win_sw_av,lev, '#78184A', label='South West',linewidth=0.8)
ax.plot(co_win_se_av,lev, '#FFB300', label='South East',linewidth=0.8)
plt.ylim(1000,0,200)
plt.xlim(0,400,100)
#===== Customize tick labels ====================
gvutil.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
ax.tick_params(axis='y', labelsize=10)
ax.tick_params(axis='x', labelsize=10)
ax.set_xticklabels([])
ax.set_yticklabels([])
ax.legend(loc="upper right",fontsize=10)
ax.set_title('CO', fontsize=15, pad=10)
""" =======  CO SPRING ==============="""
ax = fig.add_subplot(4,3,5)
ax.plot(co_spr_wc_av,lev, 'red',linewidth=0.8)
ax.plot(co_spr_ao_av,lev, '#0093AF',linewidth=0.8)
ax.plot(co_spr_as_av,lev, 'blue',linewidth=0.8)
ax.plot(co_spr_ec_av,lev, '#3B444B',linewidth=0.8)
ax.plot(co_spr_sw_av,lev, '#78184A',linewidth=0.8)
ax.plot(co_spr_se_av,lev, '#FFB300',linewidth=0.8)
plt.ylim(1000,0,200)
plt.xlim(0,400,100)
#===== Customize tick labels ====================
gvutil.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
ax.tick_params(axis='y', labelsize=10)
ax.tick_params(axis='x', labelsize=10)
ax.set_yticklabels([])
ax.set_xticklabels([])
plt.xlim(0,400,100)
""" =======  CO SUMMER==============="""
ax = fig.add_subplot(4,3,8)
ax.plot(co_sum_wc_av,lev, 'red', label='West Coast',linewidth=0.8)
ax.plot(co_sum_ao_av,lev, '#0093AF', label='Atlantic Ocean',linewidth=0.8)
ax.plot(co_sum_as_av,lev, 'blue', label='Asia',linewidth=0.8)
ax.plot(co_sum_ec_av,lev, '#3B444B', label='East Coast',linewidth=0.8)
ax.plot(co_sum_sw_av,lev, '#78184A', label='South West',linewidth=0.8)
ax.plot(co_sum_se_av,lev, '#FFB300', label='South East',linewidth=0.8)
#===== Customize tick labels ====================
gvutil.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
ax.tick_params(axis='y', labelsize=10)
ax.tick_params(axis='x', labelsize=10)
ax.set_yticklabels([])
ax.set_xticklabels([])
plt.ylim(1000,0,200)
plt.xlim(0,400,100)
""" =======  CO AUTUMN ==============="""
ax = fig.add_subplot(4,3,11)
ax.plot(co_aut_wc_av,lev, 'red', label='West Coast',linewidth=0.8)
ax.plot(co_aut_ao_av,lev, '#0093AF', label='Atlantic Ocean',linewidth=0.8)
ax.plot(co_aut_as_av,lev, 'blue', label='Asia',linewidth=0.8)
ax.plot(co_aut_ec_av,lev, '#3B444B', label='East Coast',linewidth=0.8)
ax.plot(co_aut_sw_av,lev, '#78184A', label='South West',linewidth=0.8)
ax.plot(co_aut_se_av,lev, '#FFB300', label='South East',linewidth=0.8)
#===== Customize tick labels ====================
gvutil.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
ax.tick_params(axis='y', labelsize=10)
ax.tick_params(axis='x', labelsize=10)
ax.set_yticklabels([])
plt.ylim(1000,0,200)
plt.xlim(0,400,100)

""" =======  PAN WINTER ==============="""
ax = fig.add_subplot(4,3,3)
ax.plot(pan_win_wc_av,lev, 'red', label='West Coast',linewidth=0.8)
ax.plot(pan_win_ao_av,lev, '#0093AF', label='Atlantic Ocean',linewidth=0.8)
ax.plot(pan_win_as_av,lev, 'blue', label='Asia',linewidth=0.8)
ax.plot(pan_win_ec_av,lev, '#3B444B', label='East Coast',linewidth=0.8)
ax.plot(pan_win_sw_av,lev, '#78184A', label='South West',linewidth=0.8)
ax.plot(pan_win_se_av,lev, '#FFB300', label='South East',linewidth=0.8)
plt.ylim(1000,0,200)
plt.xlim(0,400,100)
ax.set_xticklabels([])
ax.set_yticklabels([])
#===== Customize tick labels ====================
gvutil.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
ax.tick_params(axis='y', labelsize=10)
ax.tick_params(axis='x', labelsize=10)
ax.set_title('PAN', fontsize=15, pad=10)
""" =======  PAN SPRING ==============="""
ax = fig.add_subplot(4,3,6)
ax.plot(pan_spr_wc_av,lev, 'red',linewidth=0.8)
ax.plot(pan_spr_ao_av,lev, '#0093AF',linewidth=0.8)
ax.plot(pan_spr_as_av,lev, 'blue',linewidth=0.8)
ax.plot(pan_spr_ec_av,lev, '#3B444B',linewidth=0.8)
ax.plot(pan_spr_sw_av,lev, '#78184A',linewidth=0.8)
ax.plot(pan_spr_se_av,lev, '#FFB300',linewidth=0.8)
plt.ylim(1000,0,200)
plt.xlim(0,400,100)
#===== Customize tick labels ====================
gvutil.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
ax.tick_params(axis='y', labelsize=10)
ax.tick_params(axis='x', labelsize=10)
ax.set_yticklabels([])
ax.set_xticklabels([])
""" ======= PAN SUMMER==============="""
ax = fig.add_subplot(4,3,9)
ax.plot(pan_sum_wc_av,lev, 'red', label='West Coast',linewidth=0.8)
ax.plot(pan_sum_ao_av,lev, '#0093AF', label='Atlantic Ocean',linewidth=0.8)
ax.plot(pan_sum_as_av,lev, 'blue', label='Asia',linewidth=0.8)
ax.plot(pan_sum_ec_av,lev, '#3B444B', label='East Coast',linewidth=0.8)
ax.plot(pan_sum_sw_av,lev, '#78184A', label='South West',linewidth=0.8)
ax.plot(pan_sum_se_av,lev, '#FFB300', label='South East',linewidth=0.8)
#===== Customize tick labels ====================
gvutil.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
ax.tick_params(axis='y', labelsize=10)
ax.tick_params(axis='x', labelsize=10)
ax.set_yticklabels([])
ax.set_xticklabels([])
plt.ylim(1000,0,200)
plt.xlim(0,400,100)
""" =======  PAN AUTUMN ==============="""
ax = fig.add_subplot(4,3,12)
ax.plot(pan_aut_wc_av,lev, 'red', label='West Coast',linewidth=0.8)
ax.plot(pan_aut_ao_av,lev, '#0093AF', label='Atlantic Ocean',linewidth=0.8)
ax.plot(pan_aut_as_av,lev, 'blue', label='Asia',linewidth=0.8)
ax.plot(pan_aut_ec_av,lev, '#3B444B', label='East Coast',linewidth=0.8)
ax.plot(pan_aut_sw_av,lev, '#78184A', label='South West',linewidth=0.8)
ax.plot(pan_aut_se_av,lev, '#FFB300', label='South East',linewidth=0.8)
#===== Customize tick labels ====================
gvutil.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
ax.tick_params(axis='y', labelsize=10)
ax.tick_params(axis='x', labelsize=10)
ax.set_yticklabels([])
plt.ylim(1000,0,200)
plt.xlim(0,400,100)


fig.subplots_adjust(top=0.952,
                    bottom=0.037,
                    left=0.102,
                    right=0.977,
                    hspace=0.113,
                    wspace=0.135)

plt.savefig('f1.png',dpi=600)
plt.show()


