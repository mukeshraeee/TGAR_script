import matplotlib
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import numpy as np
import xarray as xr
import pandas as pd
import geocat.viz as gv
import cmaps
from numpy import sqrt
import pandas as pd
"""=======Control font============================"""
matplotlib.rcParams['font.family'] = "sans-serif"
matplotlib.rcParams['font.sans-serif'] = "Times New Roman"
#======== Load Concentration data =============================
df1 = xr.open_dataset("/Volumes/External_4TB/jpl_AR/2005_2019/o3_2005_2019_1000_300hpa_vertmean_regrid.nc")
df2 = xr.open_dataset("/Volumes/External_4TB/jpl_AR/2005_2019/co_2005_2019_vertmean_regrid.nc")
df3 = xr.open_dataset("/Volumes/External_4TB/jpl_AR/2005_2019/pan_2005_2019_vertmean_regrid.nc")

#======== Load IGT data =============================
dataset1 = xr.open_dataset('/Volumes/External_4TB/jpl_AR/2005_2019/igt_o3_2005_2019_1000_200_regrid.nc')
dataset2 = xr.open_dataset('/Volumes/External_4TB/jpl_AR/2005_2019/igt_co_2005_2019_regrid.nc')
dataset3 = xr.open_dataset('/Volumes/External_4TB/jpl_AR/2005_2019/igt_pan_2005_2019_regrid.nc')

#====== Get data Concentration data =========
o3  = df1.o3
co  = df2.co
pan = df3.pan


"""==== Atlantic =================================="""
#lat_slice = slice(40, 60)
#lon_slice = slice(-70, -10)

"""==== Pacific =================================="""
#lat_slice = slice(40, 55)
#lon_slice = slice(150, 180)

"""==== SH =================================="""
lat_slice = slice(-65, -45)
lon_slice = slice(-90, 90)



# Apply slicing to all datasets
o3  =  o3.sel(lat=lat_slice, lon=lon_slice)
co  = co.sel(lat=lat_slice, lon=lon_slice)
pan = pan.sel(lat=lat_slice, lon=lon_slice)


"""==== Gobal mean concentration over time ================================="""
o3_av  = np.mean(o3, axis=(1, 2))
co_av  = np.mean(co, axis=(1, 2))
pan_av = np.mean(pan, axis=(1, 2))
#=== resample === 
o3_av_re  = o3_av.resample(time='M').mean()
co_av_re  = co_av.resample(time='M').mean()
pan_av_re = pan_av.resample(time='M').mean()

#=== == Calculate monthly average and standard deviation =========

#====== Get ivtx and ivty from each file ===========
ivtx1 = dataset1.ivtx
ivty1 = dataset1.ivty

ivtx2 = dataset2.ivtx
ivty2 = dataset2.ivty

ivtx3 = dataset3.ivtx
ivty3 = dataset3.ivty



ivtx1 = ivtx1.sel(lat=lat_slice, lon=lon_slice)
ivty1 = ivty1.sel(lat=lat_slice, lon=lon_slice)
ivtx2 = ivtx2.sel(lat=lat_slice, lon=lon_slice)
ivty2 = ivty2.sel(lat=lat_slice, lon=lon_slice)
ivtx3 = ivtx3.sel(lat=lat_slice, lon=lon_slice)
ivty3 = ivty3.sel(lat=lat_slice, lon=lon_slice)

#========== Calculate IGT =================
o3_igt   = sqrt((ivtx1)**2+(ivty1)**2) 
co_igt   = sqrt((ivtx2)**2+(ivty2)**2) 
pan_igt  = sqrt((ivtx3)**2+(ivty3)**2) 
#==== Gobal mean concentration over time =================================
o3_igt_av  = np.mean(co_igt, axis=(1, 2))
co_igt_av  = np.mean(o3_igt, axis=(1, 2))
pan_igt_av = np.mean(pan_igt, axis=(1, 2))

#=== resample === 
o3_igt_av  = o3_igt_av.resample(time='M').mean()
co_igt_av  = co_igt_av.resample(time='M').mean()
pan_igt_av = pan_igt_av.resample(time='M').mean()



"""========== Now Plot======================================"""
# ++++++++++++++++++++++++ Global ++++++++++++++++++++++++++++++++++++

fig, axs = plt.subplots(3, 2, figsize=(10, 6))
# Choose a colormap
cmap = cmaps.BlueDarkRed18
years = range(2005, 2020)
norm = mcolors.Normalize(vmin=min(years), vmax=max(years))
colors = [cmap(norm(year)) for year in years]

# Define the data and labels for each subplot
conc_datasets = [o3_av_re, co_av_re, pan_av_re]
igt_datasets = [o3_igt_av, co_igt_av, pan_igt_av]
titles = ["O3", "CO", "PAN"]
units = ["ppb", "ppb", "ppt"]
igt_units = ["kg m⁻¹ s⁻¹", "kg m⁻¹ s⁻¹", "g m⁻¹ s⁻¹"]

for i, (conc_data, igt_data, title, unit, igt_unit) in enumerate(zip(conc_datasets, igt_datasets, titles, units, igt_units)):
    # Concentration plot (left column)
    ax = axs[i, 0]
    
    # Plot each year separately
    for year, color in zip(years, colors):
        year_data = conc_data.sel(time=str(year))
        ax.plot(year_data.time.dt.month, year_data.values, color=color, alpha=0.7, linewidth=2)
    
    # Calculate and plot the overall monthly average and standard deviation
    monthly_avg = conc_data.groupby("time.month").mean()
    monthly_std = conc_data.groupby("time.month").std()
    ax.plot(monthly_avg.month, monthly_avg.values, color='black', linewidth=2, label='2005-2019 Average')
    ax.fill_between(monthly_avg.month, 
                    monthly_avg - monthly_std, 
                    monthly_avg + monthly_std, 
                    color='gray', alpha=0.8, label='±1 σ') 
    # Customize the plot
    ax.set_ylabel(f'{title} \n({unit})', fontsize=14)
    if i == 0:
        ax.set_title('Southern Hemisphere Concentration', fontsize=14,pad=10)
    ax.set_xticks(range(1, 13))
    if i != 2:  # Remove x-axis labels for all but the last row
        ax.set_xticklabels([])
    ax.grid(True, linestyle='--', alpha=0.4)
    gv.add_major_minor_ticks(ax, x_minor_per_major=4, y_minor_per_major=5, labelsize=12)
    ax = axs[i, 1]
    
    # Plot each year separately
    for year, color in zip(years, colors):
        year_data = igt_data.sel(time=str(year))
        ax.plot(year_data.time.dt.month, year_data.values, color=color, alpha=0.7, linewidth=2)
    
    # Calculate and plot the overall monthly average and standard deviation
    monthly_avg = igt_data.groupby("time.month").mean()
    monthly_std = igt_data.groupby("time.month").std()
    ax.plot(monthly_avg.month, monthly_avg.values, color='black', linewidth=2, label='2005-2019 Average')
    ax.fill_between(monthly_avg.month, 
                    monthly_avg - monthly_std, 
                    monthly_avg + monthly_std, 
                    color='gray', alpha=0.5, label='±1 σ')
    
    # Customize the plot
    ax.set_ylabel(f'{title}', fontsize=14)
    if i == 0:
        ax.set_title('Southern Hemisphere IGT [$Kg m^{{-1}}s^{{-1}}$]', fontsize=14,pad=10)
    ax.set_xticks(range(1, 13))
    if i != 2:  # Remove x-axis labels for all but the last row
        ax.set_xticklabels([])
    ax.grid(True, linestyle='--', alpha=0.4)
    gv.add_major_minor_ticks(ax, x_minor_per_major=4, y_minor_per_major=5, labelsize=12)

# Add x-label and x-axis labels only to the bottom row
for ax in axs[-1, :]:
    #ax.set_xlabel('Month', fontsize=12)
    ax.set_xticklabels(['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'])

# Add a colorbar to the right of the subplots
"""cbar_ax = fig.add_axes([0.94, 0.05, 0.02, 0.9])  # [left, bottom, width, height]
sm = plt.cm.ScalarMappable(cmap=cmaps.cmp_b2r, norm=norm)
sm.set_array([])
cbar = fig.colorbar(sm, cax=cbar_ax, label='Year', ticks=years[::1])
cbar.set_label('Year', fontsize=12)"""

# Adjust the layout
fig.subplots_adjust(top=0.94,
                    bottom=0.055,
                    left=0.092,
                    right=0.926,
                    hspace=0.204,
                    wspace=0.301)

plt.savefig('fig10_sh.tiff',dpi=300)
plt.savefig('fig10_sh.png',dpi=600)
plt.show()

