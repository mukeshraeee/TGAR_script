""" ======= This code generates vertically integrated columnar trace gases concentrations=====
    Written by  Mukesh
    Location: JPL
    Time: 2023/03/17 """
    
 #====== import library ================
import numpy as np
import xarray as xr
from matplotlib import pyplot as plt
from numpy import sqrt
import geocat.viz as gv
import pandas as pd
import matplotlib
import matplotlib as mpl

"""=======Control font============================"""
matplotlib.rcParams['font.family'] = "sans-serif"
matplotlib.rcParams['font.sans-serif'] = "Times New Roman"
#========= Load Conc. data ===========================
df1 = xr.open_dataset("/Volumes/External_4TB/jpl_AR/2005_2019/co_2005_2019_vertmean.nc")
df2 = xr.open_dataset("/Volumes/External_4TB/jpl_AR/2005_2019/o3_2005_2019_1000_300hpa_vertmean_regrid.nc")
df3 = xr.open_dataset("/Volumes/External_4TB/jpl_AR/2005_2019/pan_2005_2019_vertmean_regrid.nc")
#===== IGT ===
ds1 = xr.open_dataset("/Volumes/External_4TB/jpl_AR/2005_2019/igt_co_2005_2019_regrid.nc")
ds2 = xr.open_dataset("/Volumes/External_4TB/jpl_AR/2005_2019/igt_o3_2005_2019_1000_200_regrid.nc")
ds3 = xr.open_dataset("/Volumes/External_4TB/jpl_AR/2005_2019/igt_pan_2005_2019_regrid.nc")



#===== Get data ====
co  = df1.co
o3  = df2.o3
pan = df3.pan

#====== CO
#co = co.resample(time='D').mean()
co = co.resample(time='M').mean()
#===== O3
#o3 = o3.resample(time='D').mean()
o3 = o3.resample(time='M').mean()
#====== PAN
#pan = pan.resample(time='D').mean()
pan = pan.resample(time='M').mean()


time = co.time


#======== IGT ===================================
#co
ivtx1 = ds1.ivtx
ivty1 = ds1.ivty
#o3
ivtx2 = ds2.ivtx
ivty2 = ds2.ivty
#pan
ivtx3 = ds3.ivtx
ivty3 = ds3.ivty

#==== igt calculation =========
igt1  = sqrt(ivtx1**2+ivty1**2) # CO
igt2  = sqrt(ivtx2**2+ivty2**2) # O3
igt3  = sqrt(ivtx3**2+ivty3**2) # PAN


#====== Resample  Daily ======================
#igt1  = igt1.resample(time='D').mean()
#igt2  = igt2.resample(time='D').mean()
#igt3  = igt3.resample(time='D').mean()
#====== mnothly ====================
igt1  = igt1.resample(time='M').mean()
igt2  = igt2.resample(time='M').mean()
igt3  = igt3.resample(time='M').mean()

#========== Take zonal average ==================
co   = co.mean(dim=['lat', 'lon'])
o3   = o3.mean(dim=['lat', 'lon'])
pan  = pan.mean(dim=['lat', 'lon'])

igt1   = igt1.mean(dim=['lat', 'lon'])
igt2   = igt2.mean(dim=['lat', 'lon'])
igt3   = igt3.mean(dim=['lat', 'lon'])

#================== Now take curve of interest ====================
n_steps     = 2

#====== CO ============================
co           = pd.DataFrame(co)
co_mean      = co.rolling(n_steps).mean()
co_sd        = 2* co.rolling(n_steps).std()
#====== O3 ============================
o3           = pd.DataFrame(o3)
o3_mean      = o3.rolling(n_steps).mean()
o3_sd        = 2 * o3.rolling(n_steps).std()
#======= PAN ==========================
pan           = pd.DataFrame(pan)
pan_mean      = pan.rolling(n_steps).mean()
pan_sd        = 2 * pan.rolling(n_steps).std()
#====== Upper and lower limit ==
co_lower  = (co_mean-co_sd)[0]
co_upper  = (co_mean+co_sd)[0]

o3_lower  = (o3_mean-o3_sd)[0]
o3_upper  = (o3_mean+o3_sd)[0]

pan_lower  = (pan_mean-pan_sd)[0]
pan_upper  = (pan_mean+pan_sd)[0]


#=====IGT ===
#====== CO ============================
igt1           = pd.DataFrame(igt1)
igt1_mean      = igt1.rolling(n_steps).mean()
igt1_sd        = 2* igt1.rolling(n_steps).std()
#====== O3 ============================
igt2           = pd.DataFrame(igt2)
igt2_mean      = igt2.rolling(n_steps).mean()
igt2_sd        = 2* igt2.rolling(n_steps).std()
#======= PAN ==========================
igt3           = pd.DataFrame(igt3)
igt3_mean      = igt3.rolling(n_steps).mean()
igt3_sd        = 2* igt3.rolling(n_steps).std()
#====== Upper and lower limit ==
igt1_lower  = (igt1_mean-igt1_sd)[0]
igt1_upper  = (igt1_mean+igt1_sd)[0]

igt2_lower  = (igt2_mean-igt2_sd)[0]
igt2_upper  = (igt2_mean+igt2_sd)[0]

igt3_lower  = (igt3_mean-igt3_sd)[0]
igt3_upper  = (igt3_mean+igt3_sd)[0]

#============== Now plot ==========================
#============== Now plot ==========================
fig = plt.figure(figsize=(5, 7))
"""# O3 subplot"""
ax = fig.add_subplot(3,1,1)
# Calculate O3 trend
time_numeric = np.arange(len(time))
o3_array = np.array(o3).flatten()
mask = ~np.isnan(o3_array)
z = np.polyfit(time_numeric[mask], o3_array[mask], 1)
p = np.poly1d(z)
o3_trend = p(time_numeric)
# Add trend value text
trend_value = z[0]
#ax.text(0.05, 0.95, f'Trend: {trend_value:.1e} ppb/day', 
#        transform=ax.transAxes, verticalalignment='top', 
#        fontsize=10, bbox=dict(facecolor='white', alpha=0.7))
# Plot O3 concentration and trend
p1 = ax.plot(time, o3, 'red', linewidth=1, label='Concentration')
ax.fill_between(time, o3_lower, o3_upper,  color='lightpink', alpha=0.5, zorder=0)
gv.add_major_minor_ticks(ax,x_minor_per_major=5,y_minor_per_major=4,labelsize=14)
ax1 = ax.twinx()
p2 = ax1.plot(time, igt2, 'blue', linewidth=1, label='IGT')
ax1.fill_between(time, igt2_lower, igt2_upper,  color='lightblue', alpha=0.5, zorder=1)
gv.set_titles_and_labels(ax,ylabel="$O_3$")
gv.set_titles_and_labels(ax1,ylabel="$O_3$-IGT")
ax.tick_params(axis='both',  which='major',  labelsize=12)
ax1.tick_params(axis='both', which='major', labelsize=12)
ax1.set_yticks(ax1.get_yticks(), minor=False)
ax1.set_yticks([], minor=True)
ax.set_xticks([], minor=True)
ax.plot(time, o3_trend, '#3B444B', linestyle='dashed', linewidth=2, label='O3 Trend')
ax.tick_params(axis='x', which='both', top=False)
ax.tick_params(axis='y', which='both', labelsize=12)
#ax.spines['top'].set_visible(False)
ax.spines['bottom'].set_visible(True) 
ax1.spines['top'].set_visible(False)

ax.set_ylim(35, 55)

#== insert label 
# Combine legend handles and labels
lines = p1 + p2 
labels = [l.get_label() for l in lines]
ax.legend(lines, labels, loc='upper left', fontsize=10)




"""# CO subplot"""
ax = fig.add_subplot(3,1,2)
# Calculate CO trend
co_array = np.array(co).flatten()  # Ensure co is a 1D array
mask = ~np.isnan(co_array)  # Create a mask for non-NaN values
z = np.polyfit(time_numeric[mask], co_array[mask], 1)
p = np.poly1d(z)
co_trend = p(time_numeric)
# Add trend value text
trend_value = z[0]
#ax.text(0.05, 0.95, f'Trend: {trend_value:.1e} ppb/day', 
#        transform=ax.transAxes, verticalalignment='top', 
#        fontsize=10, bbox=dict(facecolor='white', alpha=0.7))
# Plot CO concentration and trend
ax.plot(time, co, 'red', linewidth=1, label='Concentration')
ax.fill_between(time, co_lower, co_upper, color='lightpink', alpha=0.5, zorder=0)
gv.add_major_minor_ticks(ax,x_minor_per_major=5,y_minor_per_major=4,labelsize=14)
ax1 = ax.twinx()
ax1.plot(time, igt1, 'blue', linewidth=1,label='IGT')
ax1.fill_between(time, igt1_lower, igt1_upper,  color='lightblue', alpha=0.5, zorder=1)
gv.set_titles_and_labels(ax,ylabel="CO")
gv.set_titles_and_labels(ax1,ylabel="CO-IGT")
ax.set_xticks([], minor=True)
ax.plot(time, co_trend, '#3B444B', linestyle='dashed', linewidth=2, label='CO Trend')
ax1.spines['top'].set_visible(False)
ax.tick_params(axis='both', which='major', labelsize=12)
ax1.tick_params(axis='both', which='major', labelsize=12)
ax1.set_yticks(ax1.get_yticks(), minor=False)
ax1.set_yticks([], minor=True)
ax.tick_params(axis='x', which='both', top=False)
ax.spines['top'].set_visible(False)
ax.set_ylim(60, 85)


"""# PAN subplot"""
ax = fig.add_subplot(3,1,3)
# Calculate PAN trend
pan_array = np.array(pan).flatten()
mask = ~np.isnan(pan_array)
z = np.polyfit(time_numeric[mask], pan_array[mask], 1)
p = np.poly1d(z)
pan_trend = p(time_numeric)
# Add trend value text
trend_value = z[0]
#ax.text(0.05, 0.95, f'Trend: {trend_value:.1e} ppb/day', 
#        transform=ax.transAxes, verticalalignment='top', 
#        fontsize=10, bbox=dict(facecolor='white', alpha=0.7))
# Plot PAN concentration and trend
ax.plot(time, pan, 'red', linewidth=1, label='Concentration [ppb]')
ax.fill_between(time, pan_lower, pan_upper,  color='lightpink', alpha=0.5, zorder=0)
gv.add_major_minor_ticks(ax,x_minor_per_major=5,y_minor_per_major=4,labelsize=14)
ax1 = ax.twinx()
ax1.plot(time, igt3, 'blue', linewidth=1, label='IGT [$Kg m^{-1} s^{-1}$]')
ax1.fill_between(time, igt3_lower, igt3_upper,  color='lightblue', alpha=0.5, zorder=1)
gv.set_titles_and_labels(ax,ylabel="PAN")
gv.set_titles_and_labels(ax1,ylabel="PAN-IGT")
ax.spines['top'].set_visible(False)
ax.spines['bottom'].set_visible(True) 
ax1.spines['top'].set_visible(False)
ax.tick_params(axis='both', which='major', labelsize=12)
ax1.tick_params(axis='both', which='major', labelsize=12)
ax1.set_yticks(ax1.get_yticks(), minor=False)
ax1.set_yticks([], minor=True)
ax.set_xticks([], minor=True)
ax.plot(time, pan_trend, '#3B444B', linestyle='dashed', linewidth=2, label='PAN Trend')
ax.tick_params(axis='x', which='both', top=False)
ax.tick_params(axis='y', which='both', labelsize=12)
ax.set_ylim(80, 160)
# Adjust layout
fig.tight_layout()
fig.subplots_adjust(top=0.987,
            bottom=0.044,
            left=0.14,
            right=0.82,
            hspace=0.175,
            wspace=0.18)

plt.savefig('co_o3_pan.png',dpi=600)
plt.savefig('co_o3_pan.tiff',dpi=150)
plt.show()














































