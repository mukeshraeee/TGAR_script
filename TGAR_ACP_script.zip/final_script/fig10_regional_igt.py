""" ======= This code generates vertically integrated columnar trace gases concentrations and IGT =====
    Written by  Mukesh
    Location: JPL
    Time: 2023/03/17 """
    
#====== import library ================
import numpy as np
import xarray as xr
from matplotlib import pyplot as plt
from numpy import sqrt
import geocat.viz as gv
import pandas as pd
import matplotlib
from mpl_toolkits.basemap import Basemap
import cmaps

"""=======Control font============================"""
matplotlib.rcParams['font.family'] = "sans-serif"
matplotlib.rcParams['font.sans-serif'] = "Times New Roman"

#========= Load data ===========================
df1 = xr.open_dataset("/Volumes/External_4TB/jpl_AR/2005_2019/co_2005_2019_vertmean_regrid.nc")
df2 = xr.open_dataset("/Volumes/External_4TB/jpl_AR/2005_2019/o3_2005_2019_1000_300hpa_vertmean_regrid.nc")
df3 = xr.open_dataset("/Volumes/External_4TB/jpl_AR/2005_2019/pan_2005_2019_vertmean_regrid.nc")

#===== Get data ====
co  = df1.co
o3  = df2.o3
pan = df3.pan

#===== Load IGT data ==============================
ds1 = xr.open_dataset("/Volumes/External_4TB/jpl_AR/2005_2019/igt_co_2005_2019_monavg.nc")
ds2 = xr.open_dataset("/Volumes/External_4TB/jpl_AR/2005_2019/igt_o3_2005_2019_1000_200_regrid.nc")    #O3
ds3 = xr.open_dataset("/Volumes/External_4TB/jpl_AR/2005_2019/igt_pan_2005_2019_monavg.nc")   #PAN



#co
ivtx1 = ds1.ivtx
ivty1 = ds1.ivty
#o3
ivtx2 = ds2.ivtx
ivty2 = ds2.ivty
#pan
ivtx3 = ds3.ivtx
ivty3 = ds3.ivty

#==== igt calculation =========
igt1  = sqrt(ivtx1**2+ivty1**2) # CO
igt2  = sqrt(ivtx2**2+ivty2**2) # O3
igt3  = sqrt(ivtx3**2+ivty3**2) # PAN


""" Concentration """

#===== slice 30N-90N ====
df1   = co.sel(lat=slice(30, 90))
df2   = o3.sel(lat=slice(30, 90))
df3   = pan.sel(lat=slice(30, 90))

#===== slice 30S-30N ====
df4   = co.sel(lat=slice(-30, 30))
df5   = o3.sel(lat=slice(-30, 30))
df6   = pan.sel(lat=slice(-30, 30))

#===== slice 30S-90S ====
df7   = co.sel(lat=slice(-90, -30))
df8   = o3.sel(lat=slice(-90, -30))
df9   = pan.sel(lat=slice(-90, -30))


""" IGT """
#===== slice 30N-90N ====
df1_co    = igt1.sel(lat=slice(30, 90))
df2_o3    = igt2.sel(lat=slice(30, 90))
df3_pan   = igt3.sel(lat=slice(30, 90))

#===== slice 30S-30N ====
df4_co    = igt1.sel(lat=slice(-30, 30))
df5_o3    = igt2.sel(lat=slice(-30, 30))
df6_pan   = igt3.sel(lat=slice(-30, 30))

#===== slice 30S-90S ====
df7_co    = igt1.sel(lat=slice(-90, -30))
df8_o3    = igt2.sel(lat=slice(-90, -30))
df9_pan   = igt3.sel(lat=slice(-90, -30))



#============Zonal Average concentration ======
""" ====== CO ==============="""
co1 = df1.mean(dim='lon') #30N-90N
co2 = df4.mean(dim='lon') #30N-30S
co3 = df7.mean(dim='lon') #30S-90S

""" ====== O3 ==============="""
o1 = df2.mean(dim='lon') #30N-90N
o2 = df5.mean(dim='lon') #30N-30S
o3 = df8.mean(dim='lon') #30S-90S

""" ====== PAN ==============="""
pan1 = df3.mean(dim='lon') #30N-90N
pan2 = df6.mean(dim='lon') #30N-30S
pan3 = df9.mean(dim='lon') #30S-90S



#============Zonal Average IGT ======
""" ====== IGT - CO ==============="""
co1_igt = df1_co.mean(dim='lon') #30N-90N
co2_igt = df4_co.mean(dim='lon') #30N-30S
co3_igt = df7_co.mean(dim='lon') #30S-90S

""" ====== IGT - O3 ==============="""
o1_igt = df2_o3.mean(dim='lon') #30N-90N
o2_igt = df5_o3.mean(dim='lon') #30N-30S
o3_igt = df8_o3.mean(dim='lon') #30S-90S

""" ====== IGT - PAN ==============="""
pan1_igt = df3_pan.mean(dim='lon') #30N-90N
pan2_igt = df6_pan.mean(dim='lon') #30N-30S
pan3_igt = df9_pan.mean(dim='lon') #30S-90S


#====== Now resample for concentration ===============
#==== CO ========
#====== Daily ======================
#co1 = co1.resample(time='D').mean()
#co2 = co2.resample(time='D').mean()
#co3 = co3.resample(time='D').mean()
#====== mnothly ====================
co1 = co1.resample(time='M').mean()
co2 = co2.resample(time='M').mean()
co3 = co3.resample(time='M').mean()

time = co3.time
#==== O3 ========
#====== Daily ======================
#o1 = o1.resample(time='D').mean()
#o2 = o2.resample(time='D').mean()
#o3 = o3.resample(time='D').mean()
#====== Monthly ======================
o1 = o1.resample(time='M').mean()
o2 = o2.resample(time='M').mean()
o3 = o3.resample(time='M').mean()

#=== PAN ======
#====== Daily ======================
#pan1 = pan1.resample(time='D').mean()
#pan2 = pan2.resample(time='D').mean()
#pan3 = pan3.resample(time='D').mean()
#====== mnothly ====================
pan1 = pan1.resample(time='M').mean()
pan2 = pan2.resample(time='M').mean()
pan3 = pan3.resample(time='M').mean()



#====== Now resample for IGT ===============
#==== CO ========
#====== Daily ======================
#co1_igt = co1_igt.resample(time='D').mean()
#co2_igt = co2_igt.resample(time='D').mean()
#co3_igt = co3_igt.resample(time='D').mean()
#====== mnothly ====================
co1_igt = co1_igt.resample(time='M').mean()
co2_igt = co2_igt.resample(time='M').mean()
co3_igt = co3_igt.resample(time='M').mean()

time = co3.time
#==== O3 ========
#====== Daily ======================
#o1_igt = o1_igt.resample(time='D').mean()
#o2_igt = o2_igt.resample(time='D').mean()
#o3_igt = o3_igt.resample(time='D').mean()
#====== Monthly ======================
o1_igt = o1_igt.resample(time='M').mean()
o2_igt = o2_igt.resample(time='M').mean()
o3_igt = o3_igt.resample(time='M').mean()

#=== PAN ======
#====== Daily ======================
#pan1_igt = pan1_igt.resample(time='D').mean()
#pan2_igt = pan2_igt.resample(time='D').mean()
#pan3_igt = pan3_igt.resample(time='D').mean()
#====== mnothly ====================
pan1_igt = pan1_igt.resample(time='M').mean()
pan2_igt = pan2_igt.resample(time='M').mean()
pan3_igt = pan3_igt.resample(time='M').mean()


#===== Take latitudinal average  ======
co1 = np.average(co1, axis=1)
co2 = np.average(co2, axis=1)
co3 = np.average(co3, axis=1)

o1 = np.average(o1, axis=1)
o2 = np.average(o2, axis=1)
o3 = np.average(o3, axis=1)

pan1 = np.average(pan1, axis=1)
pan2 = np.average(pan2, axis=1)
pan3 = np.average(pan3, axis=1)


#===== Take latitudinal average  ======
co1_igt = np.average(co1_igt, axis=1)
co2_igt = np.average(co2_igt, axis=1)
co3_igt = np.average(co3_igt, axis=1)

o1_igt = np.average(o1_igt, axis=1)
o2_igt = np.average(o2_igt, axis=1)
o3_igt = np.average(o3_igt, axis=1)

pan1_igt = np.average(pan1_igt, axis=1)
pan2_igt = np.average(pan2_igt, axis=1)
pan3_igt = np.average(pan3_igt, axis=1)


""" ============ For Concentration ============="""
#======= Take area of interest curve ========
n_steps =2
#====== CO ============================
co1           = pd.DataFrame(co1)
co1_mean      = co1.rolling(n_steps).mean()
co1_sd        = 2 * co1.rolling(n_steps).std()

co2           = pd.DataFrame(co2)
co2_mean      = co2.rolling(n_steps).mean()
co2_sd        = 2 * co2.rolling(n_steps).std()

co3           = pd.DataFrame(co3)
co3_mean      = co3.rolling(n_steps).mean()
co3_sd        = 2 * co3.rolling(n_steps).std()

#====== O3 ============================
o1           = pd.DataFrame(o1)
o1_mean      = o1.rolling(n_steps).mean()
o1_sd        = 2 * o1.rolling(n_steps).std()

o2           = pd.DataFrame(o2)
o2_mean      = o2.rolling(n_steps).mean()
o2_sd        = 2 * o2.rolling(n_steps).std()


o3           = pd.DataFrame(o3)
o3_mean      = o3.rolling(n_steps).mean()
o3_sd        = 2 * o3.rolling(n_steps).std()


#======= PAN ==========================
pan1           = pd.DataFrame(pan1)
pan1_mean      = pan1.rolling(n_steps).mean()
pan1_sd        = 2 * pan1.rolling(n_steps).std()

pan2           = pd.DataFrame(pan2)
pan2_mean      = pan2.rolling(n_steps).mean()
pan2_sd        = 2 * pan2.rolling(n_steps).std()


pan3           = pd.DataFrame(pan3)
pan3_mean      = pan3.rolling(n_steps).mean()
pan3_sd        = 2 * pan3.rolling(n_steps).std()

#====== Upper and lower limit ==
co1_lower  = (co1_mean-co1_sd)[0]
co1_upper  = (co1_mean+co1_sd)[0]

co2_lower  = (co2_mean-co2_sd)[0]
co2_upper  = (co2_mean+co2_sd)[0]

co3_lower  = (co3_mean-co3_sd)[0]
co3_upper  = (co3_mean+co3_sd)[0]


o1_lower  = (o1_mean-o1_sd)[0]
o1_upper  = (o1_mean+o1_sd)[0]

o2_lower  = (o2_mean-o2_sd)[0]
o2_upper  = (o2_mean+o2_sd)[0]

o3_lower  = (o3_mean-o3_sd)[0]
o3_upper  = (o3_mean+o3_sd)[0]


pan1_lower  = (pan1_mean-pan1_sd)[0]
pan1_upper  = (pan1_mean+pan1_sd)[0]

pan2_lower  = (pan2_mean-pan2_sd)[0]
pan2_upper  = (pan2_mean+pan2_sd)[0]

pan3_lower  = (pan3_mean-pan3_sd)[0]
pan3_upper  = (pan3_mean+pan3_sd)[0]



""" ====== For IGT =================="""

#====== CO ============================
co1_igt           = pd.DataFrame(co1_igt)
co1_mean_igt      = co1_igt.rolling(n_steps).mean()
co1_sd_igt        = 2 * co1_igt.rolling(n_steps).std()

co2_igt           = pd.DataFrame(co2_igt)
co2_mean_igt      = co2_igt.rolling(n_steps).mean()
co2_sd_igt        = 2 * co2_igt.rolling(n_steps).std()

co3_igt           = pd.DataFrame(co3_igt)
co3_mean_igt      = co3_igt.rolling(n_steps).mean()
co3_sd_igt        = 2 * co3_igt.rolling(n_steps).std()

#====== O3 ============================
o1_igt           = pd.DataFrame(o1_igt)
o1_mean_igt      = o1_igt.rolling(n_steps).mean()
o1_sd_igt        = 2 * o1_igt.rolling(n_steps).std()

o2_igt           = pd.DataFrame(o2_igt)
o2_mean_igt      = o2_igt.rolling(n_steps).mean()
o2_sd_igt        = 2 * o2_igt.rolling(n_steps).std()


o3_igt           = pd.DataFrame(o3_igt)
o3_mean_igt      = o3_igt.rolling(n_steps).mean()
o3_sd_igt        = 2 * o3_igt.rolling(n_steps).std()


#======= PAN ==========================
pan1_igt           = pd.DataFrame(pan1_igt)
pan1_mean_igt      = pan1_igt.rolling(n_steps).mean()
pan1_sd_igt        = 2 * pan1_igt.rolling(n_steps).std()

pan2_igt           = pd.DataFrame(pan2_igt)
pan2_mean_igt      = pan2_igt.rolling(n_steps).mean()
pan2_sd_igt        = 2 * pan2_igt.rolling(n_steps).std()


pan3_igt           = pd.DataFrame(pan3_igt)
pan3_mean_igt      = pan3_igt.rolling(n_steps).mean()
pan3_sd_igt        = 2 * pan3_igt.rolling(n_steps).std()

#====== Upper and lower limit ==
co1_lower_igt  = (co1_mean_igt-co1_sd_igt)[0]
co1_upper_igt  = (co1_mean_igt+co1_sd_igt)[0]

co2_lower_igt  = (co2_mean_igt-co2_sd_igt)[0]
co2_upper_igt  = (co2_mean_igt+co2_sd_igt)[0]

co3_lower_igt  = (co3_mean_igt-co3_sd_igt)[0]
co3_upper_igt  = (co3_mean_igt+co3_sd_igt)[0]


o1_lower_igt  = (o1_mean_igt-o1_sd_igt)[0]
o1_upper_igt  = (o1_mean_igt+o1_sd_igt)[0]

o2_lower_igt  = (o2_mean_igt-o2_sd_igt)[0]
o2_upper_igt  = (o2_mean_igt+o2_sd_igt)[0]

o3_lower_igt  = (o3_mean_igt-o3_sd_igt)[0]
o3_upper_igt  = (o3_mean_igt+o3_sd_igt)[0]


pan1_lower_igt  = (pan1_mean_igt-pan1_sd_igt)[0]
pan1_upper_igt  = (pan1_mean_igt+pan1_sd_igt)[0]

pan2_lower_igt  = (pan2_mean_igt-pan2_sd_igt)[0]
pan2_upper_igt  = (pan2_mean_igt+pan2_sd_igt)[0]

pan3_lower_igt  = (pan3_mean_igt-pan3_sd_igt)[0]
pan3_upper_igt  = (pan3_mean_igt+pan3_sd_igt)[0]

""" ============= Now Plot ==================="""
fig = plt.figure(figsize=(9, 7))

""" ============== Plot O3 ===================="""
ax = fig.add_subplot(3,2,1)
ax.plot(time, o1, 'red',  linewidth=1)
ax.plot(time, o2, 'blue', linewidth=1)
ax.plot(time, o3, 'black', linewidth=1)
ax.fill_between(time, o1_lower, o1_upper,  color='lightpink', alpha=0.5, zorder=0)
ax.fill_between(time, o2_lower, o2_upper,  color='lightblue', alpha=0.5, zorder=1)
ax.fill_between(time, o3_lower, o3_upper,  color='#003153',   alpha=0.5, zorder=0)
gv.set_titles_and_labels(ax)
gv.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
ax.tick_params(axis="x", labelsize=13)
ax.tick_params(axis="y", labelsize=13)
gv.set_titles_and_labels(ax,maintitle ='Concentration', ylabel="$O_3$")
ax.set_ylim(20, 80)
""" ============== Plot CO ===================="""
ax = fig.add_subplot(3,2,3)
ax.plot(time, co1, 'red',  linewidth=1, label = '30N-90N')
ax.plot(time, co2, 'blue', linewidth=1, label = '30N-30S')
ax.plot(time, co3, 'black', linewidth=1, label = '30S-90S')
ax.fill_between(time, co1_lower, co1_upper,  color='lightpink', alpha=0.5, zorder=0)
ax.fill_between(time, co2_lower, co2_upper,  color='lightblue', alpha=0.5, zorder=1)
ax.fill_between(time, co3_lower, co3_upper,  color='#003153',   alpha=0.5, zorder=0)
gv.set_titles_and_labels(ax, ylabel="CO")
gv.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
ax.tick_params(axis="x", labelsize=13)
ax.tick_params(axis="y", labelsize=13)
plt.legend(loc='upper left',ncol=3)
ax.set_ylim(20, 120)
""" ============== Plot PAN ===================="""
ax = fig.add_subplot(3,2,5)
ax.plot(time, pan1, 'red',  linewidth=1)
ax.plot(time, pan2, 'blue', linewidth=1)
ax.plot(time, pan3, 'black', linewidth=1)
ax.fill_between(time, pan1_lower, pan1_upper,  color='lightpink', alpha=0.5, zorder=0)
ax.fill_between(time, pan2_lower, pan2_upper,  color='lightblue', alpha=0.5, zorder=1)
ax.fill_between(time, pan3_lower, pan3_upper,  color='#003153',   alpha=0.5, zorder=0)
gv.set_titles_and_labels(ax, ylabel="PAN")
gv.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
ax.tick_params(axis="x", labelsize=13)
ax.tick_params(axis="y", labelsize=13)
ax.set_ylim(0, 300)
""" ============== Plot CO IGT ===================="""
ax = fig.add_subplot(3,2,2)
ax.plot(time, co1_igt, 'red',  linewidth=1, label = '30N-90N')
ax.plot(time, co2_igt, 'blue', linewidth=1, label = '30N-30S')
ax.plot(time, co3_igt, 'black', linewidth=1, label = '30S-90S')
ax.fill_between(time, co1_lower_igt, co1_upper_igt,  color='lightpink', alpha=0.5, zorder=0)
ax.fill_between(time, co2_lower_igt, co2_upper_igt,  color='lightblue', alpha=0.5, zorder=1)
ax.fill_between(time, co3_lower_igt, co3_upper_igt,  color='#003153',   alpha=0.5, zorder=0)
gv.set_titles_and_labels(ax,maintitle ='IGT')
gv.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
ax.tick_params(axis="x", labelsize=13)
ax.tick_params(axis="y", labelsize=13)
ax.set_ylim(0.0025, 0.0125)
""" ============== Plot O3 IGT ===================="""
ax = fig.add_subplot(3,2,4)
ax.plot(time, o1_igt, 'red',  linewidth=1)
ax.plot(time, o2_igt, 'blue', linewidth=1)
ax.plot(time, o3_igt, 'black', linewidth=1)
ax.fill_between(time, o1_lower_igt, o1_upper_igt,  color='lightpink', alpha=0.5, zorder=0)
ax.fill_between(time, o2_lower_igt, o2_upper_igt,  color='lightblue', alpha=0.5, zorder=1)
ax.fill_between(time, o3_lower_igt, o3_upper_igt,  color='#003153',   alpha=0.5, zorder=0)
gv.set_titles_and_labels(ax)
gv.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
ax.tick_params(axis="x", labelsize=13)
ax.tick_params(axis="y", labelsize=13)
ax.set_ylim(0, 0.03)
""" ============== Plot PAN IGT ===================="""
ax = fig.add_subplot(3,2,6)
ax.plot(time, pan1_igt, 'red',  linewidth=1)
ax.plot(time, pan2_igt, 'blue', linewidth=1)
ax.plot(time, pan3_igt, 'black', linewidth=1)
ax.fill_between(time, pan1_lower_igt, pan1_upper_igt,  color='lightpink', alpha=0.5, zorder=0)
ax.fill_between(time, pan2_lower_igt, pan2_upper_igt,  color='lightblue', alpha=0.5, zorder=1)
ax.fill_between(time, pan3_lower_igt, pan3_upper_igt,  color='#003153',   alpha=0.5, zorder=0)
gv.set_titles_and_labels(ax)
gv.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
ax.tick_params(axis="x", labelsize=13)
ax.tick_params(axis="y", labelsize=13)
ax.set_ylim(0, 0.15)

fig.subplots_adjust(top=0.937,
            bottom=0.044,
            left=0.09,
            right=0.983,
            hspace=0.349,
            wspace=0.26)
plt.savefig('zonal_mean_igt_conc_NEW1.png', dpi=600)
plt.savefig('zonal_mean_igt_conc_NEW1.tiff', dpi=200)
plt.show()
