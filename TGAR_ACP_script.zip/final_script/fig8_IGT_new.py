"""===== This code plots the annual trend of vertically integrated trace gases concentration
         such as CO, O3, PAN and significant level
         
         Date : 2023/May/10
         By   : Mukesh Rai
         lOC  : JPL office =========== """

#======== Load libraries ======================
import numpy as np
import netCDF4 as nc
from matplotlib import pyplot as plt
from numpy import sqrt
from mpl_toolkits.basemap import Basemap
from scipy.stats import pearsonr
import cmaps
import matplotlib
import matplotlib.gridspec as gridspec

"""=======Control font============================"""
matplotlib.rcParams['font.family'] = "sans-serif"
matplotlib.rcParams['font.sans-serif'] = "Times New Roman"

#========= Load data ===========================
dataset1 = nc.Dataset('/Volumes/External_4TB/jpl_AR/2005_2019/igt_co_2005_2019_yearavg_regrid.nc')
dataset2 = nc.Dataset('/Volumes/External_4TB/jpl_AR/2005_2019/igt_o3_2005_2019_1000_200_regrid_yearmean.nc')
dataset3 = nc.Dataset('/Volumes/External_4TB/jpl_AR/2005_2019/igt_pan_2005_2019_yearavg_regrid.nc')

#====== Get ivtx and ivty from each file ===========
ivtx1 = dataset1.variables['ivtx'][:]
ivty1 = dataset1.variables['ivty'][:]

ivtx2 = dataset2.variables['ivtx'][:]
ivty2 = dataset2.variables['ivty'][:]

ivtx3 = dataset3.variables['ivtx'][:]
ivty3 = dataset3.variables['ivty'][:]

#===== Convert the values to float32 using numpy ========
ivtx1 = np.array(ivtx1, dtype=np.float32)
ivty1 = np.array(ivty1, dtype=np.float32)

ivtx2 = np.array(ivtx2, dtype=np.float32)
ivty2 = np.array(ivty2, dtype=np.float32)

ivtx3 = np.array(ivtx3, dtype=np.float32)
ivty3 = np.array(ivty3, dtype=np.float32)

#========== Get data =================
co = sqrt((ivtx1)**2+(ivty1)**2) *10000
o3 = sqrt((ivtx2)**2+(ivty2)**2) *10000
pan = sqrt((ivtx3)**2+(ivty3)**2) *1000

latitude_variable = dataset1.variables['lat']
longitude_variable = dataset1.variables['lon']
lat = latitude_variable[:]
lon = longitude_variable[:]


"""====== Reshape the data array to have time as the first dimension
         and flatten the lat and lon dimensions======= """

""" === co ==="""
time, lat_dim, lon_dim = co.shape
data_reshaped1 = np.reshape(co, (time, lat_dim * lon_dim))

""" === o3 ==="""
data_reshaped2 = np.reshape(o3, (time, lat_dim * lon_dim))

""" === pan ==="""
data_reshaped3 = np.reshape(pan, (time, lat_dim * lon_dim))

"""===== calculate slope ============"""

slopes1 = np.zeros((lat_dim * lon_dim,))
for i in range(lat_dim * lon_dim):
    slope1, _ = np.polyfit(np.arange(time), data_reshaped1[:, i], 1)
    slopes1[i] = slope1

slopes2 = np.zeros((lat_dim * lon_dim,))
for i in range(lat_dim * lon_dim):
    slope2, _ = np.polyfit(np.arange(time), data_reshaped2[:, i], 1)
    slopes2[i] = slope2

slopes3 = np.zeros((lat_dim * lon_dim,))
for i in range(lat_dim * lon_dim):
    slope3, _ = np.polyfit(np.arange(time), data_reshaped3[:, i], 1)
    slopes3[i] = slope3

""" ==== Reshape the slopes array back to the original lat and lon dimensions ====== """
slopes1 = np.reshape(slopes1, (lat_dim, lon_dim))
slopes2 = np.reshape(slopes2, (lat_dim, lon_dim))
slopes3 = np.reshape(slopes3, (lat_dim, lon_dim))

"""==== Calculate the p-value of the Pearson correlation
      coefficient for each grid point over time """

p_values1 = np.zeros((lat_dim * lon_dim,))
for i in range(lat_dim * lon_dim):
    _, p_value1 = pearsonr(data_reshaped1[:, i], np.arange(time))
    p_values1[i] = p_value1

p_values2 = np.zeros((lat_dim * lon_dim,))
for i in range(lat_dim * lon_dim):
    _, p_value2 = pearsonr(data_reshaped2[:, i], np.arange(time))
    p_values2[i] = p_value2

p_values3 = np.zeros((lat_dim * lon_dim,))
for i in range(lat_dim * lon_dim):
    _, p_value3 = pearsonr(data_reshaped3[:, i], np.arange(time))
    p_values3[i] = p_value3

""" ==== Reshape the p-values array back
         to the original lat and lon dimensions === """
p_values1 = np.reshape(p_values1, (lat_dim, lon_dim))
p_values2 = np.reshape(p_values2, (lat_dim, lon_dim))
p_values3 = np.reshape(p_values3, (lat_dim, lon_dim))

sig1 = np.where(p_values1 < 0.05)
sig2 = np.where(p_values2 < 0.05)
sig3 = np.where(p_values3 < 0.05)


#======= Now plot =====================================================

fig, axs = plt.subplots(3, 1, figsize=(4, 9))
gridspec.GridSpec(3, 1)
m = Basemap(projection='robin', lon_0=0, resolution='c')
x, y = m(*np.meshgrid(lon, lat))

def downsample_points(x, y, step=6):
    return x[::step], y[::step]

sig1_x, sig1_y = downsample_points(x[sig1], y[sig1])
sig2_x, sig2_y = downsample_points(x[sig2], y[sig2])
sig3_x, sig3_y = downsample_points(x[sig3], y[sig3])

#==== Plot function =====
def plot_trend(ax, slopes, sig_x, sig_y, title, clim, color_ticks, marker_size=0.005):
    ax = m.pcolormesh(x, y, slopes, cmap=cmaps.BlueWhiteOrangeRed)
    plt.clim(*clim)
    plt.title(title)
    plt.title(title, fontsize=15)
    cbar = fig.colorbar(ax, ticks=color_ticks, extend='both', orientation='horizontal')
    cbar.ax.set_title('$Kg m^{-1} s^{-1}/year$', fontsize=10, pad=5)
    cbar.ax.tick_params(labelsize=12)
    cbar.ax.minorticks_on()
    # Use solid dots for significant points
    m.scatter(sig_x, sig_y, marker='.', s=marker_size, c='#3B444B')
    m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.4, dashes=[4, 4], labels=[1, 0, 0, 0], fontsize=12)
    m.drawmeridians(range(0, 360, 60), color='gray', linewidth=0.4, dashes=[4, 4], labels=[0, 0, 0, 1], fontsize=9)
    m.drawcountries(linewidth=0.2)
    m.drawcoastlines(linewidth=0.2)
    #==== add 
    #==== D1 ===============
    lon1 = [-180, -180, -120, -120,-180]
    lat1 = [35, 55, 55, 35,35]

    #==== D2  ==
    lon2 = [-100, -100, 0, 0,-100]
    lat2 = [40, 60, 60, 40,40]

    #==== D3  ==
    lon3 = [-110, -110, 0, 0,-110]
    lat3 = [20, 38, 38, 20,20]

    #==== D4  ==
    lon4 = [-120, -120, 0, 0,-120]
    lat4 = [-45, -65, -65, -45,-45]

    #==== D5  ==
    lon5 = [130, 130, 180, 180,130]
    lat5 = [40,  55,  55, 40,40]

    #===== D6 ===
    lon6 = [120,  120,  180, 180, 120]
    lat6 = [20, 38, 38,  20, 20]


    x1, y1 = m(lon1, lat1)
    x2, y2 = m(lon2, lat2)
    x3, y3 = m(lon3, lat3)
    x4, y4 = m(lon4, lat4)
    x5, y5 = m(lon5, lat5)
    x6, y6 = m(lon6, lat6)

    m.plot(x1, y1, marker=None, color='red',         linewidth=1)
    m.plot(x2, y2, marker=None, color='green',       linewidth=1)
    m.plot(x3, y3, marker=None, color='blue',        linewidth=1)
    m.plot(x4, y4, marker=None, color='gray',        linewidth=1)
    m.plot(x5, y5, marker=None, color='magenta',     linewidth=1)
    m.plot(x6, y6, marker=None, color='#1E90FF',      linewidth=1)


#==== Plot CO, O3, PAN trends ===========
plt.subplot2grid((3, 1), (0, 0))
plot_trend(axs[1], slopes2, sig2_x, sig2_y, '$O_3$_IGT',(-2, 2), np.linspace(-2, 2, 11),marker_size=0.1) #, (0, 0.5), np.linspace(0, 0.5, 11), marker_size=0.1)

plt.subplot2grid((3, 1), (1,0))
plot_trend(axs[0], slopes1, sig1_x, sig1_y, 'CO_IGT', (-2, 2), np.linspace(-2, 2, 11), marker_size=0.1)

plt.subplot2grid((3, 1), (2, 0))
plot_trend(axs[2], slopes3, sig3_x, sig3_y, 'PAN_IGT', (-2, 2), np.linspace(-2, 2, 11), marker_size=0.1)

fig.subplots_adjust(top=0.97, bottom=0.007, left=0.092, right=0.996, hspace=0.16, wspace=0.117)

plt.savefig('igt_trend_new.png', dpi=600)
plt.savefig('igt_trend.tiff', dpi=200)
plt.show()
