""" This script is for ploting seasonal IGT
    Written by : Mukesh Rai
    Date : 2023/Mar/02
    Location: JPL """

#===== Import Libraries ========================
import matplotlib
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap
import numpy as np
import cmaps
from matplotlib.patches import Patch
from matplotlib.pyplot import figure
import matplotlib.gridspec as gridspec
import scipy.ndimage
from mpl_toolkits.axes_grid1 import make_axes_locatable
from matplotlib import rcParams
from numpy import sqrt
import xarray as xr
from mpl_toolkits.axes_grid1 import make_axes_locatable
from mplgrid import grid
from mpl_toolkits.axes_grid1 import make_axes_locatable
from mpl_toolkits.axes_grid1 import ImageGrid
import pandas as pd
from geocat.viz import util as gvutil
from matplotlib.ticker import MultipleLocator, FormatStrFormatter
from matplotlib import ticker
import matplotlib.lines as mlines


"""Control font"""
matplotlib.rcParams['font.family'] = "sans-serif"
matplotlib.rcParams['font.sans-serif'] = "Times New Roman"

#============== Load data =========================
data1 = xr.open_dataset('/Volumes/External_4TB/jpl_AR/2005_2019/igt_co_2005_2019_regrid.nc')
data2 = xr.open_dataset('/Volumes/External_4TB/jpl_AR/2005_2019/igt_o3_2005_2019_regrid.nc')
#data3 = xr.open_dataset('/Users/mrai/mukesh_data/jpl_AR/2005_2019/igt_pan_2005_2019.nc')
data3 = xr.open_dataset('/Volumes/External_4TB/jpl_AR/2005_2019/igt_pan_2005_2019_regrid.nc')

#===== CO ===========
ivtx1 = data1.ivtx
ivty1 = data1.ivty

#==== O3 ============
ivtx2 = data2.ivtx
ivty2 = data2.ivty

#==== PAN ==========
ivtx3 = data3.ivtx
ivty3 = data3.ivty



#==== Get lat and lon =========
lat = data1.lat
lon = data1.lon



#=========== First resample hourly data into monthly wise =======
#=== co ==
ivtx_month1 = ivtx1.resample(time="1M").mean()
ivty_month1 = ivty1.resample(time="1M").mean()
#=== o3 ==
ivtx_month2 = ivtx2.resample(time="1M").mean()
ivty_month2 = ivty2.resample(time="1M").mean()

#=== PAN ==
ivtx3 = ivtx3.sortby('time') # first sort the time dimension in ascending order using the sortby() method #
ivty3 = ivty3.sortby('time') # otherwise it will throws an error => ValueError: index must be monotonic for resampling #

ivtx_month3 = ivtx3.resample(time="1M").mean()
ivty_month3 = ivty3.resample(time="1M").mean()


#========= Seasonal mean ==========================
#=== CO ==
ivtx_seasonal1 = ivtx_month1.groupby("time.season").mean("time")
ivty_seasonal1 = ivty_month1.groupby("time.season").mean("time")

#== O3 ==
ivtx_seasonal2 = ivtx_month2.groupby("time.season").mean("time")
ivty_seasonal2 = ivty_month2.groupby("time.season").mean("time")

#== PAN ==
ivtx_seasonal3 = ivtx_month3.groupby("time.season").mean("time")
ivty_seasonal3 = ivty_month3.groupby("time.season").mean("time")


#========= Calculate Integrated Gas Transport  ========
igt1  = sqrt(ivtx_seasonal1**2+ivty_seasonal1**2)
igt2  = sqrt(ivtx_seasonal2**2+ivty_seasonal2**2)
igt3  = sqrt(ivtx_seasonal3**2+ivty_seasonal3**2)
igt3  = igt3      # Since, PAN is in ppt, convert to ppb

#========= Take seasonal flux on  =======

#==== Winter ======

#=== CO ==
ivtx_win1 = ivtx_seasonal1.isel(season=0) # winter [DJF]
ivty_win1 = ivty_seasonal1.isel(season=0) # winter [DJF]
#=== O3 ==
ivtx_win2 = ivtx_seasonal2.isel(season=0) # winter [DJF]
ivty_win2 = ivty_seasonal2.isel(season=0) # winter [DJF]
#== PAN ==
ivtx_win3 = ivtx_seasonal3.isel(season=0) # winter [DJF]
ivty_win3 = ivty_seasonal3.isel(season=0) # winter [DJF]

#==== Summer  ======
#=== CO ==
ivtx_sum1 = ivtx_seasonal1.isel(season=1) # Summer [JJA]
ivty_sum1 = ivty_seasonal1.isel(season=1) # Summer [JJA]
#=== O3 ==
ivtx_sum2 = ivtx_seasonal2.isel(season=1) # Summer [JJA]
ivty_sum2 = ivty_seasonal2.isel(season=1) # Summer [JJA]
#=== PAN ==
ivtx_sum3 = ivtx_seasonal3.isel(season=1) # Summer [JJA]
ivty_sum3 = ivty_seasonal3.isel(season=1) # Summer [JJA]


#==== Spring  ======
#=== CO ==
ivtx_spr1 = ivtx_seasonal1.isel(season=2) # Spring [MAM]
ivty_spr1 = ivty_seasonal1.isel(season=2) # Spring [MAM]
#=== O3 ==
ivtx_spr2 = ivtx_seasonal2.isel(season=2) # Spring [MAM]
ivty_spr2 = ivty_seasonal2.isel(season=2) # Spring [MAM]
#=== PAN ==
ivtx_spr3 = ivtx_seasonal3.isel(season=2) # Spring [MAM]
ivty_spr3 = ivty_seasonal3.isel(season=2) # Spring [MAM]

#==== Autumn  ======
#=== CO ==
ivtx_aut1 = ivtx_seasonal1.isel(season=3) # Autumn [SON]
ivty_aut1 = ivty_seasonal1.isel(season=3) # Autumn [SON]

#=== O3 ==
ivtx_aut2 = ivtx_seasonal2.isel(season=3) # Spring [SON]
ivty_aut2 = ivty_seasonal2.isel(season=3) # Spring [SON]

#=== PAN ==
ivtx_aut3 = ivtx_seasonal3.isel(season=3) # Spring [SON]
ivty_aut3 = ivty_seasonal3.isel(season=3) # Spring [SON]



#======== select seasonal IGT  =======
#==== CO ==
win1 = igt1.isel(season=0) # winter [DJF]
sum1 = igt1.isel(season=1) # Summer [JJA]
spr1 = igt1.isel(season=2) # Spring [MAM]
aut1 = igt1.isel(season=3) # Autumn [SON]

#=== O3 ==
win2 = igt2.isel(season=0) # winter [DJF]
sum2 = igt2.isel(season=1) # Summer [JJA]
spr2 = igt2.isel(season=2) # Spring [MAM]
aut2 = igt2.isel(season=3) # Autumn [SON]

#=== PAN ==
win3 = igt3.isel(season=0) # winter [DJF]
sum3 = igt3.isel(season=1) # Summer [JJA]
spr3 = igt3.isel(season=2) # Spring [MAM]
aut3 = igt3.isel(season=3) # Autumn [SON]


#====== Take latidudinal average ============
#=== Winter ==
win1_lat = np.average(win1,axis=1) #CO
win2_lat = np.average(win2,axis=1) #O3
win3_lat = np.average(win3,axis=1) #PAN

#=== Spring ==
spr1_lat = np.average(spr1,axis=1) #CO
spr2_lat = np.average(spr2,axis=1) #O3 
spr3_lat = np.average(spr3,axis=1) #PAN

#=== Summer ==
sum1_lat = np.average(sum1,axis=1) #CO
sum2_lat = np.average(sum2,axis=1) #O3
sum3_lat = np.average(sum3,axis=1) #PAN


#=== Autumn  ==
aut1_lat = np.average(aut1,axis=1) #CO
aut2_lat = np.average(aut2,axis=1) #O3   
aut3_lat = np.average(aut3,axis=1) #PAN  


#===== Calculate Northern and Southern hemisphere contribution =====


#==== whole world average ====

#== Winter ==
co_av_win  = np.sum(win1_lat) #co
o3_av_win  = np.sum(win2_lat) #o3
pan_av_win = np.sum(win3_lat) #pan

#== Spring ==
co_av_spr  = np.sum(spr1_lat) #co
o3_av_spr  = np.sum(spr2_lat) #o3 
pan_av_spr = np.sum(spr3_lat) #pan

#== Summer ==
co_av_sum  = np.sum(sum1_lat) #co
o3_av_sum  = np.sum(sum2_lat) #o3 
pan_av_sum = np.sum(sum3_lat) #pan

#== Autumn ==
co_av_aut  = np.sum(aut1_lat) #co
o3_av_aut  = np.sum(aut2_lat) #o3 
pan_av_aut = np.sum(aut3_lat) #pan



#========== Now calculate Northward and Southward IGT contribution ==========

#===== CO-winter ===============================

#=== northward ========== 
win_north_co1    = win1.sel(lat = slice(0,90))
win_north_co    = np.average(win_north_co1,axis=1)
ave_co_north    = np.sum(win_north_co) 
win_co_north    = ave_co_north/co_av_win*100

#=== southward ========
win_south_co1    = win1.sel(lat = slice(-90,0))
win_south_co    = np.average(win_south_co1,axis=1)
ave_co_south    = np.sum(win_south_co)
win_co_south    = ave_co_south/co_av_win*100


#===== O3-winter =============================
#=== northward ==========
win_north_o3    = win2.sel(lat = slice(0,90)) 
win_north_o3    = np.average(win_north_o3,axis=1)
ave_o3_north    = np.sum(win_north_o3)
win_o3_north    = ave_o3_north/o3_av_win*100

#=== southward =======
win_south_o3    = win2.sel(lat = slice(-90,0))
win_south_o3    = np.average(win_south_o3,axis=1)
ave_o3_south    = np.sum(win_south_o3)
win_o3_south    = ave_o3_south/o3_av_win*100


#===== PAN-winter =============================
#=== northward ==========
win_north_pan    = win3.sel(lat = slice(0,90))
win_north_pan    = np.average(win_north_pan,axis=1)
ave_pan_north    = np.sum(win_north_pan)
win_pan_north    = ave_pan_north/pan_av_win*100

#=== southward =======
win_south_pan    = win3.sel(lat = slice(-90,0))
win_south_pan    = np.average(win_south_pan,axis=1)
ave_pan_south    = np.sum(win_south_pan)
win_pan_south    = ave_pan_south/pan_av_win*100



#==============XX===================

#===== CO-Spring ===============================

#=== northward ==========
spr_north_co       = spr1.sel(lat = slice(0,90))
spr_north_co       = np.average(spr_north_co,axis=1)
ave_co_north_spr   = np.sum(spr_north_co)
spr_co_north       = ave_co_north_spr/co_av_spr*100

#=== southward ========
spr_south_co       = spr1.sel(lat = slice(-90,0))
spr_south_co       = np.average(spr_south_co,axis=1)
ave_co_south_spr   = np.sum(spr_south_co)
spr_co_south       = ave_co_south_spr/co_av_spr*100

#===== O3-Spring =============================
#=== northward ==========
spr_north_o3      = spr2.sel(lat = slice(0,90))
spr_north_o3      = np.average(spr_north_o3,axis=1)
ave_o3_north_spr  = np.sum(spr_north_o3)
spr_o3_north      = ave_o3_north_spr/o3_av_spr*100

#=== southward =======
spr_south_o3        = spr2.sel(lat = slice(-90,0))
spr_south_o3        = np.average(spr_south_o3,axis=1)
ave_o3_south_spr    = np.sum(spr_south_o3)
spr_o3_south        = ave_o3_south_spr/o3_av_spr*100

#===== PAN-Spring =============================
#=== northward ==========
spr_north_pan        = spr3.sel(lat = slice(0,90))
spr_north_pan        = np.average(spr_north_pan,axis=1)
ave_pan_north_spr    = np.sum(spr_north_pan)
spr_pan_north        = ave_pan_north_spr/pan_av_spr*100

#=== southward =======
spr_south_pan       = spr3.sel(lat = slice(-90,0))
spr_south_pan       = np.average(spr_south_pan,axis=1)
ave_pan_south_spr   = np.sum(spr_south_pan)
spr_pan_south       = ave_pan_south_spr/pan_av_spr*100

#=================XX================
#===== CO-Summer ===============================

#=== northward ==========
sum_north_co       = sum1.sel(lat = slice(0,90))
sum_north_co       = np.average(sum_north_co,axis=1)
ave_co_north_sum   = np.sum(sum_north_co)
sum_co_north       = ave_co_north_sum/co_av_sum*100

#=== southward ========
sum_south_co       = sum1.sel(lat = slice(-90,0))
sum_south_co       = np.average(sum_south_co,axis=1)
ave_co_south_sum   = np.sum(sum_south_co)
sum_co_south       = ave_co_south_sum/co_av_sum*100

#===== O3-Summer =============================
#=== northward ==========
sum_north_o3      = sum2.sel(lat = slice(0,90))
sum_north_o3      = np.average(sum_north_o3,axis=1)
ave_o3_north_sum  = np.sum(sum_north_o3)
sum_o3_north      = ave_o3_north_sum/o3_av_sum*100

#=== southward =======
sum_south_o3        = sum2.sel(lat = slice(-90,0))
sum_south_o3        = np.average(sum_south_o3,axis=1)
ave_o3_south_sum    = np.sum(sum_south_o3)
sum_o3_south        = ave_o3_south_sum/o3_av_sum*100

#===== PAN-Summer =============================
#=== northward ==========
sum_north_pan        = sum3.sel(lat = slice(0,90))
sum_north_pan        = np.average(sum_north_pan,axis=1)
ave_pan_north_sum    = np.sum(sum_north_pan)
sum_pan_north        = ave_pan_north_sum/pan_av_sum*100

#=== southward =======
sum_south_pan       = sum3.sel(lat = slice(-90,0))
sum_south_pan       = np.average(sum_south_pan,axis=1)
ave_pan_south_sum   = np.sum(sum_south_pan)
sum_pan_south       = ave_pan_south_sum/pan_av_sum*100

#=================XX================
#===== CO-Autumn ===============================

#=== northward ==========
aut_north_co       = aut1.sel(lat = slice(0,90))
aut_north_co       = np.average(aut_north_co,axis=1)
ave_co_north_aut   = np.sum(aut_north_co)
aut_co_north       = ave_co_north_aut/co_av_aut*100

#=== southward ========
aut_south_co       = aut1.sel(lat = slice(-90,0))
aut_south_co       = np.average(aut_south_co,axis=1)
ave_co_south_aut   = np.sum(aut_south_co)
aut_co_south       = ave_co_south_aut/co_av_aut*100

#===== O3-Autumn =============================
#=== northward ==========
aut_north_o3      = aut2.sel(lat = slice(0,90))
aut_north_o3      = np.average(aut_north_o3,axis=1)
ave_o3_north_aut  = np.sum(aut_north_o3)
aut_o3_north      = ave_o3_north_aut/o3_av_aut*100

#=== southward =======
aut_south_o3        = aut2.sel(lat = slice(-90,0))
aut_south_o3        = np.average(aut_south_o3,axis=1) 
ave_o3_south_aut    = np.sum(aut_south_o3)
aut_o3_south        = ave_o3_south_aut/o3_av_aut*100

#===== PAN-Autumn =============================
#=== northward ==========
aut_north_pan        = aut3.sel(lat = slice(0,90))
aut_north_pan        = np.average(aut_north_pan,axis=1)
ave_pan_north_aut    = np.sum(aut_north_pan)
aut_pan_north        = ave_pan_north_aut/pan_av_aut*100

#=== southward ======= 
aut_south_pan       = aut3.sel(lat = slice(-90,0))
aut_south_pan       = np.average(aut_south_pan,axis=1)
ave_pan_south_aut   = np.sum(aut_south_pan)
aut_pan_south       = ave_pan_south_aut/pan_av_aut*100

#=================XX================

#========== Setting Frame ======================
fig = plt.figure(figsize=(11, 9))
m = Basemap(projection='robin',lon_0=0,resolution='h', area_thresh=1500)
""" =================== Plotting  O3 ==============================================================================="""
#========= Frame Winter  ========================
ax = plt.subplot(4,3,1)
x, y = m(*np.meshgrid(lon,lat))
s = m.pcolormesh(x,y,win2,cmap=cmaps.GMT_panoply) #WhiteBlueGreenYellowRed)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=8)
m.drawmeridians(range(0, 360, 60), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=8)
m.drawcoastlines(linewidth=0.2)
plt.clim(0,0.025)
ax.set_title('$O_3$', fontsize=15, pad=5)
plt.ylabel("DJF",fontsize=15,labelpad=5)

#==== Add quiver plot ========
plt.quiver(x[::8,::8], y[::8,::8],ivtx_win2[::8,::8],ivty_win2[::8,::8],pivot='middle',scale_units='inches',headwidth=6,headlength=9)

#========= Frame Spring  ========================
ax = plt.subplot(4,3,4)
x, y = m(*np.meshgrid(lon,lat))
s = m.pcolormesh(x,y,spr2,cmap=cmaps.GMT_panoply) #WhiteBlueGreenYellowRed)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=8)
m.drawmeridians(range(0, 360, 60), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=8)
m.drawcoastlines(linewidth=0.2)
plt.clim(0,0.025)
plt.ylabel("MAM",fontsize=15,labelpad=5)

#==== Add quiver plot ========
plt.quiver(x[::8,::8], y[::8,::8],ivtx_spr2[::8,::8],ivty_spr2[::8,::8],pivot='middle',scale_units='inches',headwidth=6,headlength=9)

#====== Frame Summer ======================
ax = fig.add_subplot(4,3,7)
x, y = m(*np.meshgrid(lon,lat))
s = m.pcolormesh(x,y,sum2,cmap=cmaps.GMT_panoply) #WhiteBlueGreenYellowRed)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=8)
m.drawmeridians(range(0, 360, 60), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=8)
m.drawcoastlines(linewidth=0.2)
plt.clim(0,0.025)
plt.ylabel("JJA",fontsize=15,labelpad=5)
#==== Add quiver plot ========
plt.quiver(x[::8,::8], y[::8,::8],ivtx_sum2[::8,::8],ivty_sum2[::8,::8],pivot='middle',scale_units='inches',headwidth=6,headlength=9)
#====== Frame Autumn ======================
ax = fig.add_subplot(4,3,10)
x, y = m(*np.meshgrid(lon,lat))
m2 = m.pcolormesh(x,y,aut2,cmap=cmaps.GMT_panoply) #WhiteBlueGreenYellowRed)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=10)
m.drawmeridians(range(0, 360, 60), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 1],fontsize=10)
m.drawcoastlines(linewidth=0.2)
plt.clim(0,0.025)
plt.ylabel("SON",fontsize=15,labelpad=5)
#==== Add quiver plot ========
plt.quiver(x[::8,::8], y[::8,::8],ivtx_aut2[::8,::8],ivty_aut2[::8,::8],pivot='middle',scale_units='inches',headwidth=6,headlength=9)
#===== Add colorbar ===================
divider = make_axes_locatable(ax)
cax = divider.append_axes('bottom', size="10%", pad=0.2)
cbar = fig.colorbar(m2, cax=cax,orientation='horizontal',extend='both')
cbar.set_label('$Kg m^{-1} s^{-1}$',fontsize=15)
cbar.ax.tick_params(labelsize=12)
cbar.ax.minorticks_on()


""" =================== Plotting  CO ==============================================================================="""
#========= Frame Winter  ========================
ax = fig.add_subplot(4,3,2)
x, y = m(*np.meshgrid(lon,lat))
s = m.pcolormesh(x,y,win1,cmap=cmaps.GMT_panoply)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=8)
m.drawmeridians(range(0, 360, 60),    color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=8)
m.drawcoastlines(linewidth=0.2)

ax.set_title('CO', fontsize=15, pad=0)

plt.clim(0,0.025)

#==== Add quiver plot ========
plt.quiver(x[::8,::8], y[::8,::8],ivtx_win1[::8,::8],ivty_win1[::8,::8],pivot='middle',scale_units='inches',headwidth=6,headlength=9)

#========= Frame Spring  ========================
ax = fig.add_subplot(4,3,5)
x, y = m(*np.meshgrid(lon,lat))
s = m.pcolormesh(x,y,spr1,cmap=cmaps.GMT_panoply) #WhiteBlueGreenYellowRed)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=8)
m.drawmeridians(range(0, 360, 60),    color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=8)   
m.drawcoastlines(linewidth=0.2)
plt.clim(0,0.025)

#==== Add quiver plot ========
plt.quiver(x[::8,::8], y[::8,::8],ivtx_spr1[::8,::8],ivty_spr1[::8,::8],pivot='middle',scale_units='inches',headwidth=6,headlength=9)

#====== Frame Summer ======================
ax = fig.add_subplot(4,3,8)
x, y = m(*np.meshgrid(lon,lat))
s = m.pcolormesh(x,y,sum1,cmap=cmaps.GMT_panoply) #WhiteBlueGreenYellowRed)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=8)
m.drawmeridians(range(0, 360, 60),    color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=8)
m.drawcoastlines(linewidth=0.2)
plt.clim(0,0.025)   

#==== Add quiver plot ========
plt.quiver(x[::8,::8], y[::8,::8],ivtx_sum1[::8,::8],ivty_sum1[::8,::8],pivot='middle',scale_units='inches',headwidth=6,headlength=9)

#====== Frame Autumn ======================
ax = fig.add_subplot(4,3,11)
x, y = m(*np.meshgrid(lon,lat))
m1 = m.pcolormesh(x,y,aut1,cmap=cmaps.GMT_panoply) # WhiteBlueGreenYellowRed)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=10)
m.drawmeridians(range(0, 360, 60), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 1],fontsize=10)   
m.drawcoastlines(linewidth=0.2)

plt.clim(0,0.025)

#==== Add quiver plot ========
plt.quiver(x[::8,::8], y[::8,::8],ivtx_aut1[::8,::8],ivty_aut1[::8,::8],pivot='middle',scale_units='inches',headwidth=6,headlength=9)


#===== Add colorbar ===================
divider = make_axes_locatable(ax)
cax = divider.append_axes('bottom', size="10%", pad=0.2)
cbar = fig.colorbar(m2, cax=cax,orientation='horizontal',extend='both')
cbar.set_label('$Kg m^{-1} s^{-1}$',fontsize=15)
cbar.ax.tick_params(labelsize=12)
cbar.ax.minorticks_on()

""" =================== Plotting  PAN  ==============================================================================="""
#========= Frame Winter  ========================
ax = plt.subplot(4,3,3)
x, y = m(*np.meshgrid(lon,lat))
ax1 = m.pcolormesh(x,y,win3,cmap=cmaps.GMT_panoply) #WhiteBlueGreenYellowRed)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 1, 0, 0],fontsize=10)
m.drawmeridians(range(0, 360, 60), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=10)
m.drawcoastlines(linewidth=0.2)
plt.clim(0,0.125)
ax.set_title('PAN', fontsize=15, pad=0)
#==== Add quiver plot ========
plt.quiver(x[::8,::8], y[::8,::8],ivtx_win3[::8,::8],ivty_win3[::8,::8],pivot='middle',scale_units='inches',headwidth=6,headlength=9)

#========= Frame Spring  ========================
ax = plt.subplot(4,3,6)
x, y = m(*np.meshgrid(lon,lat))
s = m.pcolormesh(x,y,spr3,cmap=cmaps.GMT_panoply) #WhiteBlueGreenYellowRed)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 1, 0, 0],fontsize=10)
m.drawmeridians(range(0, 360, 60), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=10)
m.drawcoastlines(linewidth=0.2)
plt.clim(0,0.125)

#==== Add quiver plot ========
plt.quiver(x[::8,::8], y[::8,::8],ivtx_spr3[::8,::8],ivty_spr3[::8,::8],pivot='middle',scale_units='inches',headwidth=6,headlength=9)

#====== Frame Summer ======================
ax = fig.add_subplot(4,3,9)

x, y = m(*np.meshgrid(lon,lat))
s = m.pcolormesh(x,y,sum3,cmap=cmaps.GMT_panoply) #WhiteBlueGreenYellowRed)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 1, 0, 0],fontsize=10)
m.drawmeridians(range(0, 360, 60), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 0],fontsize=10)
m.drawcoastlines(linewidth=0.2)
plt.clim(0,0.125)

#==== Add quiver plot ========
plt.quiver(x[::8,::8], y[::8,::8],ivtx_sum3[::8,::8],ivty_sum3[::8,::8],pivot='middle',scale_units='inches',headwidth=6,headlength=9)

#====== Frame Autumn ====================== 
ax = plt.subplot(4,3,12) 
x, y = m(*np.meshgrid(lon,lat)) 
m3 = m.pcolormesh(x,y,aut3,cmap=cmaps.GMT_panoply) #WhiteBlueGreenYellowRed)
m.drawparallels(range(-180, 180, 20), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 1, 0, 0],fontsize=10)
m.drawmeridians(range(0,360, 60), color='gray', linewidth=0.5, dashes=[4, 4], labels=[0, 0, 0, 1],fontsize=10) 
m.drawcoastlines(linewidth=0.2) 
plt.clim(0,0.125)

#==== Add quiver plot ======== 
plt.quiver(x[::8,::8], y[::8,::8],ivtx_aut3[::8,::8],ivty_aut3[::8,::8],pivot='middle',scale_units='inches',headwidth=6,headlength=9)


#===== Add colorbar ===================
divider = make_axes_locatable(ax)
cax = divider.append_axes('bottom', size="10%", pad=0.2)
cbar = fig.colorbar(m2, cax=cax,orientation='horizontal',extend='both')
cbar.set_label('$Kg m^{-1} s^{-1}$',fontsize=15)
cbar.ax.tick_params(labelsize=12)
cbar.ax.minorticks_on()




fig.subplots_adjust(top=0.973,
                        bottom=0.07,
                        left=0.025,
                        right=0.972,
                        hspace=0.002,
                        wspace=0.031)

plt.savefig('fig4.png',dpi=300)
plt.show()

