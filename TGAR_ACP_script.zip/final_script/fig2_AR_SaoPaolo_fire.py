""" This code generates the AR object """


import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap
import numpy as np
import cmaps
import xarray as xr
from numpy import sqrt
import matplotlib
import numpy.ma as ma
import pandas as pd
# Conrol font
matplotlib.rcParams['font.family'] = "sans-serif"
matplotlib.rcParams['font.sans-serif'] = "Times New Roman"
# Load data
igt  = xr.open_dataset('ar_pan_shape_igt_regrid.nc')
data = xr.open_dataset('ar_pan_regrid.nc')
# Get ivtx and ivty
ivtx = igt.ivtx[19927,:,:]
ivty = igt.ivty[19927,:,:]
# Calculate IGT
igt = sqrt(ivtx**2 + ivty**2) 
# Get axis and shape
axis = data.axis[19927,:,:]
shape = data.shape[19927,:,:]
# Get lat and lon
lat = igt.lat
lon = igt.lon
# Get timestamp
time = igt.time.values
timestamp = pd.to_datetime(time)
formatted_time = timestamp.strftime("%Y/%b/%d, %H:%M:%S")


"""======= Create figure with two subplots======= """
fig = plt.figure(figsize=(4.5, 5))
grid = fig.add_gridspec(ncols=1,
                        nrows=2)
            
# Plot global AR objects 
ax1 = fig.add_subplot(grid[0, 0])
m1 = Basemap(projection='cyl', ax=ax1)
x1, y1 = m1(*np.meshgrid(lon, lat))
m1.drawcoastlines(linewidth=0.3)
m1.arcgisimage(service='Elevation/World_Hillshade_Dark', xpixels = 1500, verbose= True)
m1.drawparallels(range(-90, 91, 30), labels=[1, 0, 0, 0],   color='gray', linewidth=0.2, dashes=[4, 4])
m1.drawmeridians(range(-180, 180, 40), labels=[0, 0, 0, 1], color='gray', linewidth=0.2, dashes=[4, 4])
s1 = m1.contourf(x1, y1, igt, cmap=cmaps.CBR_wet)
# ======= Zoom in Main AR object ====================
ax2 = fig.add_subplot(grid[1, 0]) 
m2 = Basemap(projection='cyl', llcrnrlat=45, urcrnrlat=70, llcrnrlon=-80, urcrnrlon=60, resolution='c', ax=ax2)
x2, y2 = m2(*np.meshgrid(lon, lat))
m2.drawparallels(range(-90, 91, 10), labels=[1, 0, 0, 0], color='gray',   linewidth=0.5, dashes=[4, 4])
m2.drawmeridians(range(-180, 180, 30), labels=[0, 0, 0, 1], color='gray', linewidth=0.5, dashes=[4, 4])
m2.drawcoastlines(linewidth=0.5)
m2.drawcountries()
m2.drawlsmask(land_color='#36454F', ocean_color='#93CCEA', lakes=True)
s2 = m2.contourf(x2, y2, igt, cmap=cmaps.CBR_wet)
cbar2 = plt.colorbar(s2, ax=ax2, orientation='horizontal', pad=0.15)
cbar2.set_label('IGT_PAN[$Kg m^{-1} s^{-1}$]', fontsize=10, labelpad=5)
#cbar2.ax.set_title('$10^{-2}$')
cbar2.ax.tick_params(labelsize=10)
# Add text on the map
m2.scatter(x2, y2, axis, linewidth=4, marker='_', color='red')
plt.quiver(x2[::3,::3], y2[::3,::3], ivtx[::3,::3], ivty[::3,::3],
            pivot='middle', scale_units='width', 
            scale=4, headwidth=4, headlength=4,width=0.002)

fig.suptitle(f"PAN TGAR @ {formatted_time}", fontsize=15, y=0.95)

fig.subplots_adjust(top=0.88, bottom=0.083, left=0.102, right=0.955, hspace=0, wspace=0.315)

#plt.tight_layout()
plt.savefig('pan_atlantic_new.png', dpi=400)
plt.show()