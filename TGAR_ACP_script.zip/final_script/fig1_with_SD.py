

#===== Import Libraries ========================
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import cmaps
from matplotlib.patches import Patch
from matplotlib.pyplot import figure
import matplotlib.gridspec as gridspec
import scipy.ndimage
from mpl_toolkits.axes_grid1 import make_axes_locatable
from matplotlib import rcParams
from numpy import sqrt
import xarray as xr
from mpl_toolkits.axes_grid1 import make_axes_locatable
from mplgrid import grid
from mpl_toolkits.axes_grid1 import make_axes_locatable
from mpl_toolkits.axes_grid1 import ImageGrid
import pandas as pd
from geocat.viz import util as gvutil
from matplotlib.ticker import MultipleLocator, FormatStrFormatter
from matplotlib import ticker
import matplotlib.lines as mlines
from mpl_toolkits.basemap import Basemap
from mpl_toolkits.axes_grid1.inset_locator import inset_axes

"""Control font"""
matplotlib.rcParams['font.family'] = "sans-serif"
matplotlib.rcParams['font.sans-serif'] = "Times New Roman"
#============== Load data  =========================
df1  = xr.open_dataset('/Volumes/External_4TB/jpl_AR/2005_2019/co_2005_2019_monavg_regrid.nc')
df2  = xr.open_dataset('/Volumes/External_4TB/jpl_AR/2005_2019/o3_2005_2019_monavg_regrid.nc')
df3  = xr.open_dataset('/Volumes/External_4TB/jpl_AR/2005_2019/pan_2005_2019_monavg_regrid.nc')
#===== Get data ====
co  = df1.co
o3  = df2.o3
pan = df3.pan
#====== Get level from =======
lev  = co.lev

"""== Atlantic ==== """
co_wc  = co.sel(lat=slice(40, 60), lon=slice(-70, -10))
o3_wc  = o3.sel(lat=slice(40, 60), lon=slice(-70, -10))
pan_wc = pan.sel(lat=slice(40, 60), lon=slice(-70, -10))

"""== Pacific """
co_as  = co.sel(lat=slice(40, 55), lon=slice(140, 180))
o3_as  = o3.sel(lat=slice(40, 55), lon=slice(140, 180))
pan_as = pan.sel(lat=slice(40, 55), lon=slice(140, 180))

"""== Southern Hemisphere ===== """
co_ec  = co.sel(lat=slice(-65, -45), lon=slice(-90, 90))
o3_ec  = o3.sel(lat=slice(-65, -45), lon=slice(-90, 90))
pan_ec = pan.sel(lat=slice(-65, -45), lon=slice(-90, 90))

#=========== Now group by seasons ==========================
#==== Atlantic ==
co_wc   = co_wc.groupby("time.season").mean("time")
o3_wc   = o3_wc.groupby("time.season").mean("time")
pan_wc  = pan_wc.groupby("time.season").mean("time")
#==== Pacific ==
co_as   = co_as.groupby("time.season").mean("time")
o3_as   = o3_as.groupby("time.season").mean("time")
pan_as  = pan_as.groupby("time.season").mean("time")
#==== Southern Hemisphere ==
co_ec   = co_ec.groupby("time.season").mean("time")
o3_ec   = o3_ec.groupby("time.season").mean("time")
pan_ec  = pan_ec.groupby("time.season").mean("time")

#========= Now select the seasons ========================
""" Atlantic """
#======= CO =====================
co_wc_win = co_wc.isel(season=0) # winter
co_wc_sum = co_wc.isel(season=1) # summer
co_wc_spr = co_wc.isel(season=2) # spring
co_wc_aut = co_wc.isel(season=3) # autumn
#======= O3 =====================
o3_wc_win = o3_wc.isel(season=0) # winter
o3_wc_sum = o3_wc.isel(season=1) # summer
o3_wc_spr = o3_wc.isel(season=2) # spring
o3_wc_aut = o3_wc.isel(season=3) # autumn
#======= PAN =====================
pan_wc_win = pan_wc.isel(season=0) # winter
pan_wc_sum = pan_wc.isel(season=1) # summer
pan_wc_spr = pan_wc.isel(season=2) # spring
pan_wc_aut = pan_wc.isel(season=3) # autumn

""" Atlantic  """
#======= CO =====================
co_as_win = co_as.isel(season=0) # winter
co_as_sum = co_as.isel(season=1) # summer
co_as_spr = co_as.isel(season=2) # spring
co_as_aut = co_as.isel(season=3) # autumn
#======= O3 =====================
o3_as_win = o3_as.isel(season=0) # winter
o3_as_sum = o3_as.isel(season=1) # summer
o3_as_spr = o3_as.isel(season=2) # spring
o3_as_aut = o3_as.isel(season=3) # autumn
#======= PAN =====================
pan_as_win = pan_as.isel(season=0) # winter
pan_as_sum = pan_as.isel(season=1) # summer
pan_as_spr = pan_as.isel(season=2) # spring
pan_as_aut = pan_as.isel(season=3) # autumn
""" Southern Hemisphere  """
#======= CO =====================
co_ec_win = co_ec.isel(season=0) # winter
co_ec_sum = co_ec.isel(season=1) # summer
co_ec_spr = co_ec.isel(season=2) # spring
co_ec_aut = co_ec.isel(season=3) # autumn
#======= O3 =====================
o3_ec_win = o3_ec.isel(season=0) # winter
o3_ec_sum = o3_ec.isel(season=1) # summer
o3_ec_spr = o3_ec.isel(season=2) # spring
o3_ec_aut = o3_ec.isel(season=3) # autumn
#====== PAN =====================
pan_ec_win = pan_ec.isel(season=0) # winter
pan_ec_sum = pan_ec.isel(season=1) # summer
pan_ec_spr = pan_ec.isel(season=2) # spring
pan_ec_aut = pan_ec.isel(season=3) # autumn



"""======== Now take Zonal Average ========="""
"""=========== WEST COAST =================="""
#============ co ===============================
co_win_wc_av  = np.mean(co_wc_win,axis=1)      # lat
co_win_wc_av  = np.mean(co_win_wc_av,axis=1)   # lon

co_sum_wc_av  = np.mean(co_wc_sum,axis=1)
co_sum_wc_av  = np.mean(co_sum_wc_av,axis=1)

co_spr_wc_av  = np.mean(co_wc_spr,axis=1)
co_spr_wc_av  = np.mean(co_spr_wc_av,axis=1)

co_aut_wc_av  = np.mean(co_wc_aut,axis=1)
co_aut_wc_av  = np.mean(co_aut_wc_av,axis=1)

#============ o3  ===============================
o3_win_wc_av  = np.mean(o3_wc_win,axis=1)      # lat
o3_win_wc_av  = np.mean(o3_win_wc_av,axis=1)   # lon

o3_sum_wc_av  = np.mean(o3_wc_sum,axis=1)
o3_sum_wc_av  = np.mean(o3_sum_wc_av,axis=1)

o3_spr_wc_av  = np.mean(o3_wc_spr,axis=1)
o3_spr_wc_av  = np.mean(o3_spr_wc_av,axis=1)

o3_aut_wc_av  = np.mean(o3_wc_aut,axis=1)
o3_aut_wc_av  = np.mean(o3_aut_wc_av,axis=1)

#============ pan  ===============================
pan_win_wc_av  = np.mean(pan_wc_win,axis=1)      # lat
pan_win_wc_av  = np.mean(pan_win_wc_av,axis=1)   # lon

pan_sum_wc_av  = np.mean(pan_wc_sum,axis=1)
pan_sum_wc_av  = np.mean(pan_sum_wc_av,axis=1)

pan_spr_wc_av  = np.mean(pan_wc_spr,axis=1)
pan_spr_wc_av  = np.mean(pan_spr_wc_av,axis=1)

pan_aut_wc_av  = np.mean(pan_wc_aut,axis=1)
pan_aut_wc_av  = np.mean(pan_aut_wc_av,axis=1)



"""=========== Asia =================="""

#============ co ===============================
co_win_as_av  = np.mean(co_as_win,axis=1)      # lat
co_win_as_av  = np.mean(co_win_as_av,axis=1)   # lon

co_sum_as_av  = np.mean(co_as_sum,axis=1)
co_sum_as_av  = np.mean(co_sum_as_av,axis=1)

co_spr_as_av  = np.mean(co_as_spr,axis=1)
co_spr_as_av  = np.mean(co_spr_as_av,axis=1)

co_aut_as_av  = np.mean(co_as_aut,axis=1)
co_aut_as_av  = np.mean(co_aut_as_av,axis=1)

#============ o3  ===============================
o3_win_as_av  = np.mean(o3_as_win,axis=1)      # lat
o3_win_as_av  = np.mean(o3_win_as_av,axis=1)   # lon

o3_sum_as_av  = np.mean(o3_as_sum,axis=1)
o3_sum_as_av  = np.mean(o3_sum_as_av,axis=1)

o3_spr_as_av  = np.mean(o3_as_spr,axis=1)
o3_spr_as_av  = np.mean(o3_spr_as_av,axis=1)

o3_aut_as_av  = np.mean(o3_as_aut,axis=1)
o3_aut_as_av  = np.mean(o3_aut_as_av,axis=1)


#============ pan  ===============================
pan_win_as_av  = np.mean(pan_as_win,axis=1)      # lat
pan_win_as_av  = np.mean(pan_win_as_av,axis=1)   # lon

pan_sum_as_av  = np.mean(pan_as_sum,axis=1)
pan_sum_as_av  = np.mean(pan_sum_as_av,axis=1)

pan_spr_as_av  = np.mean(pan_as_spr,axis=1)
pan_spr_as_av  = np.mean(pan_spr_as_av,axis=1)

pan_aut_as_av  = np.mean(pan_as_aut,axis=1)
pan_aut_as_av  = np.mean(pan_aut_as_av,axis=1)

"""=========== EAST COAST =================="""

#============ co ===============================
co_win_ec_av  = np.mean(co_ec_win,axis=1)      # lat
co_win_ec_av  = np.mean(co_win_ec_av,axis=1)   # lon

co_sum_ec_av  = np.mean(co_ec_sum,axis=1)
co_sum_ec_av  = np.mean(co_sum_ec_av,axis=1)

co_spr_ec_av  = np.mean(co_ec_spr,axis=1)
co_spr_ec_av  = np.mean(co_spr_ec_av,axis=1)

co_aut_ec_av  = np.mean(co_ec_aut,axis=1)
co_aut_ec_av  = np.mean(co_aut_ec_av,axis=1)

#============ o3  ===============================
o3_win_ec_av  = np.mean(o3_ec_win,axis=1)      # lat
o3_win_ec_av  = np.mean(o3_win_ec_av,axis=1)   # lon

o3_sum_ec_av  = np.mean(o3_ec_sum,axis=1)
o3_sum_ec_av  = np.mean(o3_sum_ec_av,axis=1)

o3_spr_ec_av  = np.mean(o3_ec_spr,axis=1)
o3_spr_ec_av  = np.mean(o3_spr_ec_av,axis=1)

o3_aut_ec_av  = np.mean(o3_ec_aut,axis=1)
o3_aut_ec_av  = np.mean(o3_aut_ec_av,axis=1)


#============ pan  ===============================
pan_win_ec_av  = np.mean(pan_ec_win,axis=1)      # lat
pan_win_ec_av  = np.mean(pan_win_ec_av,axis=1)   # lon

pan_sum_ec_av  = np.mean(pan_ec_sum,axis=1)
pan_sum_ec_av  = np.mean(pan_sum_ec_av,axis=1)

pan_spr_ec_av  = np.mean(pan_ec_spr,axis=1)
pan_spr_ec_av  = np.mean(pan_spr_ec_av,axis=1)

pan_aut_ec_av  = np.mean(pan_ec_aut,axis=1)
pan_aut_ec_av  = np.mean(pan_aut_ec_av,axis=1)



# Calculate seasonal standard deviation = Atlantic
o3_at_std  = o3.sel(lat=slice(40, 60), lon=slice(-70, -10)).groupby("time.season").std("time")
co_at_std  = co.sel(lat=slice(40, 60), lon=slice(-70, -10)).groupby("time.season").std("time")
pan_at_std = pan.sel(lat=slice(40, 60), lon=slice(-70, -10)).groupby("time.season").std("time")

# Calculate seasonal standard deviation = Pacific
o3_pa_std  = o3.sel(lat=slice(40, 55), lon=slice(140, 180)).groupby("time.season").std("time")
co_pa_std  = co.sel(lat=slice(40, 55), lon=slice(140, 180)).groupby("time.season").std("time")
pan_pa_std = pan.sel(lat=slice(40, 55), lon=slice(140, 180)).groupby("time.season").std("time")

# Calculate seasonal standard deviation = Southern Hemispherre
o3_sh_std  = o3.sel(lat=slice(-65, -45), lon=slice(-90, 90)).groupby("time.season").std("time")
co_sh_std  = co.sel(lat=slice(-65, -45), lon=slice(-90, 90)).groupby("time.season").std("time")
pan_sh_std = pan.sel(lat=slice(-65, -45), lon=slice(-90, 90)).groupby("time.season").std("time")


#=== Getting the seasonal data for atlantic =======
#= O3
std_o3_win_atlantic = o3_at_std[0]
std_o3_spr_atlantic = o3_at_std[1]
std_o3_sum_atlantic = o3_at_std[2]
std_o3_aut_atlantic = o3_at_std[3]
#=CO
std_co_win_atlantic = co_at_std[0]
std_co_spr_atlantic = co_at_std[1]
std_co_sum_atlantic = co_at_std[2]
std_co_aut_atlantic = co_at_std[3]
# PAN
std_pan_win_atlantic = pan_at_std[0]
std_pan_spr_atlantic = pan_at_std[1]
std_pan_sum_atlantic = pan_at_std[2]
std_pan_aut_atlantic = pan_at_std[3]


#=== Getting the seasonal data for Pacific =======
#= O3
std_o3_win_pacific = o3_pa_std[0]
std_o3_spr_pacific = o3_pa_std[1]
std_o3_sum_pacific = o3_pa_std[2]
std_o3_aut_pacific = o3_pa_std[3]
#=CO
std_co_win_pacific = co_pa_std[0]
std_co_spr_pacific = co_pa_std[1]
std_co_sum_pacific = co_pa_std[2]
std_co_aut_pacific = co_pa_std[3]
# PAN
std_pan_win_pacific = pan_pa_std[0]
std_pan_spr_pacific = pan_pa_std[1]
std_pan_sum_pacific = pan_pa_std[2]
std_pan_aut_pacific = pan_pa_std[3]


#=== Getting the seasonal data for Pacific =======
#= O3
std_o3_win_sh = o3_sh_std[0]
std_o3_spr_sh = o3_sh_std[1]
std_o3_sum_sh = o3_sh_std[2]
std_o3_aut_sh = o3_sh_std[3]
#=CO
std_co_win_sh = co_sh_std[0]
std_co_spr_sh = co_sh_std[1]
std_co_sum_sh = co_sh_std[2]
std_co_aut_sh = co_sh_std[3]
# PAN
std_pan_win_sh = pan_sh_std[0]
std_pan_spr_sh = pan_sh_std[1]
std_pan_sum_sh = pan_sh_std[2]
std_pan_aut_sh = pan_sh_std[3]


""" Atlantic"""
# Calculate zonal average of standard deviation = O3
std_o3_win_atlantic_av = np.mean(std_o3_win_atlantic, axis=(1, 2))
std_o3_spr_atlantic_av = np.mean(std_o3_spr_atlantic, axis=(1, 2))
std_o3_sum_atlantic_av = np.mean(std_o3_sum_atlantic, axis=(1, 2))
std_o3_aut_atlantic_av = np.mean(std_o3_aut_atlantic, axis=(1, 2))

# Calculate zonal average of standard deviation = CO
std_co_win_atlantic_av = np.mean(std_co_win_atlantic, axis=(1, 2))
std_co_spr_atlantic_av = np.mean(std_co_spr_atlantic, axis=(1, 2))
std_co_sum_atlantic_av = np.mean(std_co_sum_atlantic, axis=(1, 2))
std_co_aut_atlantic_av = np.mean(std_co_aut_atlantic, axis=(1, 2))

# Calculate zonal average of standard deviation = PAN
std_pan_win_atlantic_av = np.mean(std_pan_win_atlantic, axis=(1, 2))
std_pan_spr_atlantic_av = np.mean(std_pan_spr_atlantic, axis=(1, 2))
std_pan_sum_atlantic_av = np.mean(std_pan_sum_atlantic, axis=(1, 2))
std_pan_aut_atlantic_av = np.mean(std_pan_aut_atlantic, axis=(1, 2))

""" Pacific"""
# Calculate zonal average of standard deviation = O3
std_o3_win_pacific_av = np.mean(std_o3_win_pacific, axis=(1, 2))
std_o3_spr_pacific_av = np.mean(std_o3_spr_pacific, axis=(1, 2))
std_o3_sum_pacific_av = np.mean(std_o3_sum_pacific, axis=(1, 2))
std_o3_aut_pacific_av = np.mean(std_o3_aut_pacific, axis=(1, 2))

# Calculate zonal average of standard deviation = CO
std_co_win_pacific_av = np.mean(std_co_win_pacific, axis=(1, 2))
std_co_spr_pacific_av = np.mean(std_co_spr_pacific, axis=(1, 2))
std_co_sum_pacific_av = np.mean(std_co_sum_pacific, axis=(1, 2))
std_co_aut_pacific_av = np.mean(std_co_aut_pacific, axis=(1, 2))

# Calculate zonal average of standard deviation = PAN
std_pan_win_pacific_av = np.mean(std_pan_win_pacific, axis=(1, 2))
std_pan_spr_pacific_av = np.mean(std_pan_spr_pacific, axis=(1, 2))
std_pan_sum_pacific_av = np.mean(std_pan_sum_pacific, axis=(1, 2))
std_pan_aut_pacific_av = np.mean(std_pan_aut_pacific, axis=(1, 2))


""" SH """
# Calculate zonal average of standard deviation = O3
std_o3_win_sh_av = np.mean(std_o3_win_sh, axis=(1, 2))
std_o3_spr_sh_av = np.mean(std_o3_spr_sh, axis=(1, 2))
std_o3_sum_sh_av = np.mean(std_o3_sum_sh, axis=(1, 2))
std_o3_aut_sh_av = np.mean(std_o3_aut_sh, axis=(1, 2))

# Calculate zonal average of standard deviation = CO
std_co_win_sh_av = np.mean(std_co_win_sh, axis=(1, 2))
std_co_spr_sh_av = np.mean(std_co_spr_sh, axis=(1, 2))
std_co_sum_sh_av = np.mean(std_co_sum_sh, axis=(1, 2))
std_co_aut_sh_av = np.mean(std_co_aut_sh, axis=(1, 2))

# Calculate zonal average of standard deviation = PAN
std_pan_win_sh_av = np.mean(std_pan_win_sh, axis=(1, 2))
std_pan_spr_sh_av = np.mean(std_pan_spr_sh, axis=(1, 2))
std_pan_sum_sh_av = np.mean(std_pan_sum_sh, axis=(1, 2))
std_pan_aut_sh_av = np.mean(std_pan_aut_sh, axis=(1, 2))





"""====== Now plot ======================================="""
fig = plt.figure(figsize=(10, 8))
""" =======  O3 WINTER ==============="""
ax = fig.add_subplot(4,3,1)
#ax = fig.add_subplot(1,1,1)
ax.plot(o3_win_wc_av,lev, 'green',   label='Atlantic',linewidth=2)
ax.plot(o3_win_as_av,lev, '#5D8AA8', label='Pacific', linewidth=2)
ax.plot(o3_win_ec_av,lev, 'black', label='Southern Hemisphere',linewidth=2)

#==== plot standard deviation ==
ax.fill_betweenx(lev, o3_win_wc_av - std_o3_win_atlantic_av, o3_win_wc_av + std_o3_win_atlantic_av, alpha=0.2,color='green',zorder=1)
ax.fill_betweenx(lev, o3_win_as_av - std_o3_win_atlantic_av, o3_win_as_av + std_o3_win_atlantic_av, alpha=0.2,color='#5D8AA8',zorder=1)
ax.fill_betweenx(lev, o3_win_ec_av - std_o3_win_atlantic_av, o3_win_ec_av + std_o3_win_atlantic_av, alpha=0.2,color='black',zorder=1)

plt.ylim(1000,0,200)
plt.xlim(20,100)
#===== Customize tick labels ====================
gvutil.set_titles_and_labels(ax,ylabel="DJF \n  [hPa]")
ax.set_title('$O_3$', fontsize=15, pad=10)
gvutil.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
ax.tick_params(axis='y', labelsize=12)
ax.tick_params(axis='x', labelsize=12)
ax.set_xticklabels([])

#ax.set_xticklabels([])
""" =======  O3 SPRING ==============="""
ax = fig.add_subplot(4,3,4)
ax.plot(o3_spr_wc_av,lev, 'green',   label='Atlantic',linewidth=2)
ax.plot(o3_spr_as_av,lev, '#5D8AA8', label='Pacific', linewidth=2)
ax.plot(o3_spr_ec_av,lev, 'magenta', label='Southern Hemisphere',linewidth=2)

#==== plot standard deviation ==
ax.fill_betweenx(lev, o3_spr_wc_av - std_o3_spr_atlantic_av, o3_spr_wc_av + std_o3_spr_atlantic_av, alpha=0.2,color='green',zorder=1)
ax.fill_betweenx(lev, o3_spr_as_av - std_o3_spr_atlantic_av, o3_spr_as_av + std_o3_spr_atlantic_av, alpha=0.2,color='#5D8AA8',zorder=1)
ax.fill_betweenx(lev, o3_spr_ec_av - std_o3_spr_atlantic_av, o3_spr_ec_av + std_o3_spr_atlantic_av, alpha=0.2,color='black',zorder=1)

plt.ylim(1000,0,200)
plt.xlim(20,100)
ax.set_xticklabels([])
#===== Customize tick labels ====================
gvutil.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
gvutil.set_titles_and_labels(ax,ylabel="MAM \n  [hPa]")
ax.tick_params(axis='y', labelsize=12)
ax.tick_params(axis='x', labelsize=12)
#ax.set_yticklabels([])
ax.set_xticklabels([])
""" =======  O3 SUMMER==============="""
ax = fig.add_subplot(4,3,7)

ax.plot(o3_sum_wc_av,lev, 'green',   label='Atlantic',linewidth=2)
ax.plot(o3_sum_as_av,lev, 'blue', label='Asia',linewidth=2)
ax.plot(o3_sum_ec_av,lev, '#3B444B', label='East Coast',linewidth=2)


#==== plot standard deviation ==
ax.fill_betweenx(lev, o3_sum_wc_av - std_o3_sum_atlantic_av, o3_sum_wc_av + std_o3_sum_atlantic_av, alpha=0.2,color='green',zorder=1)
ax.fill_betweenx(lev, o3_sum_as_av - std_o3_sum_atlantic_av, o3_sum_as_av + std_o3_sum_atlantic_av, alpha=0.2,color='#5D8AA8',zorder=1)
ax.fill_betweenx(lev, o3_sum_ec_av - std_o3_sum_atlantic_av, o3_sum_ec_av + std_o3_sum_atlantic_av, alpha=0.2,color='black',zorder=1)

#===== Customize tick labels ====================
gvutil.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
gvutil.set_titles_and_labels(ax,ylabel="JJA \n  [hPa]")
ax.tick_params(axis='y', labelsize=12)
ax.tick_params(axis='x', labelsize=12)
#ax.set_yticklabels([])
ax.set_xticklabels([])

plt.ylim(1000,0,200)
plt.xlim(20,100)

""" =======  O3 AUTUMN ==============="""
ax = fig.add_subplot(4,3,10)
ax.plot(o3_aut_wc_av,lev, 'green', label='West Coast',linewidth=2)
ax.plot(o3_aut_as_av,lev, '#5D8AA8', label='Pacific', linewidth=2)
ax.plot(o3_aut_ec_av,lev, 'black', label='East Coast',linewidth=2)


#==== plot standard deviation ==
ax.fill_betweenx(lev, o3_aut_wc_av - std_o3_aut_atlantic_av, o3_aut_wc_av + std_o3_aut_atlantic_av, alpha=0.2,color='green',zorder=1)
ax.fill_betweenx(lev, o3_aut_as_av - std_o3_aut_atlantic_av, o3_aut_as_av + std_o3_aut_atlantic_av, alpha=0.2,color='#5D8AA8',zorder=1)
ax.fill_betweenx(lev, o3_aut_ec_av - std_o3_aut_atlantic_av, o3_aut_ec_av + std_o3_aut_atlantic_av, alpha=0.2,color='black',zorder=1)

#===== Customize tick labels ====================
gvutil.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
gvutil.set_titles_and_labels(ax,ylabel="SON \n  [hPa]")
ax.tick_params(axis='y', labelsize=12)
ax.tick_params(axis='x', labelsize=12)
#ax.set_yticklabels([])
plt.ylim(1000,0,200)
plt.xlim(20,100)

""" =======  CO WINTER ==============="""
ax = fig.add_subplot(4,3,2)
ax.plot(co_win_wc_av,lev, 'green',   label='Atlantic',linewidth=2)
ax.plot(co_win_as_av,lev, '#5D8AA8', label='Pacific', linewidth=2)
ax.plot(co_win_ec_av,lev, 'magenta', label='Southern Hemisphere',linewidth=2)
plt.ylim(1000,0,200)
plt.xlim(50,350,50)
#===== Customize tick labels ====================
gvutil.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
ax.tick_params(axis='y', labelsize=10)
ax.tick_params(axis='x', labelsize=10)
ax.set_xticklabels([])
ax.set_yticklabels([])
ax.legend(loc="upper right",fontsize=10)
ax.set_title('CO', fontsize=15, pad=10)
""" =======  CO SPRING ==============="""
ax = fig.add_subplot(4,3,5)
ax.plot(co_spr_wc_av,lev, 'red',linewidth=0.8)
ax.plot(co_spr_as_av,lev, 'blue',linewidth=0.8)
ax.plot(co_spr_ec_av,lev, '#3B444B',linewidth=0.8)
plt.ylim(1000,0,200)
plt.xlim(50,350,50)
#===== Customize tick labels ====================
gvutil.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
ax.tick_params(axis='y', labelsize=10)
ax.tick_params(axis='x', labelsize=10)
ax.set_yticklabels([])
ax.set_xticklabels([])
plt.xlim(50,350,50)
""" =======  CO SUMMER==============="""
ax = fig.add_subplot(4,3,8)
ax.plot(co_sum_wc_av,lev, 'red', label='West Coast',linewidth=0.8)
ax.plot(co_sum_as_av,lev, 'blue', label='Asia',linewidth=0.8)
ax.plot(co_sum_ec_av,lev, '#3B444B', label='East Coast',linewidth=0.8)
#===== Customize tick labels ====================
gvutil.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
ax.tick_params(axis='y', labelsize=10)
ax.tick_params(axis='x', labelsize=10)
ax.set_yticklabels([])
ax.set_xticklabels([])
plt.ylim(1000,0,200)
plt.xlim(50,350,50)
""" =======  CO AUTUMN ==============="""
ax = fig.add_subplot(4,3,11)
ax.plot(co_aut_wc_av,lev, 'red', label='West Coast',linewidth=0.8)
ax.plot(co_aut_as_av,lev, 'blue', label='Asia',linewidth=0.8)
ax.plot(co_aut_ec_av,lev, '#3B444B', label='East Coast',linewidth=0.8)
#===== Customize tick labels ====================
gvutil.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
ax.tick_params(axis='y', labelsize=10)
ax.tick_params(axis='x', labelsize=10)
ax.set_yticklabels([])
plt.ylim(1000,0,200)
plt.xlim(0,400,100)

""" =======  PAN WINTER ==============="""
ax = fig.add_subplot(4,3,3)
ax.plot(pan_win_wc_av,lev, 'red', label='West Coast',linewidth=0.8)
ax.plot(pan_win_as_av,lev, 'blue', label='Asia',linewidth=0.8)
ax.plot(pan_win_ec_av,lev, '#3B444B', label='East Coast',linewidth=0.8)
plt.ylim(1000,0,200)
plt.xlim(0,400,100)
ax.set_xticklabels([])
ax.set_yticklabels([])
#===== Customize tick labels ====================
gvutil.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
ax.tick_params(axis='y', labelsize=10)
ax.tick_params(axis='x', labelsize=10)
ax.set_title('PAN', fontsize=15, pad=10)


#=== add basemap in the corner ==
ax_map = inset_axes(ax, width="50%", height="50%", loc='upper right')
m = Basemap(projection='cyl', llcrnrlat=-90, urcrnrlat=90, llcrnrlon=-180, urcrnrlon=180, resolution='c', ax=ax_map)
m.drawcoastlines(linewidth=0.3)
m.drawcountries(linewidth=0.3)
m.fillcontinents(color='lightgray', lake_color='white')
m.drawparallels(np.arange(-90., 91., 30.),   linewidth=0.2, dashes=[4, 4],labels=[1, 0, 0, 0], fontsize=7)
m.drawmeridians(np.arange(-180., 181., 90.), linewidth=0.2, dashes=[4, 4],labels=[0, 0, 0, 1], fontsize=7)


# Add rectangles for specified regions
def add_rectangle(lons, lats, color):
    x, y = m(lons, lats)
    m.plot(x, y, color=color, linewidth=1, latlon=False)

# Atlantic
lon2 = [-70, -70, -10, -10, -70]
lat2 = [40, 60, 60, 40, 40]
add_rectangle(lon2, lat2, 'green')

# Southern hemisphere
lon4 = [-90, -90, 90, 90, -90]
lat4 = [-45, -65, -65, -45, -45]
add_rectangle(lon4, lat4, '#5D8AA8')

# Pacific
lon5 = [140, 140, 180, 180, 140]
lat5 = [40, 55, 55, 40, 40]
add_rectangle(lon5, lat5, 'magenta')


""" =======  PAN SPRING ==============="""
ax = fig.add_subplot(4,3,6)
ax.plot(pan_spr_wc_av,lev, 'red',linewidth=0.8)
ax.plot(pan_spr_as_av,lev, 'blue',linewidth=0.8)
ax.plot(pan_spr_ec_av,lev, '#3B444B',linewidth=0.8)
plt.ylim(1000,0,200)
plt.xlim(0,400,100)

#===== Customize tick labels ====================
gvutil.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
ax.tick_params(axis='y', labelsize=10)
ax.tick_params(axis='x', labelsize=10)
ax.set_yticklabels([])
ax.set_xticklabels([])
""" ======= PAN SUMMER==============="""
ax = fig.add_subplot(4,3,9)
ax.plot(pan_sum_wc_av,lev, 'red', label='West Coast',linewidth=0.8)
ax.plot(pan_sum_as_av,lev, 'blue', label='Asia',linewidth=0.8)
ax.plot(pan_sum_ec_av,lev, '#3B444B', label='East Coast',linewidth=0.8)
#===== Customize tick labels ====================
gvutil.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
ax.tick_params(axis='y', labelsize=10)
ax.tick_params(axis='x', labelsize=10)
ax.set_yticklabels([])
ax.set_xticklabels([])
plt.ylim(1000,0,200)
plt.xlim(0,400,100)
""" =======  PAN AUTUMN ==============="""
ax = fig.add_subplot(4,3,12)
ax.plot(pan_aut_wc_av,lev, 'red', label='West Coast',linewidth=0.8)
ax.plot(pan_aut_as_av,lev, 'blue', label='Asia',linewidth=0.8)
ax.plot(pan_aut_ec_av,lev, '#3B444B', label='East Coast',linewidth=0.8)
#===== Customize tick labels ====================
gvutil.add_major_minor_ticks(ax,x_minor_per_major=3,y_minor_per_major=4,labelsize=8)
ax.tick_params(axis='y', labelsize=10)
ax.tick_params(axis='x', labelsize=10)
ax.set_yticklabels([])
plt.ylim(1000,0,200)
plt.xlim(0,400,100)


fig.subplots_adjust(top=0.952,
                    bottom=0.037,
                    left=0.102,
                    right=0.977,
                    hspace=0.113,
                    wspace=0.135)

plt.savefig('f1_new_new.png',dpi=600)
plt.show()


